
![Police Data Challenge](http://thisisstatistics.org/wp-content/uploads/2017/09/ASA_PDC_opt1_1140x350-1140x350.jpg)

# <font color=green>**Police Data Challenge**</font>



As data collection and analysis become critical tools for policing, law enforcement agencies aren’t just working case by case. Police forces are working with statisticians in crime analyst roles to identify big-picture patterns in the numbers that are as critical as any other clue in the fight to keep communities safe. Together, they are encouraging joint problem solving, innovation, enhanced understanding, and accountability between communities and the law enforcement agencies that serve them.

>Using data available through the <font color = red>*Police Data Initiative*</font>, we had to analyze complex data sets from the <font color = red>Baltimore, Cincinnati and **Seattle** Police Departments</font>, and also recommend innovative solutions to enhance public safety. Although not required, teams may identify and utilize external data sets.

**How Does the Contest Work?** 
Teams of 2-5 high school or college undergrad students in the U.S. and Canada can submit an entry. Each team must complete the declaration of intent form by 11:59 PM on Friday, Oct. 20 and must submit their presentation by 11:59 PM EDT on Friday, Nov. 3 to be eligible. Submissions will require a short essay describing the team’s process and presenting their analysis and recommendations via a PowerPoint presentation.

> Awards will be given in three categories (1) **<font color = green>Best Overall Analysis**</font>,<font color = purple>(*Spoiler Alert*)</font> (2) Best Visualization, and (3) Best Use of External Data.
**--------------------------------------------------------------------------------------------------------------------**

This was also a Midterm Project for our <font,color=magenta>**Data Visualization Class**</font> taught by <font,color=green>[**Prof.Silas Bergen**](http://driftlessdata.space)</font>.  We would like to thank him for this huge midterm project(*maybe the first time i am thankful for giving us a huge project and pushing us to think creative and practical*) and ofcourse his creativity and innovative thinking

My team,<font color= purple>**Jimmy Hickey**,**Luke Peacock**,*and me* **Kapil Khanal**</font> representing <font color=purple>**WINONA STATE UNIVERSITY**</font>

I would definetly like to thank *StackOverflow*,*Pandas Documentation*,*DataQuest*,*tab completion in Jupyter notebook* for code snippets and tutorials and **F<font color=red>.</font>R<font color=magenta>.</font>I<font color=purple>.</font>E<font color=blue>.</font>N<font color=green>.</font>D<font color=violet>.</font>S** for being there for me during computation time

# Let's dive in....


```python
#Import Everythng that is necessary
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import matplotlib.dates as mdates
import seaborn as sns
```


```python
#Had to name like this... dsci_midterm.csv..LOL....Any WSU data science student knows the mess..in their machine.
#CSV,CSV everywhere !!
crime_data = pd.read_csv("dsci_midterm.csv") 
```

    /anaconda/lib/python3.6/site-packages/IPython/core/interactiveshell.py:2728: DtypeWarning: Columns (0) have mixed types. Specify dtype option on import or set low_memory=False.
      interactivity=interactivity, compiler=compiler, result=result)



```python
#Let's peek at the data
crime_data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CAD CDW ID</th>
      <th>CAD Event Number</th>
      <th>General Offense Number</th>
      <th>Event Clearance Code</th>
      <th>Event Clearance Description</th>
      <th>Event Clearance SubGroup</th>
      <th>Event Clearance Group</th>
      <th>Event Clearance Date</th>
      <th>Hundred Block Location</th>
      <th>District/Sector</th>
      <th>Zone/Beat</th>
      <th>Census Tract</th>
      <th>Longitude</th>
      <th>Latitude</th>
      <th>Incident Location</th>
      <th>Initial Type Description</th>
      <th>Initial Type Subgroup</th>
      <th>Initial Type Group</th>
      <th>At Scene Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>﻿15736</td>
      <td>10000246357</td>
      <td>2010246357</td>
      <td>242.0</td>
      <td>FIGHT DISTURBANCE</td>
      <td>DISTURBANCES</td>
      <td>DISTURBANCES</td>
      <td>07/17/2010 08:49:00 PM</td>
      <td>3XX BLOCK OF PINE ST</td>
      <td>M</td>
      <td>M2</td>
      <td>8100.2001</td>
      <td>-122.338147</td>
      <td>47.610975</td>
      <td>(47.610975163, -122.338146748)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15737</td>
      <td>10000246471</td>
      <td>2010246471</td>
      <td>65.0</td>
      <td>THEFT - MISCELLANEOUS</td>
      <td>THEFT</td>
      <td>OTHER PROPERTY</td>
      <td>07/17/2010 08:50:00 PM</td>
      <td>36XX BLOCK OF DISCOVERY PARK BLVD</td>
      <td>Q</td>
      <td>Q1</td>
      <td>5700.1012</td>
      <td>-122.404613</td>
      <td>47.658325</td>
      <td>(47.658324899, -122.404612874)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>15738</td>
      <td>10000246255</td>
      <td>2010246255</td>
      <td>250.0</td>
      <td>MISCHIEF, NUISANCE COMPLAINTS</td>
      <td>NUISANCE, MISCHIEF COMPLAINTS</td>
      <td>NUISANCE, MISCHIEF</td>
      <td>07/17/2010 08:55:00 PM</td>
      <td>21XX BLOCK OF 3RD AVE</td>
      <td>M</td>
      <td>M2</td>
      <td>7200.2025</td>
      <td>-122.342843</td>
      <td>47.613551</td>
      <td>(47.613551471, -122.342843234)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15739</td>
      <td>10000246473</td>
      <td>2010246473</td>
      <td>460.0</td>
      <td>TRAFFIC (MOVING) VIOLATION</td>
      <td>TRAFFIC RELATED CALLS</td>
      <td>TRAFFIC RELATED CALLS</td>
      <td>07/17/2010 09:00:00 PM</td>
      <td>7XX BLOCK OF ROY ST</td>
      <td>D</td>
      <td>D1</td>
      <td>7200.1002</td>
      <td>-122.341847</td>
      <td>47.625401</td>
      <td>(47.625401388, -122.341846999)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15740</td>
      <td>10000246330</td>
      <td>2010246330</td>
      <td>250.0</td>
      <td>MISCHIEF, NUISANCE COMPLAINTS</td>
      <td>NUISANCE, MISCHIEF COMPLAINTS</td>
      <td>NUISANCE, MISCHIEF</td>
      <td>07/17/2010 09:00:00 PM</td>
      <td>9XX BLOCK OF ALOHA ST</td>
      <td>D</td>
      <td>D1</td>
      <td>6700.1009</td>
      <td>-122.339709</td>
      <td>47.627425</td>
      <td>(47.627424837, -122.339708605)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Woah !! What is up with that NaN..Let's check if its like that all across dataset
crime_data.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CAD CDW ID</th>
      <th>CAD Event Number</th>
      <th>General Offense Number</th>
      <th>Event Clearance Code</th>
      <th>Event Clearance Description</th>
      <th>Event Clearance SubGroup</th>
      <th>Event Clearance Group</th>
      <th>Event Clearance Date</th>
      <th>Hundred Block Location</th>
      <th>District/Sector</th>
      <th>Zone/Beat</th>
      <th>Census Tract</th>
      <th>Longitude</th>
      <th>Latitude</th>
      <th>Incident Location</th>
      <th>Initial Type Description</th>
      <th>Initial Type Subgroup</th>
      <th>Initial Type Group</th>
      <th>At Scene Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1444259</th>
      <td>2088572</td>
      <td>17000333842</td>
      <td>2017333842</td>
      <td>280.0</td>
      <td>SUSPICIOUS PERSON</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>09/08/2017 02:06:17 AM</td>
      <td>62XX BLOCK OF 13 AV S</td>
      <td>O</td>
      <td>O3</td>
      <td>10900.2089</td>
      <td>-122.316110</td>
      <td>47.547516</td>
      <td>(47.547516, -122.31611)</td>
      <td>UNKNOWN - COMPLAINT OF UNKNOWN NATURE</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1444260</th>
      <td>2088573</td>
      <td>17000333823</td>
      <td>2017333823</td>
      <td>245.0</td>
      <td>DISTURBANCE, OTHER</td>
      <td>DISTURBANCES</td>
      <td>DISTURBANCES</td>
      <td>09/08/2017 02:13:38 AM</td>
      <td>46XX BLOCK OF S MORGAN ST</td>
      <td>S</td>
      <td>S2</td>
      <td>11101.1002</td>
      <td>-122.274994</td>
      <td>47.544250</td>
      <td>(47.54425, -122.274994)</td>
      <td>FIGHT - JO - PHYSICAL (NO WEAPONS)</td>
      <td>DISTURBANCES</td>
      <td>DISTURBANCES</td>
      <td>09/08/2017 01:26:38 AM</td>
    </tr>
    <tr>
      <th>1444261</th>
      <td>2088522</td>
      <td>17000333768</td>
      <td>2017333768</td>
      <td>161.0</td>
      <td>TRESPASS</td>
      <td>TRESPASS</td>
      <td>TRESPASS</td>
      <td>09/08/2017 12:13:15 AM</td>
      <td>1XX BLOCK OF MERCER ST</td>
      <td>Q</td>
      <td>Q3</td>
      <td>7000.3021</td>
      <td>-122.354750</td>
      <td>47.624577</td>
      <td>(47.624577, -122.35475)</td>
      <td>TRESPASS</td>
      <td>TRESPASS</td>
      <td>TRESPASS</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1444262</th>
      <td>2088590</td>
      <td>17000333779</td>
      <td>2017333779</td>
      <td>430.0</td>
      <td>MOTOR VEHICLE COLLISION</td>
      <td>TRAFFIC RELATED CALLS</td>
      <td>MOTOR VEHICLE COLLISION INVESTIGATION</td>
      <td>09/08/2017 02:41:47 AM</td>
      <td>1XX BLOCK OF BROADWAY E</td>
      <td>E</td>
      <td>E1</td>
      <td>7402.1010</td>
      <td>-122.320860</td>
      <td>47.619324</td>
      <td>(47.619324, -122.32086)</td>
      <td>MOTOR VEHICLE COLLISION, HIT AND RUN</td>
      <td>MOTOR VEHICLE COLLISION INVESTIGATION</td>
      <td>TRAFFIC RELATED CALLS</td>
      <td>09/08/2017 12:12:32 AM</td>
    </tr>
    <tr>
      <th>1444263</th>
      <td>2088591</td>
      <td>17000333762</td>
      <td>2017333762</td>
      <td>280.0</td>
      <td>SUSPICIOUS PERSON</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>09/08/2017 02:42:57 AM</td>
      <td>2XX BLOCK OF LAKE WASHINGTON BV E</td>
      <td>C</td>
      <td>C3</td>
      <td>7800.1016</td>
      <td>-122.281586</td>
      <td>47.620106</td>
      <td>(47.620106, -122.281586)</td>
      <td>SUSPICIOUS STOP - OFFICER INITIATED ONVIEW</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>SUSPICIOUS CIRCUMSTANCES</td>
      <td>09/07/2017 11:34:38 PM</td>
    </tr>
  </tbody>
</table>
</div>




```python
crime_data.dtypes
```




    CAD CDW ID                      object
    CAD Event Number                 int64
    General Offense Number           int64
    Event Clearance Code           float64
    Event Clearance Description     object
    Event Clearance SubGroup        object
    Event Clearance Group           object
    Event Clearance Date            object
    Hundred Block Location          object
    District/Sector                 object
    Zone/Beat                       object
    Census Tract                   float64
    Longitude                      float64
    Latitude                       float64
    Incident Location               object
    Initial Type Description        object
    Initial Type Subgroup           object
    Initial Type Group              object
    At Scene Time                   object
    dtype: object



*Time info are not in a datetime object.Right now, I am thinking to change those to proper type.*

I right away started splitting time in ':' and started pulling cash one of them separately which was cumbersome until i read somewhere that i can change it to datetime and pull time/hour/second as necessary from there..which was cool.

```python

***Terrible way of doing things***

crime_data["Event_Hour"] = crime_data["Event_Time"].apply(lambda x: x.split(":"))
crime_data["Scene_Hour"] = crime_data["Scene_Time"].apply(lambda x: x.split(":"))


crime_data["event_hour"] = [list_time[0] for list_time in crime_data["Event_Hour"]]
crime_data["scene_hour"] = [list_time[0] for list_time in crime_data["Scene_Hour"]]


crime_data["scene_hour"] =crime_data["scene_hour"].replace('nan',None)
crime_data["scene_hour"] = crime_data["scene_hour"].dropna()
crime_data["scene_hour"]'

```
So, i tried that...DATETIME MODULE to the RESCUE


```python
crime_data["Event_timing"] = pd.to_datetime(crime_data["Event Clearance Date"],errors = 'ignore')
crime_data["Scene_timing"] = pd.to_datetime(crime_data["At Scene Time"],errors = 'ignore')
```

*Would be interesting to see the response time.... For Now,Let's just compute it..I am hoping it will do proper subtract as it's datetime object* Else, We could always do heavy lifting...through python toolbox like split,lambdas and others...i did that before i actually did datetime object...i am still learning so...don't blame me! plz !!


```python
crime_data["response_time"] = crime_data["Event_timing"] - crime_data["Scene_timing"]
```

There were one or more rows where there was no data for either scene time or very rarely event clearance type...So we will get some NA's...*kinda like hollywood superheroes... Tricky Business*

**Let's slice and dice the time information**


```python
crime_data["Event_Date"] = crime_data["Event_timing"].dt.date
crime_data["Event_Time"] = crime_data["Event_timing"].dt.time
crime_data["Scene_Date"] = crime_data["Scene_timing"].dt.date
crime_data["Scene_Time"] = crime_data["Scene_timing"].dt.time 

```


```python
by_crime_group = crime_data.groupby(["Scene_Date"]).count()

```


```python
by_crime_group.reset_index
```




    <bound method DataFrame.reset_index of             CAD CDW ID  CAD Event Number  General Offense Number  \
    Scene_Date                                                         
    2009-06-19           1                 1                       1   
    2009-06-21           1                 1                       1   
    2009-06-26           1                 1                       1   
    2009-08-22           1                 1                       1   
    2009-11-28           1                 1                       1   
    2009-12-22           1                 1                       1   
    2009-12-31           1                 1                       1   
    2010-01-01           2                 2                       2   
    2010-01-02           1                 1                       1   
    2010-01-04           2                 2                       2   
    2010-01-05           1                 1                       1   
    2010-01-06           2                 2                       2   
    2010-01-07           1                 1                       1   
    2010-01-08           3                 3                       3   
    2010-01-09           1                 1                       1   
    2010-05-21           1                 1                       1   
    2010-08-12           1                 1                       1   
    2010-08-17           1                 1                       1   
    2010-09-02           1                 1                       1   
    2010-09-21           1                 1                       1   
    2010-09-30           1                 1                       1   
    2010-10-12           1                 1                       1   
    2010-12-01           3                 3                       3   
    2010-12-02           2                 2                       2   
    2010-12-03           3                 3                       3   
    2010-12-04           2                 2                       2   
    2010-12-05           1                 1                       1   
    2010-12-07           1                 1                       1   
    2010-12-09           1                 1                       1   
    2010-12-10           2                 2                       2   
    ...                ...               ...                     ...   
    2017-09-11         356               356                     356   
    2017-09-12         321               321                     321   
    2017-09-13         363               363                     363   
    2017-09-14         434               434                     434   
    2017-09-15         345               345                     345   
    2017-09-16         348               348                     348   
    2017-09-17         319               319                     319   
    2017-09-18         327               327                     327   
    2017-09-19         322               322                     322   
    2017-09-20         293               293                     293   
    2017-09-21         312               312                     312   
    2017-09-22         367               367                     367   
    2017-09-23         292               292                     292   
    2017-09-24         291               291                     291   
    2017-09-25         325               325                     325   
    2017-09-26         342               342                     342   
    2017-09-27         345               345                     345   
    2017-09-28         358               358                     358   
    2017-09-29         344               344                     344   
    2017-09-30         295               295                     295   
    2017-10-01         315               315                     315   
    2017-10-02         350               350                     350   
    2017-10-03         318               318                     318   
    2017-10-04         346               346                     346   
    2017-10-05         375               375                     375   
    2017-10-06         364               364                     364   
    2017-10-07         311               311                     311   
    2017-10-08         281               281                     281   
    2017-10-09         299               299                     299   
    2017-10-10         142               142                     142   
    
                Event Clearance Code  Event Clearance Description  \
    Scene_Date                                                      
    2009-06-19                     1                            1   
    2009-06-21                     1                            1   
    2009-06-26                     1                            1   
    2009-08-22                     1                            1   
    2009-11-28                     1                            1   
    2009-12-22                     1                            1   
    2009-12-31                     1                            1   
    2010-01-01                     2                            2   
    2010-01-02                     1                            1   
    2010-01-04                     2                            2   
    2010-01-05                     1                            1   
    2010-01-06                     2                            2   
    2010-01-07                     1                            1   
    2010-01-08                     3                            3   
    2010-01-09                     1                            1   
    2010-05-21                     1                            1   
    2010-08-12                     1                            1   
    2010-08-17                     1                            1   
    2010-09-02                     1                            1   
    2010-09-21                     1                            1   
    2010-09-30                     1                            1   
    2010-10-12                     1                            1   
    2010-12-01                     3                            3   
    2010-12-02                     2                            2   
    2010-12-03                     3                            3   
    2010-12-04                     2                            2   
    2010-12-05                     1                            1   
    2010-12-07                     1                            1   
    2010-12-09                     1                            1   
    2010-12-10                     2                            2   
    ...                          ...                          ...   
    2017-09-11                   356                          356   
    2017-09-12                   321                          321   
    2017-09-13                   363                          363   
    2017-09-14                   434                          434   
    2017-09-15                   345                          345   
    2017-09-16                   348                          348   
    2017-09-17                   319                          319   
    2017-09-18                   327                          327   
    2017-09-19                   322                          322   
    2017-09-20                   293                          293   
    2017-09-21                   312                          312   
    2017-09-22                   367                          367   
    2017-09-23                   292                          292   
    2017-09-24                   291                          291   
    2017-09-25                   325                          325   
    2017-09-26                   342                          342   
    2017-09-27                   345                          345   
    2017-09-28                   358                          358   
    2017-09-29                   344                          344   
    2017-09-30                   295                          295   
    2017-10-01                   315                          315   
    2017-10-02                   350                          350   
    2017-10-03                   318                          318   
    2017-10-04                   346                          346   
    2017-10-05                   375                          375   
    2017-10-06                   364                          364   
    2017-10-07                   311                          311   
    2017-10-08                   281                          281   
    2017-10-09                   299                          299   
    2017-10-10                   142                          142   
    
                Event Clearance SubGroup  Event Clearance Group  \
    Scene_Date                                                    
    2009-06-19                         1                      1   
    2009-06-21                         1                      1   
    2009-06-26                         1                      1   
    2009-08-22                         1                      1   
    2009-11-28                         1                      1   
    2009-12-22                         1                      1   
    2009-12-31                         1                      1   
    2010-01-01                         2                      2   
    2010-01-02                         1                      1   
    2010-01-04                         2                      2   
    2010-01-05                         1                      1   
    2010-01-06                         2                      2   
    2010-01-07                         1                      1   
    2010-01-08                         3                      3   
    2010-01-09                         1                      1   
    2010-05-21                         1                      1   
    2010-08-12                         1                      1   
    2010-08-17                         1                      1   
    2010-09-02                         1                      1   
    2010-09-21                         1                      1   
    2010-09-30                         1                      1   
    2010-10-12                         1                      1   
    2010-12-01                         3                      3   
    2010-12-02                         2                      2   
    2010-12-03                         3                      3   
    2010-12-04                         2                      2   
    2010-12-05                         1                      1   
    2010-12-07                         1                      1   
    2010-12-09                         1                      1   
    2010-12-10                         2                      2   
    ...                              ...                    ...   
    2017-09-11                       356                    356   
    2017-09-12                       321                    321   
    2017-09-13                       363                    363   
    2017-09-14                       434                    434   
    2017-09-15                       345                    345   
    2017-09-16                       348                    348   
    2017-09-17                       319                    319   
    2017-09-18                       327                    327   
    2017-09-19                       322                    322   
    2017-09-20                       293                    293   
    2017-09-21                       312                    312   
    2017-09-22                       367                    367   
    2017-09-23                       292                    292   
    2017-09-24                       291                    291   
    2017-09-25                       325                    325   
    2017-09-26                       342                    342   
    2017-09-27                       345                    345   
    2017-09-28                       358                    358   
    2017-09-29                       344                    344   
    2017-09-30                       295                    295   
    2017-10-01                       315                    315   
    2017-10-02                       350                    350   
    2017-10-03                       318                    318   
    2017-10-04                       346                    346   
    2017-10-05                       375                    375   
    2017-10-06                       364                    364   
    2017-10-07                       311                    311   
    2017-10-08                       281                    281   
    2017-10-09                       299                    299   
    2017-10-10                       142                    142   
    
                Event Clearance Date  Hundred Block Location  District/Sector  \
    Scene_Date                                                                  
    2009-06-19                     1                       1                1   
    2009-06-21                     1                       1                1   
    2009-06-26                     1                       1                1   
    2009-08-22                     1                       1                1   
    2009-11-28                     1                       1                1   
    2009-12-22                     1                       1                1   
    2009-12-31                     1                       1                1   
    2010-01-01                     2                       2                2   
    2010-01-02                     1                       1                1   
    2010-01-04                     2                       2                2   
    2010-01-05                     1                       1                1   
    2010-01-06                     2                       2                2   
    2010-01-07                     1                       1                1   
    2010-01-08                     3                       3                3   
    2010-01-09                     1                       1                1   
    2010-05-21                     1                       1                1   
    2010-08-12                     1                       1                1   
    2010-08-17                     1                       1                1   
    2010-09-02                     1                       1                1   
    2010-09-21                     1                       1                1   
    2010-09-30                     1                       1                1   
    2010-10-12                     1                       1                1   
    2010-12-01                     3                       3                3   
    2010-12-02                     2                       2                2   
    2010-12-03                     3                       3                3   
    2010-12-04                     2                       2                2   
    2010-12-05                     1                       1                1   
    2010-12-07                     1                       1                1   
    2010-12-09                     1                       1                1   
    2010-12-10                     2                       2                2   
    ...                          ...                     ...              ...   
    2017-09-11                   356                     356              356   
    2017-09-12                   321                     321              321   
    2017-09-13                   363                     363              363   
    2017-09-14                   434                     434              434   
    2017-09-15                   345                     345              345   
    2017-09-16                   348                     348              348   
    2017-09-17                   319                     319              319   
    2017-09-18                   327                     327              327   
    2017-09-19                   322                     322              322   
    2017-09-20                   293                     293              293   
    2017-09-21                   312                     312              312   
    2017-09-22                   367                     367              367   
    2017-09-23                   292                     292              292   
    2017-09-24                   291                     291              291   
    2017-09-25                   325                     325              325   
    2017-09-26                   342                     342              342   
    2017-09-27                   345                     345              345   
    2017-09-28                   358                     358              358   
    2017-09-29                   344                     344              344   
    2017-09-30                   295                     295              295   
    2017-10-01                   315                     315              315   
    2017-10-02                   350                     350              350   
    2017-10-03                   318                     318              318   
    2017-10-04                   346                     346              346   
    2017-10-05                   375                     375              375   
    2017-10-06                   364                     364              364   
    2017-10-07                   311                     311              311   
    2017-10-08                   281                     281              281   
    2017-10-09                   299                     299              299   
    2017-10-10                   142                     142              142   
    
                   ...      Initial Type Description  Initial Type Subgroup  \
    Scene_Date     ...                                                        
    2009-06-19     ...                             1                      1   
    2009-06-21     ...                             1                      1   
    2009-06-26     ...                             1                      1   
    2009-08-22     ...                             1                      1   
    2009-11-28     ...                             1                      1   
    2009-12-22     ...                             1                      1   
    2009-12-31     ...                             1                      1   
    2010-01-01     ...                             2                      2   
    2010-01-02     ...                             1                      1   
    2010-01-04     ...                             2                      2   
    2010-01-05     ...                             1                      1   
    2010-01-06     ...                             2                      2   
    2010-01-07     ...                             1                      1   
    2010-01-08     ...                             3                      3   
    2010-01-09     ...                             1                      1   
    2010-05-21     ...                             1                      1   
    2010-08-12     ...                             1                      1   
    2010-08-17     ...                             1                      1   
    2010-09-02     ...                             1                      1   
    2010-09-21     ...                             1                      1   
    2010-09-30     ...                             1                      1   
    2010-10-12     ...                             1                      1   
    2010-12-01     ...                             3                      3   
    2010-12-02     ...                             2                      2   
    2010-12-03     ...                             3                      3   
    2010-12-04     ...                             2                      2   
    2010-12-05     ...                             1                      1   
    2010-12-07     ...                             1                      1   
    2010-12-09     ...                             1                      1   
    2010-12-10     ...                             2                      2   
    ...            ...                           ...                    ...   
    2017-09-11     ...                           356                    356   
    2017-09-12     ...                           321                    321   
    2017-09-13     ...                           363                    363   
    2017-09-14     ...                           434                    434   
    2017-09-15     ...                           345                    345   
    2017-09-16     ...                           348                    348   
    2017-09-17     ...                           319                    319   
    2017-09-18     ...                           327                    327   
    2017-09-19     ...                           322                    322   
    2017-09-20     ...                           293                    293   
    2017-09-21     ...                           312                    312   
    2017-09-22     ...                           367                    367   
    2017-09-23     ...                           292                    292   
    2017-09-24     ...                           291                    291   
    2017-09-25     ...                           325                    325   
    2017-09-26     ...                           342                    342   
    2017-09-27     ...                           345                    345   
    2017-09-28     ...                           358                    358   
    2017-09-29     ...                           344                    344   
    2017-09-30     ...                           295                    295   
    2017-10-01     ...                           315                    315   
    2017-10-02     ...                           350                    350   
    2017-10-03     ...                           318                    318   
    2017-10-04     ...                           346                    346   
    2017-10-05     ...                           375                    375   
    2017-10-06     ...                           364                    364   
    2017-10-07     ...                           311                    311   
    2017-10-08     ...                           281                    281   
    2017-10-09     ...                           299                    299   
    2017-10-10     ...                           142                    142   
    
                Initial Type Group  At Scene Time  Event_timing  Scene_timing  \
    Scene_Date                                                                  
    2009-06-19                   1              1             1             1   
    2009-06-21                   1              1             1             1   
    2009-06-26                   1              1             1             1   
    2009-08-22                   1              1             1             1   
    2009-11-28                   1              1             1             1   
    2009-12-22                   1              1             1             1   
    2009-12-31                   1              1             1             1   
    2010-01-01                   2              2             2             2   
    2010-01-02                   1              1             1             1   
    2010-01-04                   2              2             2             2   
    2010-01-05                   1              1             1             1   
    2010-01-06                   2              2             2             2   
    2010-01-07                   1              1             1             1   
    2010-01-08                   3              3             3             3   
    2010-01-09                   1              1             1             1   
    2010-05-21                   1              1             1             1   
    2010-08-12                   1              1             1             1   
    2010-08-17                   1              1             1             1   
    2010-09-02                   1              1             1             1   
    2010-09-21                   1              1             1             1   
    2010-09-30                   1              1             1             1   
    2010-10-12                   1              1             1             1   
    2010-12-01                   3              3             3             3   
    2010-12-02                   2              2             2             2   
    2010-12-03                   3              3             3             3   
    2010-12-04                   2              2             2             2   
    2010-12-05                   1              1             1             1   
    2010-12-07                   1              1             1             1   
    2010-12-09                   1              1             1             1   
    2010-12-10                   2              2             2             2   
    ...                        ...            ...           ...           ...   
    2017-09-11                 356            356           356           356   
    2017-09-12                 321            321           321           321   
    2017-09-13                 363            363           363           363   
    2017-09-14                 434            434           434           434   
    2017-09-15                 345            345           345           345   
    2017-09-16                 348            348           348           348   
    2017-09-17                 319            319           319           319   
    2017-09-18                 327            327           327           327   
    2017-09-19                 322            322           322           322   
    2017-09-20                 293            293           293           293   
    2017-09-21                 312            312           312           312   
    2017-09-22                 367            367           367           367   
    2017-09-23                 292            292           292           292   
    2017-09-24                 291            291           291           291   
    2017-09-25                 325            325           325           325   
    2017-09-26                 342            342           342           342   
    2017-09-27                 345            345           345           345   
    2017-09-28                 358            358           358           358   
    2017-09-29                 344            344           344           344   
    2017-09-30                 295            295           295           295   
    2017-10-01                 315            315           315           315   
    2017-10-02                 350            350           350           350   
    2017-10-03                 318            318           318           318   
    2017-10-04                 346            346           346           346   
    2017-10-05                 375            375           375           375   
    2017-10-06                 364            364           364           364   
    2017-10-07                 311            311           311           311   
    2017-10-08                 281            281           281           281   
    2017-10-09                 299            299           299           299   
    2017-10-10                 142            142           142           142   
    
                response_time  Event_Date  Event_Time  Scene_Time  
    Scene_Date                                                     
    2009-06-19              1           1           1           1  
    2009-06-21              1           1           1           1  
    2009-06-26              1           1           1           1  
    2009-08-22              1           1           1           1  
    2009-11-28              1           1           1           1  
    2009-12-22              1           1           1           1  
    2009-12-31              1           1           1           1  
    2010-01-01              2           2           2           2  
    2010-01-02              1           1           1           1  
    2010-01-04              2           2           2           2  
    2010-01-05              1           1           1           1  
    2010-01-06              2           2           2           2  
    2010-01-07              1           1           1           1  
    2010-01-08              3           3           3           3  
    2010-01-09              1           1           1           1  
    2010-05-21              1           1           1           1  
    2010-08-12              1           1           1           1  
    2010-08-17              1           1           1           1  
    2010-09-02              1           1           1           1  
    2010-09-21              1           1           1           1  
    2010-09-30              1           1           1           1  
    2010-10-12              1           1           1           1  
    2010-12-01              3           3           3           3  
    2010-12-02              2           2           2           2  
    2010-12-03              3           3           3           3  
    2010-12-04              2           2           2           2  
    2010-12-05              1           1           1           1  
    2010-12-07              1           1           1           1  
    2010-12-09              1           1           1           1  
    2010-12-10              2           2           2           2  
    ...                   ...         ...         ...         ...  
    2017-09-11            356         356         356         356  
    2017-09-12            321         321         321         321  
    2017-09-13            363         363         363         363  
    2017-09-14            434         434         434         434  
    2017-09-15            345         345         345         345  
    2017-09-16            348         348         348         348  
    2017-09-17            319         319         319         319  
    2017-09-18            327         327         327         327  
    2017-09-19            322         322         322         322  
    2017-09-20            293         293         293         293  
    2017-09-21            312         312         312         312  
    2017-09-22            367         367         367         367  
    2017-09-23            292         292         292         292  
    2017-09-24            291         291         291         291  
    2017-09-25            325         325         325         325  
    2017-09-26            342         342         342         342  
    2017-09-27            345         345         345         345  
    2017-09-28            358         358         358         358  
    2017-09-29            344         344         344         344  
    2017-09-30            295         295         295         295  
    2017-10-01            315         315         315         315  
    2017-10-02            350         350         350         350  
    2017-10-03            318         318         318         318  
    2017-10-04            346         346         346         346  
    2017-10-05            375         375         375         375  
    2017-10-06            364         364         364         364  
    2017-10-07            311         311         311         311  
    2017-10-08            281         281         281         281  
    2017-10-09            299         299         299         299  
    2017-10-10            142         142         142         142  
    
    [1945 rows x 25 columns]>




```python
plt.plot(by_crime_group.index ,by_crime_group["Event Clearance Group"],color = 'blue')
plt.title("Count of crime across years")
fig_size = plt.rcParams["figure.figsize"]
fig_size = [14,10]

plt.rcParams["figure.figsize"] = fig_size
plt.show()
```


![png](output_19_0.png)


What happened between 2013 ans 2015? let's look at the data !


```python
#Looking at the data if that's true...
by_crime_group #set index first
by_crime_group[(by_crime_group.index.astype(str) > '2013-02-09') & (by_crime_group.index.astype(str) <= '2014-07-17')]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CAD CDW ID</th>
      <th>CAD Event Number</th>
      <th>General Offense Number</th>
      <th>Event Clearance Code</th>
      <th>Event Clearance Description</th>
      <th>Event Clearance SubGroup</th>
      <th>Event Clearance Group</th>
      <th>Event Clearance Date</th>
      <th>Hundred Block Location</th>
      <th>District/Sector</th>
      <th>...</th>
      <th>Initial Type Description</th>
      <th>Initial Type Subgroup</th>
      <th>Initial Type Group</th>
      <th>At Scene Time</th>
      <th>Event_timing</th>
      <th>Scene_timing</th>
      <th>response_time</th>
      <th>Event_Date</th>
      <th>Event_Time</th>
      <th>Scene_Time</th>
    </tr>
    <tr>
      <th>Scene_Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2013-08-09</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2014-01-12</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2014-02-15</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2014-07-13</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2014-07-14</th>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>...</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2014-07-15</th>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>...</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2014-07-16</th>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>...</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2014-07-17</th>
      <td>255</td>
      <td>255</td>
      <td>255</td>
      <td>239</td>
      <td>239</td>
      <td>239</td>
      <td>239</td>
      <td>238</td>
      <td>255</td>
      <td>255</td>
      <td>...</td>
      <td>255</td>
      <td>255</td>
      <td>255</td>
      <td>255</td>
      <td>238</td>
      <td>255</td>
      <td>238</td>
      <td>238</td>
      <td>238</td>
      <td>255</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 25 columns</p>
</div>



**What are the top most crime description??**


```python
crime_data["Event Clearance Description"].value_counts()[0:10] #Top Crime types
```




    SUSPICIOUS PERSON                                162841
    DISTURBANCE, OTHER                               140965
    TRAFFIC (MOVING) VIOLATION                       106723
    PARKING VIOLATION (EXCEPT ABANDONED VEHICLES)    104212
    LIQUOR VIOLATION - INTOXICATED PERSON             59213
    SUSPICIOUS VEHICLE                                47912
    THEFT - CAR PROWL                                 44446
    MOTOR VEHICLE COLLISION                           40687
    MISCHIEF, NUISANCE COMPLAINTS                     40585
    THEFT - MISCELLANEOUS                             40242
    Name: Event Clearance Description, dtype: int64




```python
def plotdat(data,cat):
    l=data.groupby(cat).size().sort_values(ascending = True)
    
    fig=plt.figure(figsize=(20,10))
    plt.yticks(fontsize=8)
    l.plot(kind='bar',fontsize=12,color='k')
    plt.xlabel('Crime types')
    plt.ylabel('Number of reports',fontsize=16)
    plt.savefig("Group_Frequency.png")
   
plotdat(crime_data,'Event Clearance Group')
plt.show()
```


![png](output_24_0.png)


**Our first inclination was to distill the crimes into smaller, more meaningful categories than was provided in the dataset. 
Dealing with all the crime granularities is cumbersome and hard to get inference.**
These categories are:
+ <font color = blue>**Disturbance/Traffic**</font>
+ <font color = green>**Property**</font>
+ <font color = red>**Miscellaneous**</font>
+ <font color = purple>**Health/Drug**</font>
+ <font color = blue+yellow>**Sexual/Harassment**</font>
+ <font color = green+blue>**Emergency/Violent**</font>





```python
#First lets map with only Initials..Who wants to type all the word?
crime_type_map  = {"ACCIDENT INVESTIGATION": "D",
"ANIMAL COMPLAINTS": "D",
"ARREST": "M",
"ASSAULTS": "E",
"AUTO THEFTS": "P",
"BEHAVIORAL HEALTH": "H",
"BIKE": "P",
"BURGLARY": "P",
"CAR PROWL": "S",
"DISTURBANCES": "D",
"DRIVE BY (NO INJURY)": "D",
"FAILURE TO REGISTER (SEX OFFENDER)": "M",
"FALSE ALACAD": "M",
"FALSE ALARMS": "M",
"FRAUD CALLS": "D",
"HARBOR CALLS": "E",
"HAZARDS": "M",
"HOMICIDE": "E",
"LEWD CONDUCT": "S",
"LIQUOR VIOLATIONS": "H",
"MENTAL HEALTH": "H",
"MISCELLANEOUS MISDEMEANORS": "M",
"MOTOR VEHICLE COLLISION INVESTIGATION": "D",
"NARCOTICS COMPLAINTS": "H",
"NUISANCE, MISCHIEF": "M",
"NUISANCE, MISCHIEF ": "M",
"OTHER PROPERTY": "P",
"OTHER VICE": "M",
"PERSON DOWN/INJURY": "E",
"PERSONS - LOST, FOUND, MISSING": "E",
"PROPERTY - MISSING, FOUND": "E",
"PROPERTY DAMAGE": "P",
"PROSTITUTION": "S",
"PROWLER": "S",
"PUBLIC GATHERINGS": "D",
"RECKLESS BURNING": "P",
"ROBBERY": "P",
"SHOPLIFTING": "P",
"SUSPICIOUS CIRCUMSTANCES": "D",
"THREATS, HARASSMENT": "S",
"TRAFFIC RELATED CALLS": "D",
"TRESPASS": "P",
"VICE CALLS": "M",
"WEAPONS CALLS": "E"}
```


```python
crime_data["crime_group"] = crime_data["Event Clearance Group"].map(crime_type_map)
```


```python
#Now here, should type the full word..
crime_data["Event Clearance Group"].isnull



group_mapping = {"D":"Disturbance/ Traffic",
"E":"Emergency/ Violent",
"H":"Health/Drug",
"P":"Property",
"M": "Miscellaneous",
"S":"Sexual/Harassment"}

crime_data["crime_group"] = crime_data["crime_group"].map(group_mapping)
#Count of crime groups
crime_data["crime_group"].value_counts()

```




    Disturbance/ Traffic    777939
    Property                233790
    Miscellaneous           147620
    Health/Drug             137000
    Sexual/Harassment        74139
    Emergency/ Violent       62891
    Name: crime_group, dtype: int64



*Let's see the Graphics....*


```python
g = sns.countplot(x = "crime_group",data = crime_data)
g.figure.set_size_inches(12,8)
sns.despine()
g.set(xlabel='Crime types grouped', ylabel='Total count of crime groups')
g.figure.savefig('crime_group.png')
plt.show()
```

    /anaconda/lib/python3.6/site-packages/seaborn/categorical.py:1428: FutureWarning: remove_na is deprecated and is a private function. Do not use.
      stat_data = remove_na(group_data)



![png](output_30_1.png)



```python
#What are the top five disricts?
crime_data["District/Sector"].value_counts()
sns.countplot(x=crime_data["District/Sector"],data = crime_data)
plt.show()
```

    /anaconda/lib/python3.6/site-packages/seaborn/categorical.py:1428: FutureWarning: remove_na is deprecated and is a private function. Do not use.
      stat_data = remove_na(group_data)



![png](output_31_1.png)



```python
#Which District have high number of Violent Crimes
sns.countplot(x = crime_data[crime_data["crime_group"]=="Emergency/ Violent"]["District/Sector"],data = crime_data)
sns.despine()

#sns.set(style='ticks')


plt.tight_layout()


plt.show()
```

    /anaconda/lib/python3.6/site-packages/seaborn/categorical.py:1428: FutureWarning: remove_na is deprecated and is a private function. Do not use.
      stat_data = remove_na(group_data)



![png](output_32_1.png)


###### Analyzing crime type by Month


```python
#Getting Months
crime_data["month"] =[list_month.month for list_month in pd.to_datetime(crime_data["Event_Date"])]

map_month = {1.0:'Jan',2.0:'Feb',3.0:'March',4.0:'April',5.0:'May',6.0:'June',7.0:'July',8.0:'Aug',9.0:'Sept',10.0:'Oct',11.0:'Nov',12.0:'Dec'}

crime_data["month"] = crime_data["month"].map(map_month)

```


```python
type(crime_data["Scene_Time"])
```




    pandas.core.series.Series




```python
#Getting hours
crime_data["Scene_Time"] = crime_data["Scene_Time"].astype(str)
crime_data["Hour of Day"] = pd.to_datetime(crime_data["Scene_Time"]).apply(lambda time: time.hour)
crime_data["Hour of Day"]

```




    0           NaN
    1           NaN
    2           NaN
    3           NaN
    4           NaN
    5           NaN
    6           NaN
    7           NaN
    8           NaN
    9           NaN
    10          NaN
    11          NaN
    12          NaN
    13          NaN
    14          NaN
    15          NaN
    16          NaN
    17          NaN
    18          NaN
    19          NaN
    20          NaN
    21          NaN
    22          NaN
    23          NaN
    24          NaN
    25          NaN
    26          NaN
    27          NaN
    28          NaN
    29          NaN
               ... 
    1444234    18.0
    1444235    18.0
    1444236    17.0
    1444237     NaN
    1444238     NaN
    1444239     NaN
    1444240    19.0
    1444241     NaN
    1444242     NaN
    1444243     NaN
    1444244     NaN
    1444245    19.0
    1444246    20.0
    1444247     NaN
    1444248    16.0
    1444249     NaN
    1444250     NaN
    1444251     NaN
    1444252     NaN
    1444253     NaN
    1444254    16.0
    1444255    16.0
    1444256    16.0
    1444257     NaN
    1444258    22.0
    1444259     NaN
    1444260     1.0
    1444261     NaN
    1444262     0.0
    1444263    23.0
    Name: Hour of Day, Length: 1444264, dtype: float64




```python
#Getting Day of Week
crime_data["Day of week"] = pd.to_datetime(crime_data["Scene_Date"]).apply(lambda time: time.dayofweek)

```


```python
#Mapping to meaningful words
day_map = {0:'Mon',1:'Tue',2:'Wed',3:'Thu',4:'Fri',5:'Sat',6:'Sun'}



crime_data["Day of week"] = crime_data["Day of week"].map(day_map)


#by_dayHour = crime_data.groupby(by=['Day of week','Hour of Day']).count()['Event Clearance Group']
```


```python
Time_mapped = {0 :"12AM",1:"1AM",2:"2AM",3:"3AM",4:"4AM",5:"5AM",6:"6AM",7:"7AM",8:"8AM",9:"9AM",10:"10AM",11:"11AM",12:"12PM",13:"1PM",14:"2PM",15:"3PM",16:"4PM",17:"5PM",18:"6PM",19:"7PM",20:"8PM",21:"9PM",22:"10PM",23:"11PM"}
crime_data["Hour of Day"] = crime_data["Hour of Day"].map(Time_mapped)
crime_data["Hour of Day"]

```




    0           NaN
    1           NaN
    2           NaN
    3           NaN
    4           NaN
    5           NaN
    6           NaN
    7           NaN
    8           NaN
    9           NaN
    10          NaN
    11          NaN
    12          NaN
    13          NaN
    14          NaN
    15          NaN
    16          NaN
    17          NaN
    18          NaN
    19          NaN
    20          NaN
    21          NaN
    22          NaN
    23          NaN
    24          NaN
    25          NaN
    26          NaN
    27          NaN
    28          NaN
    29          NaN
               ... 
    1444234     6PM
    1444235     6PM
    1444236     5PM
    1444237     NaN
    1444238     NaN
    1444239     NaN
    1444240     7PM
    1444241     NaN
    1444242     NaN
    1444243     NaN
    1444244     NaN
    1444245     7PM
    1444246     8PM
    1444247     NaN
    1444248     4PM
    1444249     NaN
    1444250     NaN
    1444251     NaN
    1444252     NaN
    1444253     NaN
    1444254     4PM
    1444255     4PM
    1444256     4PM
    1444257     NaN
    1444258    10PM
    1444259     NaN
    1444260     1AM
    1444261     NaN
    1444262    12AM
    1444263    11PM
    Name: Hour of Day, Length: 1444264, dtype: object




```python
by_dayHour = crime_data.groupby(by=['Day of week','Hour of Day']).count()['Event Clearance Group']
by_dayHour = by_dayHour.unstack()
by_dayHour

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Hour of Day</th>
      <th>0.0</th>
      <th>1.0</th>
      <th>2.0</th>
      <th>3.0</th>
      <th>4.0</th>
      <th>5.0</th>
      <th>6.0</th>
      <th>7.0</th>
      <th>8.0</th>
      <th>9.0</th>
      <th>...</th>
      <th>14.0</th>
      <th>15.0</th>
      <th>16.0</th>
      <th>17.0</th>
      <th>18.0</th>
      <th>19.0</th>
      <th>20.0</th>
      <th>21.0</th>
      <th>22.0</th>
      <th>23.0</th>
    </tr>
    <tr>
      <th>Day of week</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Fri</th>
      <td>2027</td>
      <td>1753</td>
      <td>1369</td>
      <td>677</td>
      <td>1096</td>
      <td>845</td>
      <td>1056</td>
      <td>1840</td>
      <td>1970</td>
      <td>2398</td>
      <td>...</td>
      <td>3088</td>
      <td>3259</td>
      <td>3347</td>
      <td>3145</td>
      <td>2621</td>
      <td>2184</td>
      <td>3912</td>
      <td>3195</td>
      <td>2920</td>
      <td>2667</td>
    </tr>
    <tr>
      <th>Mon</th>
      <td>1950</td>
      <td>1704</td>
      <td>1346</td>
      <td>823</td>
      <td>1389</td>
      <td>1058</td>
      <td>1202</td>
      <td>2086</td>
      <td>2475</td>
      <td>2658</td>
      <td>...</td>
      <td>3462</td>
      <td>3549</td>
      <td>3426</td>
      <td>3285</td>
      <td>2685</td>
      <td>2225</td>
      <td>3905</td>
      <td>2908</td>
      <td>2373</td>
      <td>1964</td>
    </tr>
    <tr>
      <th>Sat</th>
      <td>2520</td>
      <td>2636</td>
      <td>2219</td>
      <td>1036</td>
      <td>1500</td>
      <td>1028</td>
      <td>925</td>
      <td>1349</td>
      <td>1528</td>
      <td>1838</td>
      <td>...</td>
      <td>2775</td>
      <td>2880</td>
      <td>2708</td>
      <td>2778</td>
      <td>2460</td>
      <td>1980</td>
      <td>3794</td>
      <td>3839</td>
      <td>3858</td>
      <td>3313</td>
    </tr>
    <tr>
      <th>Sun</th>
      <td>2968</td>
      <td>3144</td>
      <td>2499</td>
      <td>1282</td>
      <td>1781</td>
      <td>1093</td>
      <td>1026</td>
      <td>1372</td>
      <td>1529</td>
      <td>1797</td>
      <td>...</td>
      <td>2827</td>
      <td>2820</td>
      <td>2787</td>
      <td>2760</td>
      <td>2366</td>
      <td>2064</td>
      <td>3699</td>
      <td>3363</td>
      <td>3009</td>
      <td>2372</td>
    </tr>
    <tr>
      <th>Thu</th>
      <td>1728</td>
      <td>1550</td>
      <td>1295</td>
      <td>645</td>
      <td>1124</td>
      <td>890</td>
      <td>1140</td>
      <td>1915</td>
      <td>2132</td>
      <td>2540</td>
      <td>...</td>
      <td>3131</td>
      <td>3500</td>
      <td>3314</td>
      <td>3188</td>
      <td>2714</td>
      <td>2079</td>
      <td>3895</td>
      <td>3558</td>
      <td>3179</td>
      <td>2386</td>
    </tr>
    <tr>
      <th>Tue</th>
      <td>1566</td>
      <td>1449</td>
      <td>1165</td>
      <td>677</td>
      <td>1142</td>
      <td>973</td>
      <td>1164</td>
      <td>1833</td>
      <td>2282</td>
      <td>2515</td>
      <td>...</td>
      <td>3256</td>
      <td>3539</td>
      <td>3441</td>
      <td>3362</td>
      <td>2747</td>
      <td>2124</td>
      <td>3972</td>
      <td>3581</td>
      <td>2940</td>
      <td>2250</td>
    </tr>
    <tr>
      <th>Wed</th>
      <td>1770</td>
      <td>1557</td>
      <td>1121</td>
      <td>655</td>
      <td>1094</td>
      <td>895</td>
      <td>1128</td>
      <td>1940</td>
      <td>2179</td>
      <td>2475</td>
      <td>...</td>
      <td>3258</td>
      <td>3359</td>
      <td>3440</td>
      <td>3359</td>
      <td>2750</td>
      <td>2046</td>
      <td>3696</td>
      <td>2916</td>
      <td>2413</td>
      <td>2047</td>
    </tr>
  </tbody>
</table>
<p>7 rows × 24 columns</p>
</div>




```python
by_dayHour.reindex()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Hour of Day</th>
      <th>0.0</th>
      <th>1.0</th>
      <th>2.0</th>
      <th>3.0</th>
      <th>4.0</th>
      <th>5.0</th>
      <th>6.0</th>
      <th>7.0</th>
      <th>8.0</th>
      <th>9.0</th>
      <th>...</th>
      <th>14.0</th>
      <th>15.0</th>
      <th>16.0</th>
      <th>17.0</th>
      <th>18.0</th>
      <th>19.0</th>
      <th>20.0</th>
      <th>21.0</th>
      <th>22.0</th>
      <th>23.0</th>
    </tr>
    <tr>
      <th>Day of week</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Fri</th>
      <td>2027</td>
      <td>1753</td>
      <td>1369</td>
      <td>677</td>
      <td>1096</td>
      <td>845</td>
      <td>1056</td>
      <td>1840</td>
      <td>1970</td>
      <td>2398</td>
      <td>...</td>
      <td>3088</td>
      <td>3259</td>
      <td>3347</td>
      <td>3145</td>
      <td>2621</td>
      <td>2184</td>
      <td>3912</td>
      <td>3195</td>
      <td>2920</td>
      <td>2667</td>
    </tr>
    <tr>
      <th>Mon</th>
      <td>1950</td>
      <td>1704</td>
      <td>1346</td>
      <td>823</td>
      <td>1389</td>
      <td>1058</td>
      <td>1202</td>
      <td>2086</td>
      <td>2475</td>
      <td>2658</td>
      <td>...</td>
      <td>3462</td>
      <td>3549</td>
      <td>3426</td>
      <td>3285</td>
      <td>2685</td>
      <td>2225</td>
      <td>3905</td>
      <td>2908</td>
      <td>2373</td>
      <td>1964</td>
    </tr>
    <tr>
      <th>Sat</th>
      <td>2520</td>
      <td>2636</td>
      <td>2219</td>
      <td>1036</td>
      <td>1500</td>
      <td>1028</td>
      <td>925</td>
      <td>1349</td>
      <td>1528</td>
      <td>1838</td>
      <td>...</td>
      <td>2775</td>
      <td>2880</td>
      <td>2708</td>
      <td>2778</td>
      <td>2460</td>
      <td>1980</td>
      <td>3794</td>
      <td>3839</td>
      <td>3858</td>
      <td>3313</td>
    </tr>
    <tr>
      <th>Sun</th>
      <td>2968</td>
      <td>3144</td>
      <td>2499</td>
      <td>1282</td>
      <td>1781</td>
      <td>1093</td>
      <td>1026</td>
      <td>1372</td>
      <td>1529</td>
      <td>1797</td>
      <td>...</td>
      <td>2827</td>
      <td>2820</td>
      <td>2787</td>
      <td>2760</td>
      <td>2366</td>
      <td>2064</td>
      <td>3699</td>
      <td>3363</td>
      <td>3009</td>
      <td>2372</td>
    </tr>
    <tr>
      <th>Thu</th>
      <td>1728</td>
      <td>1550</td>
      <td>1295</td>
      <td>645</td>
      <td>1124</td>
      <td>890</td>
      <td>1140</td>
      <td>1915</td>
      <td>2132</td>
      <td>2540</td>
      <td>...</td>
      <td>3131</td>
      <td>3500</td>
      <td>3314</td>
      <td>3188</td>
      <td>2714</td>
      <td>2079</td>
      <td>3895</td>
      <td>3558</td>
      <td>3179</td>
      <td>2386</td>
    </tr>
    <tr>
      <th>Tue</th>
      <td>1566</td>
      <td>1449</td>
      <td>1165</td>
      <td>677</td>
      <td>1142</td>
      <td>973</td>
      <td>1164</td>
      <td>1833</td>
      <td>2282</td>
      <td>2515</td>
      <td>...</td>
      <td>3256</td>
      <td>3539</td>
      <td>3441</td>
      <td>3362</td>
      <td>2747</td>
      <td>2124</td>
      <td>3972</td>
      <td>3581</td>
      <td>2940</td>
      <td>2250</td>
    </tr>
    <tr>
      <th>Wed</th>
      <td>1770</td>
      <td>1557</td>
      <td>1121</td>
      <td>655</td>
      <td>1094</td>
      <td>895</td>
      <td>1128</td>
      <td>1940</td>
      <td>2179</td>
      <td>2475</td>
      <td>...</td>
      <td>3258</td>
      <td>3359</td>
      <td>3440</td>
      <td>3359</td>
      <td>2750</td>
      <td>2046</td>
      <td>3696</td>
      <td>2916</td>
      <td>2413</td>
      <td>2047</td>
    </tr>
  </tbody>
</table>
<p>7 rows × 24 columns</p>
</div>




```python
plt.figure(figsize=(16,8))
crime_map = sns.heatmap(by_dayHour,cbar_kws={'label': 'Number of 911 Calls Grouped'}) #Use Scene Time 
crime_map

crime_map.set_title('911 Call frequency Heatmap for Hours of Day')
crime_map.figure.savefig("Crime_Group_frequency_latest.png")

plt.show()
%matplotlib inline
```


![png](output_42_0.png)


*Clearly we can see PMs are more prone to have more Calls.


```python
by_month = crime_data.groupby(by=['Day of week','month']).count()['Event Clearance Group']
by_month.reset_index()
by_month = by_month.unstack()
```


```python
by_month.set_index(["Jan","Feb","March","April","May","June","July","Aug","Sept","Oct","Nov","Dec"])
by_month.reindex(["Jan","Feb","March","April","May","June","July","Aug","Sept","Oct","Nov","Dec"])
by_month

plt.figure(figsize=(12,6))

crime_map_month = sns.heatmap(by_month,cbar_kws={'label': 'Number of 911 Calls'})
crime_map_month

crime_map_month.set_title('911 Call frequency Heatmap for day of Month')
crime_map_month.figure.savefig("Crime_frequency_month.png")
plt.show()
%matplotlib inline
```


![png](output_45_0.png)



```python
group=crime_data[crime_data['crime_group']=='Emergency/ Violent']
c = group['Event Clearance Description'].value_counts()
c.sort_values(ascending=False)
c.head(10)
```




    ASSAULTS, OTHER                                                            24188
    PROPERTY - FOUND (FOLLOW UP TO SPD CASE)                                   13905
    CASUALTY (NON CRIMINAL/TRAFFIC) - MAN DOWN, SICK PERSONS, INJURED, DOA)     8314
    MISSING PERSON                                                              5635
    PERSON WITH A GUN                                                           2152
    PROPERTY - MISSING                                                          1896
    CASUALTY - DRUG RELATED (OVERDOSE, OTHER)                                   1551
    PERSON WITH A WEAPON (NOT GUN)                                              1420
    FOUND PERSON                                                                1033
    ASSAULTS, FIREARM INVOLVED                                                   763
    Name: Event Clearance Description, dtype: int64




```python
group=crime_data[crime_data['crime_group']=='Emergency/ Violent']
by_month_violent = group.groupby(by=['Day of week','month']).count()["Event Clearance Group"]
by_month_violent.reset_index()
by_month_violent = by_month_violent.unstack()
by_month_violent
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>April</th>
      <th>Aug</th>
      <th>Dec</th>
      <th>Feb</th>
      <th>Jan</th>
      <th>July</th>
      <th>June</th>
      <th>March</th>
      <th>May</th>
      <th>Nov</th>
      <th>Oct</th>
      <th>Sept</th>
    </tr>
    <tr>
      <th>Day of week</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Fri</th>
      <td>273</td>
      <td>443</td>
      <td>320</td>
      <td>295</td>
      <td>332</td>
      <td>439</td>
      <td>327</td>
      <td>264</td>
      <td>362</td>
      <td>317</td>
      <td>411</td>
      <td>529</td>
    </tr>
    <tr>
      <th>Mon</th>
      <td>256</td>
      <td>505</td>
      <td>362</td>
      <td>248</td>
      <td>324</td>
      <td>362</td>
      <td>341</td>
      <td>260</td>
      <td>378</td>
      <td>325</td>
      <td>448</td>
      <td>463</td>
    </tr>
    <tr>
      <th>Sat</th>
      <td>317</td>
      <td>513</td>
      <td>333</td>
      <td>306</td>
      <td>296</td>
      <td>484</td>
      <td>328</td>
      <td>280</td>
      <td>382</td>
      <td>381</td>
      <td>399</td>
      <td>566</td>
    </tr>
    <tr>
      <th>Sun</th>
      <td>317</td>
      <td>498</td>
      <td>354</td>
      <td>300</td>
      <td>299</td>
      <td>469</td>
      <td>348</td>
      <td>246</td>
      <td>344</td>
      <td>386</td>
      <td>430</td>
      <td>593</td>
    </tr>
    <tr>
      <th>Thu</th>
      <td>273</td>
      <td>433</td>
      <td>315</td>
      <td>279</td>
      <td>288</td>
      <td>367</td>
      <td>353</td>
      <td>314</td>
      <td>327</td>
      <td>366</td>
      <td>389</td>
      <td>484</td>
    </tr>
    <tr>
      <th>Tue</th>
      <td>268</td>
      <td>475</td>
      <td>351</td>
      <td>284</td>
      <td>354</td>
      <td>362</td>
      <td>355</td>
      <td>288</td>
      <td>350</td>
      <td>351</td>
      <td>359</td>
      <td>522</td>
    </tr>
    <tr>
      <th>Wed</th>
      <td>272</td>
      <td>491</td>
      <td>329</td>
      <td>282</td>
      <td>303</td>
      <td>418</td>
      <td>354</td>
      <td>320</td>
      <td>319</td>
      <td>340</td>
      <td>379</td>
      <td>443</td>
    </tr>
  </tbody>
</table>
</div>




```python
by_month_violent.set_index(["Jan","Feb","March","April","May","June","July","Aug","Sept","Oct","Nov","Dec"])


plt.figure(figsize=(12,6))

crime_map_month_violent = sns.heatmap(by_month_violent,cbar_kws={'label': 'Number of 911 Calls'})
crime_map_month_violent

crime_map_month_violent.set_title('911 [Violent/Emergency only]  Call frequency Heatmap for day of Month')
crime_map_month_violent.figure.savefig("Crime_frequency_month_violent.png")
plt.show()
%matplotlib inline
```


![png](output_48_0.png)



```python
gun_related = ["PERSON WITH A GUN","ASSAULTS, FIREARM INVOLVED"]
gun = pd.DataFrame(crime_data[(crime_data["Event Clearance Description"]=="ASSAULTS, FIREARM INVOLVED") | (crime_data["Event Clearance Description"]=="PERSON WITH A GUN")])
gun["year"] = [x.year for x in pd.to_datetime(gun["Scene_Date"])]

```


```python
from bokeh.io import output_file, output_notebook, show
from bokeh.models import (
  GMapPlot, GMapOptions, ColumnDataSource, Circle, LogColorMapper, BasicTicker, ColorBar,
    DataRange1d, PanTool, WheelZoomTool, BoxSelectTool
)
from bokeh.models.mappers import ColorMapper, LinearColorMapper
from bokeh.palettes import Viridis5


map_options = GMapOptions(lat=47.5982623, lng=-122.3415519, map_type="roadmap", zoom=6) #latitutde and longitude of seattle

plot = GMapPlot(
    x_range=DataRange1d(), y_range=DataRange1d(), map_options=map_options
)
plot.title.text = "Gun related crimes on Different location Seattle-City"

# For GMaps to function, Google requires you obtain and enable an API key:
#
#     https://developers.google.com/maps/documentation/javascript/get-api-key
#
# Replace the value below with your personal API key:
plot.api_key = "AIzaSyBSbve1oDm-jmjK0OkPndn2o7U9obp9yfQ"

source = ColumnDataSource(
    data=dict(
        lat=gun["Latitude"],
        lon=gun["Longitude"],
        size=gun['year'],
        color=gun['year']
    )
)

color_mapper = LinearColorMapper(palette=Viridis5)

circle = Circle(x="lon", y="lat", fill_alpha=0.7, line_color='red')
plot.add_glyph(source, circle)

color_bar = ColorBar(color_mapper=color_mapper, ticker=BasicTicker(),
                     label_standoff=12, border_line_color=None, location=(0,0))
plot.add_layout(color_bar, 'right')

plot.add_tools(PanTool(), WheelZoomTool(), BoxSelectTool())
output_file("gmap_plot.html")
output_notebook()

show(plot)

#You Might need to Zoom it and orient it properly
```

    INFO:bokeh.core.state:Session output file 'gmap_plot.html' already exists, will be overwritten.




    <div class="bk-root">
        <a href="http://bokeh.pydata.org" target="_blank" class="bk-logo bk-logo-small bk-logo-notebook"></a>
        <span id="7f02cdcf-89ba-42d9-bcc0-2d985efba5a0">Loading BokehJS ...</span>
    </div>







    <div class="bk-root">
        <div class="bk-plotdiv" id="44a7e710-166f-4242-9a17-ac86c3d4a119"></div>
    </div>
<script type="text/javascript">
  
  (function(global) {
    function now() {
      return new Date();
    }
  
    var force = false;
  
    if (typeof (window._bokeh_onload_callbacks) === "undefined" || force === true) {
      window._bokeh_onload_callbacks = [];
      window._bokeh_is_loading = undefined;
    }
  
  
    
    if (typeof (window._bokeh_timeout) === "undefined" || force === true) {
      window._bokeh_timeout = Date.now() + 0;
      window._bokeh_failed_load = false;
    }
  
    var NB_LOAD_WARNING = {'data': {'text/html':
       "<div style='background-color: #fdd'>\n"+
       "<p>\n"+
       "BokehJS does not appear to have successfully loaded. If loading BokehJS from CDN, this \n"+
       "may be due to a slow or bad network connection. Possible fixes:\n"+
       "</p>\n"+
       "<ul>\n"+
       "<li>re-rerun `output_notebook()` to attempt to load from CDN again, or</li>\n"+
       "<li>use INLINE resources instead, as so:</li>\n"+
       "</ul>\n"+
       "<code>\n"+
       "from bokeh.resources import INLINE\n"+
       "output_notebook(resources=INLINE)\n"+
       "</code>\n"+
       "</div>"}};
  
    function display_loaded() {
      if (window.Bokeh !== undefined) {
        document.getElementById("44a7e710-166f-4242-9a17-ac86c3d4a119").textContent = "BokehJS successfully loaded.";
      } else if (Date.now() < window._bokeh_timeout) {
        setTimeout(display_loaded, 100)
      }
    }
  
    function run_callbacks() {
      window._bokeh_onload_callbacks.forEach(function(callback) { callback() });
      delete window._bokeh_onload_callbacks
      console.info("Bokeh: all callbacks have finished");
    }
  
    function load_libs(js_urls, callback) {
      window._bokeh_onload_callbacks.push(callback);
      if (window._bokeh_is_loading > 0) {
        console.log("Bokeh: BokehJS is being loaded, scheduling callback at", now());
        return null;
      }
      if (js_urls == null || js_urls.length === 0) {
        run_callbacks();
        return null;
      }
      console.log("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
      window._bokeh_is_loading = js_urls.length;
      for (var i = 0; i < js_urls.length; i++) {
        var url = js_urls[i];
        var s = document.createElement('script');
        s.src = url;
        s.async = false;
        s.onreadystatechange = s.onload = function() {
          window._bokeh_is_loading--;
          if (window._bokeh_is_loading === 0) {
            console.log("Bokeh: all BokehJS libraries loaded");
            run_callbacks()
          }
        };
        s.onerror = function() {
          console.warn("failed to load library " + url);
        };
        console.log("Bokeh: injecting script tag for BokehJS library: ", url);
        document.getElementsByTagName("head")[0].appendChild(s);
      }
    };var element = document.getElementById("44a7e710-166f-4242-9a17-ac86c3d4a119");
    if (element == null) {
      console.log("Bokeh: ERROR: autoload.js configured with elementid '44a7e710-166f-4242-9a17-ac86c3d4a119' but no matching script tag was found. ")
      return false;
    }
  
    var js_urls = [];
  
    var inline_js = [
      function(Bokeh) {
        (function() {
          var fn = function() {
            var docs_json = {"8fa69125-de0a-43bc-8cf4-cc82c74ec469":{"roots":{"references":[{"attributes":{"active_drag":"auto","active_scroll":"auto","active_tap":"auto","tools":[{"id":"da8d4ee7-6d61-4aef-83a5-813feed9fd46","type":"PanTool"},{"id":"7c33a37b-8f6b-436b-95c7-f59ac55ee24c","type":"WheelZoomTool"},{"id":"c47d42b6-b7ca-4cef-b6de-ae31522ed0d7","type":"BoxSelectTool"}]},"id":"62fb8ed0-f32d-4b15-92a2-ff1a2c25c1fa","type":"Toolbar"},{"attributes":{"callback":null},"id":"3049f334-1081-4f48-af12-fa402c224318","type":"DataRange1d"},{"attributes":{"callback":null,"overlay":{"id":"a4373d93-833b-473f-a967-0f64bc7d8995","type":"BoxAnnotation"},"plot":{"id":"3c47ed94-c527-4ee4-962c-3b8edca17ee5","type":"GMapPlot"}},"id":"c47d42b6-b7ca-4cef-b6de-ae31522ed0d7","type":"BoxSelectTool"},{"attributes":{"color_mapper":{"id":"97ce91ef-ca61-41cf-9437-bd8e066b1bd9","type":"LinearColorMapper"},"formatter":{"id":"8e357aa5-e5c6-49b9-99a5-cb79c69dca5d","type":"BasicTickFormatter"},"label_standoff":12,"location":[0,0],"plot":{"id":"3c47ed94-c527-4ee4-962c-3b8edca17ee5","type":"GMapPlot"},"ticker":{"id":"72fba024-981e-4e97-b487-cdd272851d88","type":"BasicTicker"}},"id":"7b57152f-8a19-40b7-866d-cc42e9613162","type":"ColorBar"},{"attributes":{"api_key":"AIzaSyBSbve1oDm-jmjK0OkPndn2o7U9obp9yfQ","map_options":{"lat":47.5982623,"lng":-122.3415519,"map_type":"roadmap","zoom":6},"renderers":[{"id":"a0fa9272-8c77-403b-af87-43d6cd5b9fe1","type":"GlyphRenderer"},{"id":"7b57152f-8a19-40b7-866d-cc42e9613162","type":"ColorBar"},{"id":"a4373d93-833b-473f-a967-0f64bc7d8995","type":"BoxAnnotation"}],"right":[{"id":"7b57152f-8a19-40b7-866d-cc42e9613162","type":"ColorBar"}],"title":{"id":"20360560-6745-4346-a1ff-01172e85e862","type":"Title"},"tool_events":{"id":"d65be3e0-5aeb-49df-9a73-2a0f927fe184","type":"ToolEvents"},"toolbar":{"id":"62fb8ed0-f32d-4b15-92a2-ff1a2c25c1fa","type":"Toolbar"},"x_range":{"id":"3049f334-1081-4f48-af12-fa402c224318","type":"DataRange1d"},"y_range":{"id":"bc800d3b-ce9c-4a61-9f51-94eb462c4bda","type":"DataRange1d"}},"id":"3c47ed94-c527-4ee4-962c-3b8edca17ee5","type":"GMapPlot"},{"attributes":{"plot":{"id":"3c47ed94-c527-4ee4-962c-3b8edca17ee5","type":"GMapPlot"}},"id":"7c33a37b-8f6b-436b-95c7-f59ac55ee24c","type":"WheelZoomTool"},{"attributes":{"data_source":{"id":"588f4be0-df1a-49a7-b365-dbbd443bf641","type":"ColumnDataSource"},"glyph":{"id":"76e214c8-3af2-4860-a56f-f2a428228d01","type":"Circle"},"hover_glyph":null,"nonselection_glyph":null,"selection_glyph":null},"id":"a0fa9272-8c77-403b-af87-43d6cd5b9fe1","type":"GlyphRenderer"},{"attributes":{"callback":null},"id":"bc800d3b-ce9c-4a61-9f51-94eb462c4bda","type":"DataRange1d"},{"attributes":{"palette":["#440154","#3B518A","#208F8C","#5BC862","#FDE724"]},"id":"97ce91ef-ca61-41cf-9437-bd8e066b1bd9","type":"LinearColorMapper"},{"attributes":{},"id":"72fba024-981e-4e97-b487-cdd272851d88","type":"BasicTicker"},{"attributes":{"callback":null,"column_names":["lat","lon","size","color"],"data":{"color":{"__ndarray__":"AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAfJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAcJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABsn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAICfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAAAA+H8AAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAgJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAISfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAACEn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAAPh/AAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAhJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAbJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAGyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAGyfQAAAAAAAAPh/AAAAAABsn0AAAAAAAICfQAAAAAAAbJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAhJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAdJ9AAAAAAABwn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAhJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAhJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAaJ9AAAAAAABon0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAISfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQA==","dtype":"float64","shape":[2915]},"lat":{"__ndarray__":"R93WL/vOR0Covg/hQc9HQK4q6cvMzEdARJH4WQjVR0AIAI49e9pHQJaAovZ+wkdAJlJT+JfNR0BirgqposhHQC3CsnF7ykdAGdFpItvdR0AGNzsak8JHQKYts6pTy0dAvfv/EprBR0Cow3/Es85HQE9JfSmhz0dAwWSoX6nNR0Ci2i7U5M5HQG7ED6Wo1EdAtRCWEVTNR0BQ+6jkbsNHQMR2bA5U0kdAaDEWJZ/AR0CQ9JwG4s1HQJD0nAbizUdAnKo+AZvOR0B1xc4MicxHQLyIvtQyvkdAzRPzn7rER0C1EJYRVM1HQEGCa7l2xkdAoA+/MNPNR0Br4CNvNM5HQKMoyLbpzEdAqIFj8m3OR0CgdbVe0cRHQJ2hVbnSzUdAQYckc5/PR0C1EJYRVM1HQFdjQxYtxEdAapMoUwPNR0BAnaZawc1HQDAieudKwkdAqIFj8m3OR0DLrGQbRsRHQPmdFwixwkdAuLQN6HTFR0D0GKN9RcpHQLUXzL2S3UdARfYvswnER0BUBPtZM81HQEpChZceykdAtuAc4A/CR0AM6tL0ls1HQKCgTFd7zEdAY041Uu3CR0AqgwoRJ8pHQLbgHOAPwkdAupl21tPBR0Ca1J0V+8RHQB6exVXcxUdAZT0QtN3dR0B7A++LW85HQDTLf/c3z0dACJ+hEKXBR0AuJsbK2c5HQMwLisgrz0dAYShsrvbDR0ATEyB/s9pHQJ98tBcVykdAAy5d++HXR0A+WwcHu9ZHQGEHT5pmz0dAw22LN9TQR0AmEC20nsNHQKYI4s8/z0dAFZqECAHFR0CRqb2zdslHQGiMDvxzzkdAxAMepirDR0Cfmp3V2s5HQJrUnRX7xEdAikgVEfrFR0AGQwS5F8VHQLJN6P1Y0UdAQH4Oqs/JR0CYmL8mUcJHQEl4rUoDyEdAhQJWEeXOR0ById1vd81HQLt1XF+0zUdA74xqnAPNR0DHu5pxV9ZHQAs4Uzq7zkdAVMtkpbrCR0BdRPDMv85HQOpx2rHjzUdALd/XoQrNR0A9h40N+NlHQJrUnRX7xEdAGF/7nJfGR0DLDMCrCsJHQLMrmr+jzkdAIgDGoETJR0CY5SqXv85HQKOY1Z7Gx0dAfxKsZYPNR0DjcOsQLcRHQOq2FvZMxkdAqMN/xLPOR0B4NsWSW85HQKykMTQA2kdAlqb8/NvCR0At9+hevsFHQJrUnRX7xEdAGlvx1RrXR0BGmXUV/ttHQKKkqWZizkdAHB5BeJTVR0Br4CNvNM5HQB0J0a3ZwkdAwtTlgBzGR0Cfmp3V2s5HQI2rUvnlyUdAtRCWEVTNR0AjF8dBvMZHQLNQFOMa1UdAVI3n/q3NR0BkE93WPdlHQKQ+EvQswkdAsyuav6POR0BHns2l1sJHQKGb8w9/ykdAjkKmPSTFR0AujYCGDsNHQGCKwa8Q3UdAiu+WdKzJR0BQaXv2h8hHQI0OSMJ+vkdAZ3Ilk7fJR0DiP2gzSs5HQDmThZtLyEdA1+ykZbTOR0Dp2t8l7cJHQBgJW1Yb1UdA8yqq/6XUR0DzQWw8WtRHQKM6ccdIykdALo2Ahg7DR0CwRRKKW8NHQKx7yZ77wkdANNn4ebfYR0A30c1PSNdHQOBjqymbxkdAplCc943OR0AxBWbjE89HQJs5eLSe2kdALDHo57rER0BBhw3XacZHQBfF03R71EdACnThmAnFR0BhVua1q8pHQAp04ZgJxUdAmDLnTm3YR0DaDooJkdRHQEj3SIpV20dA2scFxSG/R0DiZCcr4sNHQOvmsjblxUdAEEl7Iz3DR0ALGdnfI81HQJm3XJB8w0dAGyIleG7LR0BLR2YZFc5HQKDQsO2020dAIOuDDjXFR0BI11no29hHQAxFFVkGxkdA/CYpvSrIR0DeF07U/dRHQPjffWdRzEdA76GO2HjTR0DhkDYjfcBHQC/1NcO01EdASU60GG3MR0ATEyB/s9pHQCHyPfOX1kdAzvTYt8/JR0DsOivUYMZHQMoJMZzNwkdAzvm88dTNR0BBhw3XacZHQM/vOJtHzkdA8sIIp+bFR0Ca1J0V+8RHQI6cVwWCxEdAQTyRrrnDR0B+1V/pW85HQMW182C/zkdAzprtRCjCR0CkKZP+BM1HQMpuvPScykdAExMgf7PaR0Ca1J0V+8RHQJrUnRX7xEdAQrVPNEDCR0D9FFBz9c1HQJLKhsg4wkdA8rrKTzTWR0AkQeY6tcxHQGCpcPz3w0dAECLDcfPCR0DBqyfrXspHQFtY7gcn1kdA4WID8VPZR0An9BbpJ9xHQAcMkj5tzkdAZU+V/gTNR0DpQh5UscJHQNqglulO1kdA/F7qt5TMR0CPz3By28ZHQBMTIH+z2kdAB0IVq4TLR0DX0K+optRHQGHAn9XazkdAdjOjHw3LR0DKmP+zzcxHQGHAn9XazkdAdN3nOgXNR0BtmrYA5tlHQM702LfPyUdADEUVWQbGR0BrzGCWus1HQAFYxICKwkdAl99fwC/AR0DLGI4DycBHQBJQ5sGLxEdAa+AjbzTOR0B52fNY2t1HQE6zYcnszUdAKpbmTBbLR0BV9YWfns5HQHibKCMdy0dAloPCaCLAR0DaURsjOdFHQB13OCQvy0dACsz+0Ru7R0Ao4qo7ocRHQARfo3WsyUdABtOi0SzOR0CbP5TSrc9HQPANiIelxkdAXqYte4DOR0B8iG4/nsxHQO86xfFWwkdARb7ofhDaR0Df2v6fx8lHQOJ+iFlk2EdATZWhitjJR0DioLpCqsVHQLUQlhFUzUdA8QRTsVfOR0DvQsEs981HQPAqUv6BxEdABtOi0SzOR0CFBQQu4NRHQDQoZRVg00dANChlFWDTR0DjQEClJ8JHQKId14kCwkdAl6cGqfrZR0CHzM/svsFHQGa6kHTxwUdAjes9ZxvVR0AM6Vj0usRHQD1mkwg8zkdAJUdYWT3HR0A4y4P5zcJHQJDYDy0JzkdA59xf0NHLR0AtwrJxe8pHQB1cgbsI10dAXru04bDCR0B6Q0eW/81HQCS3Jt2WzEdAYlSM0qnFR0Clg/V/DsNHQIY7JnEn2kdAl2zS80LMR0AJbTmX4spHQMxOwCihx0dA8npyRVDGR0AMdVjhltVHQD/U6JuVwkdAqbWJwzTJR0Bg1zHZOMZHQHIh3W93zUdAYYicvp7DR0Ca1J0V+8RHQDm+viL0zUdA93iOuQzPR0Ab5p6KqMhHQHtqBAGDzkdAdfi6+FrXR0BrwJyw78VHQNfds+MD0EdAklm9w+3QR0Dxkrus4spHQAYw4aecyUdAv0ctL2HJR0BnSEq3+8JHQFyJ1hDw20dA8jgmOnTJR0AMS78hrctHQCf+uJXPxkdANjiDUgPDR0DV5ZSAmNBHQK30PZen3UdAN9vzNFTSR0Bu/kMgtcxHQM6NlQq9zUdA035SiunMR0BRtt71rc5HQH2saam/zkdAUbbe9a3OR0BH/ZpRWNRHQKDCU8BkwUdARntrSU/HR0CCM68lj8ZHQJrUnRX7xEdAmXYTd1rOR0BRtt71rc5HQHzXr1oqz0dAi2TKsmDOR0DO9Ni3z8lHQIg1Rv9Mx0dAJ4E/jyDIR0B5D/hFB8pHQM1hELujxkdArrvFOAnSR0Cxf2RbgtZHQB+A1CZOxkdAkgQCGdHIR0BVm+EBA8tHQAYE+y6zzEdAmoAx613aR0Ca1J0V+8RHQMxOwCihx0dA0/y8n1bBR0BIscU2tc1HQOW7yax0zkdA96avCPrLR0DPZDIussxHQJrUnRX7xEdA+E8Rib3CR0AHtyyUCcRHQD4Pb09wwUdAZ0hKt/vCR0Ct9D2Xp91HQHanqOuq2UdAzy8D+xPWR0Dlt3FWB8pHQKtQzXprukdAWtS6HBXOR0B4YKrgCsRHQD9qylBAz0dAwpj3ryHER0CndmDiSstHQHfvSL90xUdA/FvrU5rFR0D8W+tTmsVHQGY9f1H30UdAad5s0RTOR0BsEj2i4spHQPFTgulnz0dA8SHgxNvCR0Dgw/eO8thHQOYpBqPtzEdAxHk4genMR0BsEj2i4spHQGamAI0czkdABQIHLnvMR0CKnnr1yMxHQEjdzr7yykdAbZq2AObZR0Bp2whCdMZHQPqJMGl/z0dAxwjExXPdR0AtwrJxe8pHQBZq9/KVzEdAdCu+gKLNR0BH7WLAcMNHQJX+KGHbwkdAU1prZ1nOR0Af51nwstpHQE5pn7y/ykdAQQDtatnNR0Bebcy4V8NHQJdVskVNzUdAEYp4rpnOR0D9f6Sh6cxHQGSPbIjTzUdAD7Jp+1DLR0Ca1J0V+8RHQGHAn9XazkdAjjBW5YzGR0B0aBzgRb1HQM/IGAaJyUdACkAvHlbNR0ANRZbZG81HQK7Wy+fDyUdAyO7PMyDIR0Ab+HyNF89HQEYUrNTgxkdAw7Cq+5PTR0CCM68lj8ZHQPu4QMY/zkdA0fMWK8TQR0BGeA50E9BHQF8M5US7zkdAyaaKGUnOR0CzUKz/pdRHQJIZyOOEz0dA1CZO7nfAR0DTj4ObV9pHQCO+gE+NzUdA+E8Rib3CR0AyLNIGmM1HQPEEU7FXzkdAnz1DqjvMR0DqNsJRW81HQETw9z+LzkdAF20/LYfTR0Dxl7aCHc5HQLFCTdFqy0dAJ/64lc/GR0CWrc9+H8lHQAbTotEszkdAzAUIyNLNR0CGyw4Xl81HQAccmpa+xkdAXhycVU3NR0D1TQej89FHQMFkqF+pzUdAsPkHfejNR0ANRZbZG81HQD/Xsg2A1kdA3zBnPKXGR0D/N0UzzsxHQIn68jwXzkdA0YHiUEraR0DRgeJQStpHQOOLOJWzzEdAGYo73uTFR0AR1Tj0Rr9HQOA2e+lryEdAlwtsAPzNR0C/RdFKtMxHQKDQsO2020dAYY6psYDdR0ANsb/BnsNHQNb9YyE6yEdAoz/RyOnMR0ATEyB/s9pHQKDQsO2020dAzvTYt8/JR0A0ETY8vdhHQE15JpQ7zEdAbOwS1VvTR0BbXrneNtNHQM702LfPyUdA8Gh5pNXYR0DO9Ni3z8lHQHAmL/2OxkdA1esWgbHcR0AhnWusxcJHQD0LtM6HzkdAldtj2pjOR0A2SedUFsxHQBQCy6dNx0dAQ1a3eg7ER0DrckpATNZHQHBN3TwlxEdA7biLdxrKR0DZ0Rx/wMxHQAx8oHDRxEdAHELF05PcR0D7nYtexM5HQI3rPWcb1UdA1v1jITrIR0DQaPcgDs1HQBMoyvS32EdAQsv8m37DR0AG74WrvsVHQPxGuOz33UdARtEDH4PNR0Ca1J0V+8RHQLSNMCYsz0dAENj9rLfNR0ABY9t0FMRHQB2UMNP2w0dAgQB3qzfDR0B370i/dMVHQCOwTqJZykdAfyMI983cR0DWccwX081HQHWTgOcKwUdAsOd6wbjUR0B7RPHPcdNHQHuONxUD0kdAmtSdFfvER0CPIaw4KNVHQMfIlDoBz0dAmtSdFfvER0BRkzfFRcNHQNH3X1bE0EdAvj7VST/fR0BRtt71rc5HQJ7Wd8LuykdAX2zdqgTOR0BaN9askM1HQHSgslrTzUdAzAIEq17KR0BhwJ/V2s5HQKAPvzDTzUdAR93WL/vOR0B7RPHPcdNHQHWTgOcKwUdASydyvuHSR0AkQeY6tcxHQLjOTQhOw0dAgJ3sfeLRR0Cqj+Mu0spHQPp7FViB1kdABgT7LrPMR0BrNlcZgspHQHr1HwljzkdAWFhwP+DNR0Aw9l580cRHQEgOEICD2EdALIApA0fYR0D0XnrQs81HQCoIxSaXzUdAkH7inc/IR0BIqXf9McJHQJanz7V/1kdAj2dvp2/OR0Ca1J0V+8RHQKIyTA232kdAHHfOP0/NR0AcJT15CcNHQDfXaO3B1EdAWJVwLQLFR0Ak0J22P9ZHQESu222FyUdAjjBW5YzGR0DWrQswTc5HQFeYGZEDx0dAzvTYt8/JR0COVgmk8c9HQK4PmkabzkdASrRt49LNR0AUyNOPGcRHQPGaup/RzUdAfPcQUozUR0AHsdjL28RHQJPheD4DykdAluAweGjBR0DndZbp78dHQHWTgOcKwUdAZcOsrZ7DR0ANsb/BnsNHQGZdUJ0W1EdA54JEJBTNR0BWTvzK48ZHQBx79lymxkdAfPcQUozUR0DDYWngR8lHQNvwVr6w1UdAvj7VST/fR0CYrz9HM9VHQCRB5jq1zEdAHGbD9QPIR0Dj/E0oRMxHQAzpWPS6xEdAzVEuKnXcR0DhsA4pgctHQIZgLD6L3EdARFHGFkfDR0BUv0JOLs9HQGrmwcS8zkdAA3gLJCjCR0Ae0U4X899HQMH/VrJjz0dAngjiPJzWR0A2PL1SltVHQIbnpWJjzEdAOrAcIQPNR0B/wAMDCNFHQNCX3v5cykdAZjkTF2PDR0CmKQKc3s1HQBu62R8ozUdAmdhbTrLMR0DQCaGDLs9HQGGOHr+3zUdAj9/b9GfHR0AJUb6ghcZHQKSu76JzzkdAl4Gdd/DRR0D0NM0sY8JHQJD0nAbizUdAzZIANbXMR0AqRtUwtdpHQMrWN4a5zkdA2QzL+ijYR0Bx5hCeNNVHQDSZTyjUxkdAoA+/MNPNR0CCTryObsJHQOczoN6MxkdA4zYawFvIR0BZGY18XsVHQCQmqOFb1EdAqmis/Z3FR0ALSPsfYMVHQEj5SbVP10dAjjulg/XHR0CrXKj8a8NHQME3TZ+dykdAessPO5fVR0DJLcfaiM5HQCPkHHK83UdA/m+ZkQndR0C/ktmQJ8JHQBe30QDeyEdA4dBbPLzDR0ByNh0B3MxHQKqbi7/tzUdAWyVYHM7MR0D5dnjzx91HQK7Wy+fDyUdAhgMhWYDJR0AuZxKcisZHQDcOTb0UzkdAkLF4iSjJR0A3Ze09vNtHQF1qhH6mzkdANHBeofHdR0DTI7/e+s1HQKGw5FqPy0dA8VIp97TMR0Ca1J0V+8RHQFDN73i20UdA/m+ZkQndR0DEidM8DM5HQPu4QMY/zkdAZ6iWHFPCR0Cu1svnw8lHQPgPIWIOzkdADo4B9UDPR0AETSPkvtFHQARNI+S+0UdACWEIFWnNR0CHW4KvT8RHQD4NqM+/zkdA/Ea47PfdR0AHh1thIdpHQGoKbOcezkdA6ILUz5bMR0CLpGbagcRHQGX18GBpzUdADxKL4AvJR0BmpgCNHM5HQK3Fu+T+ykdA8A2Ih6XGR0CfV408yNJHQARfo3WsyUdASLHFNrXNR0ATEyB/s9pHQH+wAGQwwEdASnd8IF7BR0CV5rJ4wdRHQEIQSAvV1UdAWpVMZwrVR0B6XRoaqt1HQLStZp3x3UdAZgdVnafDR0CC7tJTksNHQGw061JEzEdA7UUFZZLDR0D8pDgZpdRHQDO1kHOnz0dAyIXLdrrDR0B4Q+UiKM1HQOvC2tvXw0dAqsyuKmTPR0BiN/wGl9FHQBpAnOBLxkdA7s5Mw7/KR0Dhzui72cJHQB28IyGZyUdAz1HpVVTdR0AzeQ8/m8NHQIvRCHDZwkdAcc6SRNLHR0AdvCMhmclHQG6EVyiYzUdAHQnRrdnCR0Dk3wQy/chHQOPwk7Qs20dAbBI9ouLKR0DIK/mgM8hHQH9K6SeJ0EdAvJaQD3rWR0D1DP3t1M9HQB1a0ddNyUdArk5w3xrcR0Bem35qq9lHQJ8w5LWrykdAgjOvJY/GR0BdT3Rd+NlHQHGLbsfYwkdA5wlqSd7CR0CASL99Hc5HQO+hjth400dAVucR1tjFR0D2r8PQ3tRHQGH6XkNw2EdAXQv37YvER0D/88nEDMFHQJrUnRX7xEdA9ayhXRDbR0DT/LyfVsFHQGUsUfiXzUdArkqt7WnUR0B0IywqYt1HQC2LYQX6xEdAe2oEAYPOR0AMfKBw0cRHQLzH95ctyUdAbH2R0JbNR0BbqP8jSNtHQKm1icM0yUdAsgKpOEHGR0A9ZpMIPM5HQHnM2IFHzkdAkpaX6qzFR0Cu1svnw8lHQDBdbzi/wkdAqpo8P+7bR0BtctLdsMJHQOl27COUwkdANVde1urNR0Cc2m2lBM9HQENiswr4zkdAtRCWEVTNR0DyVSDqZtVHQP/zycQMwUdA0ZFc/kPMR0Arnnqkwc5HQNtCJehOxUdApDUGnRDaR0Ae2bqmUM5HQOnMltxDzEdAnzDktavKR0DzKkIcscJHQAL59tTIy0dArb+9HIrCR0DeF07U/dRHQDTvLtMTzEdAe0/5mM6/R0B6HMTWBcFHQDlvumrAyUdAQVX5XHXNR0C1WIJz48VHQGamAI0czkdA9DTNLGPCR0Cn2vVyos1HQJrUnRX7xEdAkuPzLy7OR0C+sMq/tc1HQGnZQcIDzUdAW3CmDFPZR0BMrg7yjcJHQJHPK556xkdAjWQaQ/zOR0Bu8H4P8NRHQJrUnRX7xEdAWrgP7eHKR0B66ZXOYdNHQENSPha4xUdAsOd6wbjUR0BRtt71rc5HQPmdFwixwkdA0uCGfVrJR0Di6CrdXdNHQBrerMH7wkdAKGIRww7BR0BF83ckm8dHQHEOG4jMu0dALcKycXvKR0AuybBzG85HQK7Wy+fDyUdAsLVXHJfNR0D4UaBej8tHQEAv1wD30UdAsLrERzrNR0DX+iKhLclHQGoTExPVw0dAKETAIVTNR0DoM7TCM9tHQJCVuL4qw0dACkAvHlbNR0Af51nwstpHQH91+S/A0UdAjtfIHVLFR0AcZsP1A8hHQKH5boOyyEdAuB+feYHDR0DGTQ00X8xHQA7KUvC2ykdAjN0dnWPPR0AwXW84v8JHQNHzFivE0EdAfxhtyl/NR0Ca1J0V+8RHQCGda6zFwkdAx88/9HbMR0AXkCPBB8dHQOgyfN6p10dA6Paz1BHKR0C0jTAmLM9HQENSPha4xUdADkNsL7DLR0AKj6UrssxHQHzXr1oqz0dA56hSnOvdR0CqqnTQVcZHQOP3SODVvkdAy8/EdqLZR0CHY9eit9xHQBKk4JaAx0dALv8h/fa/R0DWccwX081HQHzXr1oqz0dA1+g6LIvOR0An8zQFl81HQIzsYWf+2UdAlufB3VnJR0CE7PQ3LM1HQAHpHrYNz0dAI/gAWR/IR0DXmyAD3MxHQEKxMYkcz0dAm0kBjUXKR0DNWlEdR81HQE2OpYnj00dARrHc0mrUR0C5v0Ax7shHQGfR9D9kykdAugH/kbLMR0DEidM8DM5HQAbTotEszkdAyuklpaTUR0C/7Pytbc1HQMioCsQtz0dAIZ1rrMXCR0D4DyFiDs5HQMsPvw8FzUdA5wlqSd7CR0D3evfHe81HQCc2OHQnzUdAH/zOc2fKR0CL0POaY8NHQBdg6qoqzkdAswBAKpLXR0CzAEAqktdHQANDp/55zkdAuYHkmArNR0DMBQjI0s1HQJrUnRX7xEdAIqs/6PfdR0Auht09YdBHQI4JJG3SzUdAjRmKNiXOR0DRkVz+Q9RHQMmhBlIwyUdAiOa9DnXPR0D+C/XVxNhHQLKYJ8Nw2EdAJ/yezXTOR0CbIzB4hsVHQOVVsnCNxEdAa+RLjAvIR0B/Y4bIlMxHQDYMWbzc0UdAwctiGx7WR0Apw6yoZdZHQD6CIuP/zUdAfPcQUozUR0DSycn5n81HQPZqfRqC1kdAYOYa6uDWR0CuSq3tadRHQC5+Ktm3xEdAmE8FxZfaR0CnsFJBRd1HQHanqOuq2UdAZrlB9PHPR0CK/H5ams5HQMsPvw8FzUdAmtSdFfvER0DnCWpJ3sJHQOD0VKWyzEdAWjUFuyzMR0AkQeY6tcxHQByNPEOKzkdAd+9Iv3TFR0A3OBH92thHQAOprw/0zUdAo6+NaUfOR0CMf59x4cxHQHqsg/1D1EdAo0y09d3FR0BorgY6cNhHQCTCVG0WzEdAO/moShHcR0A+giLj/81HQFfE6G03zkdAZkGBp+vNR0BQJmtdtcxHQCoKAP0a10dA2ZOVZgDMR0AB6R62Dc9HQPRG971Xw0dAbtZf/f/ZR0De9j/rGtxHQKM7U6tZwUdAYOMHov/QR0BI+kynCdtHQBelK6iNzkdAeczYgUfOR0C5geSYCs1HQAMGSZ9WzUdAIqs/6PfdR0AB1xB6yNVHQGbHodmQ1EdASbJn/17ER0AfKusJG9pHQAexZnZzzkdAJzY4dCfNR0D7Wr3hg81HQDMTOh9GxEdAJe/Ng3y/R0BqCmznHs5HQJrUnRX7xEdAE5R6ze3NR0Af+YOB59pHQOVVsnCNxEdAZ0hKt/vCR0B5zNiBR85HQJTD0516xkdA6ILUz5bMR0CS4/MvLs5HQG2atgDm2UdAglsFnizKR0CS4/MvLs5HQG2atgDm2UdAzqMQODrMR0BNT0b/Rc9HQI9nb6dvzkdAnzDktavKR0BdaCPhv85HQPLLK5p4zUdAZ0hKt/vCR0CmthZesM1HQK2/vRyKwkdA0UxByAPNR0BkfqgT1M5HQAJQEx0MxEdAd3LPuEXKR0CYvTdJXc5HQMZ6KZBnx0dAQwP4QfLPR0AhIPKlVtRHQJgj56FPxEdA9S3lDxXKR0DEpg8JkcNHQE48gV/M20dA2cn3xG7FR0C4D193EdxHQBEB/l6HxkdAMoAdI4zCR0Dx3GQc79BHQG3KFd7l1kdArb+9HIrCR0A9ZpMIPM5HQHXYJhBU0kdAn0FD/wTNR0A8REiC1cNHQKTh245F3EdAUN1u32nOR0Ck6Y7zLtRHQHD9OL3y2EdAtJ8nxvvcR0BvvdZAW8dHQEfd1i/7zkdAYcCf1drOR0DJjAjdXc5HQIE/he6VzEdA9M4nRqTQR0CCLJyIZMpHQJrUnRX7xEdA3gcgtYnPR0Ag9lueu8NHQFW2xqLUwkdAsEUSilvDR0De/aiIfsFHQCB+Sgp2xEdAX2zdqgTOR0A/AnLON8dHQD8Ccs43x0dA9YlnyZbNR0BszIOljsZHQNS4N79hxEdAq8sa1oPIR0BZYNkWb8RHQEWA07t4x0dAahMTE9XDR0BhKGyu9sNHQDyc3MmJw0dAqM+jHCvJR0CZF0mDZ8dHQOW3cVYHykdAwDNOAbjYR0A7+ahKEdxHQJv/6oBKzEdA2n2PRvrER0BhwJ/V2s5HQGHAn9XazkdAXQv37YvER0A/uTul4spHQAx8TymS1UdASP4t79TbR0A9600ebL5HQBe7CwExzUdAj2dvp2/OR0CDycfNNMhHQKhVgjK+xEdA3C3JAbvER0AggT/8/M1HQGdISrf7wkdAEodsIF3aR0Bz1wAPRthHQCS05VyKzUdAB13CobfcR0CBCdy6m8dHQJAUkWEVz0dArK3YX3bXR0Bfl+E/3dhHQPDAAMKHzkdAEQGHUKXOR0D76NSVz8ZHQIqWPJ6Wx0dA9UVCW87dR0C78lmeB8tHQCMVxhaCxEdAmSoYldTVR0A+0XXhB8dHQMBEqpLCxkdA/dtlv+7AR0ANVMa/z7xHQIP5K2SuzkdAduCcEaXBR0CvB5Pi48VHQBuZR/5gzEdABtOi0SzOR0A2HQHcLM5HQHtsy4Cz2kdAhbGFIAfDR0BhcM0d/b9HQO488ZwtxkdALJrqozXMR0BxbEW0gMZHQARfo3WsyUdAgjOvJY/GR0B7vfvjvcRHQJrUnRX7xEdAvTRFgNPLR0BG1aJK/M5HQHI2HQHczEdAAeLjUFXLR0B89xBSjNRHQOUqFr8pzEdABRVVv9LNR0ChKX0Zc85HQI9nb6dvzkdAfNevWirPR0BpAG+BBM1HQJXbY9qYzkdAmbdckHzDR0AyGOlme8xHQPzh578Hy0dASyL7IMvGR0AFacai6cxHQBTwtPq/zkdAdT+nID/PR0Bss5W9w8VHQEp3fCBewUdAGVqdnKHCR0BxOV6B6M1HQGdISrf7wkdAk0eQeqrOR0CSyobIOMJHQK30PZen3UdA9aEL6lvaR0CZdhN3Ws5HQLWrkPKTwkdAxm00gLfYR0BRtt71rc5HQHaNlgM9wkdAlAWuU67OR0BT0O0ljdlHQK5+//VwwEdAPktYZ7HLR0AViulMHsZHQJEgVUfgxkdAaz/QDE3HR0BOuGvK1MlHQIiE7/0NzkdA0/y8n1bBR0D7uEDGP85HQIZgLD6L3EdAwsBz7+HKR0DfFcH/VsJHQNFv1BQFzUdAInGPpQ/NR0DNr+YAwc5HQJ4mM95WwkdADV4SbH7GR0AG2EenrsRHQP5IERlWzUdAsacd/prUR0B69R8JY85HQAz0dKG+1UdA9EgoIqjdR0BWPRKPQdJHQEugneCWzEdAKdAn8iTNR0DuZgvdrNhHQC50JQLV00dA6dSVz/LUR0CXLEf4edVHQMSJ0zwMzkdAQfZ698fDR0BOs2HJ7M1HQAddwqG33EdAX9BCAkbPR0DR6A5iZ9hHQM6luKrsw0dANgLxun7JR0BQU8vW+sZHQAVpxqLpzEdAylLr/UbDR0BU46WbxMxHQDSAt0CC1kdAwsBz7+HKR0A7NgLxus5HQIrMXODy0kdA9UVCW87dR0AqOLwgIs1HQN4bQwBwwkdA56vkY3fNR0BXQKGePtpHQJxoVyHlxUdAbhXEQNfGR0AbaGSuUc1HQOyfpwGDzkdAG5lH/mDMR0B/TkF+NtBHQFm+LsN/1kdAg/krZK7CR0CkiXeAJ91HQI0LB0KyzEdAI9biUwDMR0BRTN4AM8dHQEgWMIFbw0dANV66SQzOR0Dl1TkGZM9HQF/uk6MA00dAPrMkQE3LR0BSf73CgtNHQIuJzce1zUdAiX5t/fS/R0DQmh9/adlHQC457pQOzkdAS3ZsBOLNR0D5hy09ms5HQPDAAMKHzkdABf9byY7ZR0D9wcBz781HQLYr9MEyykdA4E4iwr/KR0CumBHeHs5HQDykGCDRyEdA6SRbXU7BR0A1XOSers5HQGovbfuIzEdA6yq+UKnXR0ATEyB/s9pHQLU+ev0o2EdAJ9ERR/7OR0BfbN2qBM5HQFuPQXVTz0dAn3y0FxXKR0DMDZVl2cFHQD0JN9wxzUdAdexRzMLGR0DxYaokqM1HQB1cgbsI10dAteda/RbER0A2Y7cgssJHQENSPha4xUdAdCMsKmLdR0BhJ56uTNxHQHLYeA630EdARIh8rm7FR0CfMOS1q8pHQNfspGW0zkdAoYuNRmzPR0ANRZbZG81HQGfBqsuA3UdARLGJisDNR0A7PdgqTdxHQEZSxlCyzEdAdyI1q0bFR0BkY4vIo8xHQAlhCBVpzUdAydXwdoLLR0Aiqz/o991HQB7ICBWN10dAbZq2AObZR0A1FTAhqeJHQGAFTm/s2UdA7VIMWD7NR0AVyahJ6M5HQBXJqEnozkdAZLN51bDCR0BfpovsgeJHQFNdb4TNxUdAVHs+7g7PR0BhwJ/V2s5HQFo1BbsszEdAa+AjbzTOR0AiWV3aMtJHQAFYxICKwkdAYcCf1drOR0BDUj4WuMVHQNmmJRRqxkdAkL4W4vvCR0Cbn+XwfsNHQFkP8Iiw1UdA10p7kprOR0A72+CatMdHQFY21HH61kdALcKycXvKR0A9jvtjlc5HQNHJPgcXxUdAOYCpX1zHR0BoSZk3O8xHQNKauZxfz0dAqrIifIXWR0DnNS+0nsNHQFX1hZ+ezkdAZqYAjRzOR0CFwPcijdNHQGt+DonBzkdARc675FHLR0AHsdjL28RHQKaWo4NSwEdAppajg1LAR0CU60CyjcVHQCeBP48gyEdAzvTYt8/JR0AhnWusxcJHQKOtSiL7xEdAHLEWnwLMR0AdwHEF081HQDuPiv87zkdAU0Da/wDDR0C47BD/sN1HQGuad5yi0UdASxx5ILLMR0ArFyr/WshHQEkp6PaSwkdA56vkY3fNR0Akl/+QfsNHQG8PQkC+xEdAdVlMbD7CR0A3iUFg5cJHQIfcDDfgy0dAF2niHeDbR0DSb18HztFHQMWRByKLxEdA9RH4w8/JR0D2l92Th8VHQMvZO6OtzkdAB3jSwmXFR0C+K4L/rc5HQAOy17s/zkdAu/JZngfLR0DuzATDuc5HQEEN38K600dAduWzPA/MR0AhIF9CBc1HQHMR34lZw0dAXKyowTTIR0DwbI/ecMlHQEIEHEKVzkdAwhn8/WLOR0BBnl2+9dVHQPARMSWS3EdAA7LXuz/OR0Bf0EICRsNHQB/bMuAsz0dAE0iJXdvNR0C2K/TBMspHQChEwCFUzUdAATYgQlzTR0AFacai6cxHQH3ogvqW3UdArmhznNvAR0BGJXUCms5HQABRMGMKyEdAWipvRzjJR0DmP6TfvthHQJsCmZ1Fw0dAh22LMhvMR0Bf0EICRs9HQKrv/KIEzUdAgLxXrUzcR0DRkVz+Q8xHQBdjYB3Hx0dAP26/fLLIR0Bf7pOjAMtHQIl+bf30v0dAoyO5/IfOR0AyBWucTcdHQChiEcMOzUdADqK1os3BR0BYkGYsms5HQErvG197zEdASL99HTjXR0Aa3qzB+8JHQGqCqPsA3EdA4A8//z3ER0AZ5C7CFM1HQJnwS/2820dAzLkUV5XNR0A7j4r/O85HQB1yM9yA20dAIVnABG7NR0C+TBQhddFHQM+goX+C20dAJxqk4CnQR0ADste7P85HQBtjJ7wEzUdAtd0E3zTFR0A0Fk1nJ8NHQChEwCFUzUdAq+l6ouvCR0BxVG6ilsxHQOI8nMB0zkdA/cHAc+/NR0CqgHueP8VHQDarPldbzUdAe2zLgLPaR0BLy0i9p85HQEtYG2Mn2kdAC0J5H0fDR0BFvHX+7chHQMSxLm6j1UdAzcr2IW/FR0DxSLw8nc9HQJhKP+HswkdAuTR+4ZXMR0CEukihLMpHQAe2SrA43EdAISBfQgXNR0DXL9gN28pHQAVpxqLpzEdAYQDhQ4nWR0BUcHhBRMxHQEvIBz2bxUdAKETAIVTNR0AoYhHDDs1HQF/NAYI5wkdAcM6I0t7UR0COQLyuX8xHQJoF2h1SzEdAJR3lYDbLR0DNkgA1tcxHQHFUbqKW0EdAumqeI/LPR0BLHHkgssxHQMIXJlMFy0dAtp4hHLPUR0Cs4o3MI89HQJHPK556zEdAqwmi7gPQR0AoRMAhVM1HQKOtSiL7xEdAucX83NDER0C9NEWA081HQKOtSiL7xEdAuD1BYrvDR0Djh0ojZthHQP5HpkOnyUdANV66SQzOR0DikuNO6cxHQJ5flKC/zkdAwf9WsmPDR0DIzXADPtNHQLEZ4IJszUdAWRZM/FHGR0D0N6EQAdNHQIrIsIo3xkdAcceb/BbJR0BFvHX+7chHQP3YJD/iw0dAIEHxY8zbR0ByNh0B3MxHQBfwMsNGw0dA8KKvIM3MR0Bd3EYDeM1HQFyU2SCTwkdA3SkdrP/DR0DwwADCh85HQBtkkpGzzEdAO5f7RxPLR0CFLg5So9VHQFVtN8E31UdAoLo4eIbFR0D1rt/r4sVHQKBKhEhxxEdAbCQJwhXcR0C1nb63zMxHQGZmO+ZJxUdABmaFIt3LR0AQPL69a85HQFQcB14tz0dAu9QI/UzZR0AxmL9C5sBHQP9uhLyTwkdAogI0BcPLR0C8y0V8J9pHQCui8QetzkdAmYBfI0nOR0BYFFj7mc5HQIfcDDfgy0dANV66SQzOR0AVxhaCHM5HQEF9y5wuz0dAk3j6uqzNR0Cr6Xqi68JHQMSxLm6j1UdAW4nbyanKR0AgmKPH78VHQEv/iOKy3EdAAcXhL5rOR0BCxvKalsxHQGjZBxc6yEdAWps7BJLOR0AY0lgw7sZHQEgWMIFbw0dALJ/leXDTR0DBmkJods1HQMdGIF7Xy0dArwLaKHvPR0CvX7AbttlHQJtVn6utxEdAgZauYBvVR0CSOrW+ftJHQPOAWXHPzkdA63UtT1fCR0AdtIKf68JHQFGgT+RJzkdAIQiQoWPHR0DkDeRkWMNHQEfp0r8kzUdASRCugELTR0AQHm0cscJHQNFJ1ccayEdAe2zLgLPaR0Btc2N6wtpHQP0jZAR6x0dAS1gbYyfCR0CEgefew8lHQMtbsH/XxkdAyZompirDR0DvlcKB5cdHQBNm2v6Vy0dApIl3gCfNR0BTo0uQNcVHQGDZaq5RzUdA8R+vYMvOR0AQg7RXA81HQAsLmAfDzUdAKjqSy3/QR0AM6Vj0usRHQFrnJAPczEdA+OEgIcrXR0BMUpliDs5HQDQHQ0hWy0dAhWWUsDTPR0D5gZwRVM1HQF/rUiP0x0dAGCE82jjCR0A9ZpMIPM5HQAot6/6xzEdAOIQqNXvMR0B1kxgEVtBHQLxYGCKn0UdAd9zwu+nMR0CDNGPRdM5HQFOWIY51xUdAyuL+I9PNR0AlWYejq9hHQDYdAdwszkdAqmIq/YTLR0C+1xAcl81HQCgR4V8E3UdAIeUn1T7NR0B1yM1wA8ZHQEbRAx+DzUdAB3jSwmXFR0DeOZShKs5HQHFV2XdFzEdAo3cq4J7DR0C1pKMczNZHQMZtNIC32EdAJ2a9GMrNR0CoHf6arMVHQAiQoWMHyUdA9x4uOe7IR0ADeAskKNxHQMvZO6OtzkdArWnecYrCR0DmIr4Ts8ZHQK+xS1Rv2UdAmKPH723GR0AX8DLDRsNHQL7XEByXzUdAQZscPunOR0AQct7/x81HQKGkwAKY1kdAKXrgY7DGR0Be1y/YDcdHQED4UKIl00dAzczMzMzMR0DXaaSl8tJHQCWuY1xx00dAB3UkpirDR0DVCWgibMJHQJdzKa4qw0dAu/JZngfLR0CZ9WIoJ8JHQAUXK2owyUdAflcE/1vBR0BORpVh3MVHQJQT7Sqk1EdAKh2s/3POR0D2DrdDw8ZHQE91yM1ww0dAS1gbYyfaR0DeWibD8cZHQG6mQjwS00dAjQsHQrLMR0Bqpnud1MtHQJY+dEF91UdArhBWYwnHR0A5KGGm7ddHQBfwMsNGw0dAWJHRAUnIR0COO6WD9cdHQH9pUZ/kzkdABhIUP8bMR0CeX5Sgv85HQMYWghyUwkdAXDelvFbAR0CpTZzc785HQKyL22gAy0dAUIiAQ6jUR0DK4Ch5dc5HQKqbi7/tzUdAEoQroFDTR0CJ7e4BusNHQFeUEoJV20dA5Gw6ArjJR0CjWG5pNdRHQIdOz7ux1EdAq+l6ouvCR0CzBBkBFcpHQOBOIsK/zkdARWRYxRvVR0B002achtZHQGGInL6e0UdA4/xNKETMR0CpIM/Ge81HQPmHLT2azkdAzJcXYB/NR0D3AUht4shHQO89XHLczUdAhXtl3qrZR0DeByC1icNHQPlp3Jvf1EdAdjklICbJR0B9BtSbUc1HQNnr3R/vxUdAsOYAwRzPR0C+K4L/rc5HQDElkuhlwEdA9fkoIy7OR0BCJhk5C8NHQKG+ZU6X1UdAllzF4jfNR0BtA3egTslHQPDAAMKHzkdAqpuLv+3PR0CsOUAwR8NHQMtbsH/XxkdAeevvsePKR0D9SufDs8xHQD5LWGexy0dAxxAAHHvMR0CRIFVH4MZHQLbXgt4bzUdA7RLVWwPNR0Df36C9+sRHQAHBHD1+wUdAhAK0gqbUR0BeyHYAvNRHQGNPfxlzzkdA2AP8BqXGR0BKuiTW+8JHQLaa2PDyxkdAscFaZmXYR0C1xWowY9dHQHnrEMCMxkdAFXIzSV3OR0BSUq6QvN1HQPPm/lcOzkdAFerc+S3MR0BdCowYnc5HQBE2PL1S2EdAheSAN8bCR0BFq8VtVd1HQLYwmZd0xEdAYNlqrlHNR0Dsn7QrBdlHQKCsZDwUxEdAMEwx/Y7GR0ARiniumc5HQPb++nm32EdAYvByCW7cR0CIYNDNtM1HQI5nZTW8w0dAoPiCLe7OR0CQijQussxHQE/l55gJxUdAV70Ne+vFR0DW/WMhOshHQMB4Bg39y0dAkHLhVCzZR0CbWtydesZHQPKMHVcayEdAv6sJlQTNR0D5gZwRVM1HQNUrz/2Bx0dAllG4YKG/R0Ar0pxzssxHQBppeYPH1UdAm1rcnXrGR0CKDMQVxM5HQPUm5FWm1EdAYR1k5VnJR0B88VSm6cxHQJMvT4Tg1UdAfOWxzofOR0A6nTssms1HQPXKVyrxyEdAaNkHFzrIR0BAJRn/H9lHQK+mc8TozkdAv6sJlQTNR0AktOVcis1HQMLfdjuX1UdAtFvLZPjGR0AazBWUGM1HQFrnJAPczEdA4T+3ed7JR0DiJnDZi8NHQG1hx5MlyEdAXA/0iobLR0BrU+QsxsVHQETCx8Xw3EdAWadBBi/cR0ATQKEG4s1HQOlWrDqbyEdAc5HOAmXXR0BR3Vz8bddHQHzw2qXNwUdAlDbg6VHFR0AZbCeggsJHQMIxy54EzkdA6pNOt/vCR0B2+kFdpNRHQEFzawyZ3UdAEYp4rpnOR0DnafMRzsxHQFc5iUiazkdAuw9UTnrMR0CqFa2pWsVHQMfvbfqzx0dAKv5zwW7FR0DUwNhAz8JHQIfRRopV20dAWuckA9zMR0B0CYfe4sVHQL79BffN3EdAERC879LNR0D5gZwRVM1HQHf2/eqd0kdAVCpnQ4zOR0CWDKxVzt1HQNCX3v5cxkdAb7vQXKfPR0Da5sb0hM1HQAEz38FPxEdAj6ZFQC/CR0Bg2WquUc1HQHhF8L+VukdAfHXUHwHOR0DHRiBe18VHQLHsxt6yzEdAO63boPbDR0CrCaLuA9BHQGFqSx3kxUdAfu35ly3JR0BWEANd+9JHQHOMTfOazkdAYYicvp7DR0C8w41exM5HQJENqUQHykdAP26/fLLIR0CsqpffacZHQFQqZ0OMzkdA2scKfhvOR0DrJg1CdMZHQIJXy52ZzkdAxAjSppnGR0AKE0azMspHQCnZPbt0zkdA6F3g5W7FR0BvdHLfGtxHQIZFtDko2EdAleRB+UncR0D9b7Xm+M1HQATidf2CzUdAhvzG5onER0ANvpPDZcVHQBY5rsB800dAWBRY+5nOR0BWvD16lttHQKqbi7/tzUdAqwZwmaTUR0Cqm4u/7c1HQJ5/jbQs20dAyPik0SzOR0C6+xwfLcRHQNOpHnWjzUdA10y+2ebOR0D6z5off8VHQPrPmh9/xUdAEYp4rpnOR0AYctyRwM5HQMyyZOSlxkdAKlX47CbFR0BYFFj7mc5HQBsOSwM/2kdA6sQdI+TFR0DIQQkzbctHQO4RgyO1zEdAw3kNAc3FR0B2ilWDMMFHQNoAbECEyEdA565uuvrNR0D2+gdPsM9HQEvRz3a6w0dAXWqEfqbOR0BvcKV7ds5HQF3cQUp+2UdAqmIq/YTLR0DbYpjCLM9HQD2YFB+fwEdALX3ogvrWR0CrPldbscdHQDlAMEePy0dA1jroR8DOR0DlllZD4sBHQLCsNCkFzUdA1lHVBFHLR0Bg2WquUc1HQHSYLy/AzkdAD6DDosDUR0BMwX2RDs5HQNP2r6w0xUdAPrMkQE3LR0BxIY/gRs5HQG1RZoNMzkdA+GB//UPUR0Bs6GZ/oNRHQJ88LNSaxkdARWsN8YTLR0DSswA9ssxHQAN4CyQo2EdAz6e51abUR0BR7R1/s9pHQIDWzL+1zUdA9Eb3vVfDR0BtIchBCcFHQNpSOmoiz0dAFK5H4XrWR0AQkC+hgsdHQCQmqOFb1EdAv41QEBXOR0CSqbCJdM5HQJ8JzpJgzkdA8SGPfRzWR0AsDmd+NdlHQKqyInyF1kdAleRB+UncR0AKLI9U8M5HQCui8QetzkdAc/ZcE8PGR0A/vRJ7+sFHQGs9CY0czkdAV3a8J2HaR0DpfeNrz8xHQB20gp/rwkdAg4dp39zPR0AUlnhA2cZHQLwi+N9KwkdA2scKfhvOR0AoRMAhVM1HQKqAe54/xUdAfQbUm1HNR0BzEd+JWc9HQLDJGvUQ1UdANWPRdHbOR0Atsp3vp9pHQGUJD/PVxkdAR6zFpwDQR0CthsQ9ltBHQMR5OIHpzEdArweT4uPFR0C8OseA7MVHQIarAyDuzkdAINJvXwfKR0B9BtSbUc1HQBhgH5260EdAd4GSAgvER0AlWYejq8RHQIJy275Hw0dAgnLbvkfDR0BMVdriGtdHQCRiSiTRx0dA8j/5u3fIR0CT/8nfvcNHQELRPIBFykdAvK5fsBvaR0B2GJP+XsZHQH3ogvqW1UdA6rEtA87cR0A4oRABh9ZHQBxg5jv4z0dAoBov3STOR0CPTl35LM9HQOMbCp+t00dA4PjaM0vOR0Cilz1IULtHQKZV1jFM2kdAyIl0FOfBR0DY9RqhcNVHQMHxsq+HxkdAT28tMDfCR0CB14BrW9xHQOM1aBWhzUdArn7/9XDAR0BtmrYA5tlHQFBHI0Zf1UdADM/3xfjOR0DbfbJVzt1HQDIs0gaYzUdAbYdy4UHGR0AGtEw9zcxHQIOj1apM3EdAz2QyLrLMR0Cjr41pR85HQHRoHOBFvUdALcKycXvKR0B1xc4MicxHQCSJ0pyE20dAM4/lJQvHR0AbaGSuUc1HQDBdbzi/wkdAlMPTnXrGR0Cw+Qd96M1HQI7/3HkdzkdA4sDCgQTNR0DeNmBLINVHQDgA42WCxkdAEdU49Ea/R0BgZSh/W8dHQAOtNZ4MwkdABPZZ5KXGR0Dvnjl0RcNHQFGpKwKQwkdAuo/1N1XOR0B4CU59IM1HQIVeXgS200dAfNevWirPR0Ca1J0V+8RHQKrgzLwQz0dA2uqaEs7cR0BIscU2tc1HQFq4D+3hykdAS88a2kXOR0ACGQw+5c1HQAIZDD7lzUdAZlO4YiLKR0B6VOr81cVHQMktx9qIzkdA40XiwlrHR0C00iWVydVHQE48gV/M20dAbZq2AObZR0Bd5wf3SMhHQKazBRc6yEdAVXpmfLHLR0BHHwItLsZHQBtRI/KyzEdA3vY/6xrcR0AQybFxlMtHQD5k1PmTwkdAKBHhXwTFR0BrQ/Nw6sdHQD+R1gHYxUdAbBI9ouLKR0CdYzs9gdtHQMZNDTRfzEdAkuPzLy7OR0A9C7TOh85HQPDAAMKHzkdANjEn32HPR0AYl9+mVcJHQETw9z+LzkdAip569cjMR0AXrjJGcMlHQLUQlhFUzUdATRp1PSnCR0CcMb3erM5HQK+RgnmYyUdAMJ2wpq3OR0C3lrpFj8tHQE0OrJ5k2EdAi7F0h9LOR0CmUJz3jc5HQE48gV/M20dAmE8FxZfaR0DS4GC2t81HQMQDHqYqw0dAvrDKv7XNR0C5P75UkclHQBqWbGAez0dAWs0SGy7OR0DJpooZSc5HQHVDJT5P2UdAS0dmGRXOR0BTlEvjF9JHQOOG+6Kmw0dAH/zOc2fKR0CRIFVH4MZHQGaRqV/C1kdA19zR/3LXR0A7XUOUYsNHQKXcSp0qw0dAh514uvLUR0CjKMi26cxHQN2n76ShzkdAE3Xuj1rNR0Cyhi1rEtZHQJ9XjTzI0kdAHsfco+HYR0B1i7uf5ctHQM9kMi6yzEdALobdPWHQR0BxDhuIzLtHQMqZrqZ50EdAsJbdwT/NR0D8f7aEpcJHQHeiJCTSykdADOlY9LrER0B2POJnjsxHQIm3jKOLwEdAC5S5no3KR0DiVmIaHdhHQL7XEByXzUdAzE7AKKHHR0C1EJYRVM1HQJdbc6rpwUdAHiVlQdfGR0ATvxPHQtBHQJGZUjGqxEdA6tTepWnER0ATrC0ZYNRHQGamAI0czkdAvKadIAXNR0AJXrD4JsVHQM7oMCd01EdAi2TKsmDOR0B4+NpP4M1HQHnM2IFHzkdAxhGHRpnQR0C9RTzmN81HQHnZ81ja3UdANVzknq7OR0CCV8udmc5HQHmQij6g0UdAXwfOGVHCR0AiAg6hSs1HQC6QoPgxwkdAC4DxDBrSR0CSA6kmnstHQJKx2vy/zkdAelORCmPDR0CfMOS1q8pHQO1jBb8Nz0dAE80s19XMR0BLPKBsytFHQPN2HPDNzEdASBVvqzPfR0D1eV9xBb5HQMMrSZ7r3UdA5vMx71bCR0Ca1J0V+8RHQJrUnRX7xEdAmCPnoU/ER0APTXt4hs1HQL47L56MzEdA+7hAxj/OR0CfMOS1q8pHQHr1HwljzkdALlcwCxy+R0DxH14ZjMNHQKM7qavSx0dAWrgP7eHKR0ANRZbZG81HQHAmL/2OxkdAGra+LNPNR0AkK843s8ZHQNZEIhFzzkdAaAagOp7LR0AXpSuojc5HQOb3OP5EwkdAlZTDQPrYR0BQJmtdtcxHQGbsZYpiw0dAxInTPAzOR0AMI2mpj85HQJGZUjGqxEdA6g14ErHVR0Cd9IsA0cBHQOOLOJWzzEdAmhu1vfvFR0DLDMCrCsJHQPCbWGZl2EdAi9DzmmPDR0Ao4qo7ocRHQCwZLStAxUdAoLjX2t/UR0BQJmtdtcxHQAXmK8XxwEdAkssIOl3LR0Cg5vgpzcxHQF8ktOVc2kdA0jqqmiDCR0AmxjL9EsdHQHui68IPxkdA+YctPZrOR0BJKej2ksJHQMJM27+yzEdAy2d5HtzRR0DrOel948VHQCoCnN7Fz0dAKETAIVTNR0BTPZl/9MlHQMri/iPTzUdAOzYC8brOR0Bf61Ij9NNHQFrwoq8gzUdA30+Nl27CR0A34PPDCMtHQEoH6/8c0kdA1v1jITrIR0Cc3O9QFMRHQC196IL61kdACqLuA5DGR0BkXdxGA8hHQGRd3EYDyEdARSv3ArPMR0DIrx9ig8NHQIPF4cyvxkdA8GyP3nDJR0B7vfvjvcRHQDYdAdwszkdAsAER4srNR0AR3h6EgM5HQP5EZcOaxkdApBr2e2LDR0ASnzvB/s1HQGwJ+aBnx0dAvJaQD3rOR0BWuOUjKddHQDzCacGL1EdAQfLOoQzLR0D+SBEZVs1HQCTwh5//2kdAKc+8HHbDR0DHtaFinM1HQJP8iF+xwkdAnx9GCI/GR0BUqdkDrc5HQLbXgt4bzUdAOShhpu3HR0CJmBJJ9MJHQBXGFoIczkdA81fIXBncR0B1HhX/d8xHQK1u9Zz0zkdAnG7ZIf7NR0CjAbwFEshHQL9DUaBPxEdAlBeZgF/TR0Dg+NozS85HQIf/dAMFwkdAPMJpwYvER0AQPL69a85HQCHlJ9U+zUdAlxx3SgfTR0D84ee/B8tHQIi/JmvUz0dAz2vsEtXDR0BcVfZdEcxHQJqV7UPewkdA+N9KdmzMR0CI78SsF9dHQEf+YOC5w0dA9X8O8+XJR0B1kxgEVsBHQAd40sJlxUdAIQiQoWPDR0CT/IhfscJHQFSp2QOtzkdAi4nNx7XFR0Cale1D3sJHQLyReeQP1kdAvjCZKhjFR0AgQfFjzNtHQCfChqdX2kdAKETAIVTNR0Ak7UYf89dHQNRlMbH5zEdAtObHX1rCR0A0hjlBm85HQJD5gEBnykdAvVXXoZrOR0BbmfBL/chHQFb18jtNyEdAo61KIvvER0DBHD1+b9VHQOczoN6MxkdA+8bXnlnMR0BLHHkgssxHQA4SonxBz0dA8KKvIM3MR0C+1xAcl81HQGmpvB3hzEdAcceb/BbJR0DPhZFe1NpHQIums5PBvUdAGVqdnKHCR0DHv8+4cMRHQKGA7WDE0EdA7q6zIf/IR0AxmL9C5sRHQFnABG7dxUdAgEOoUrPbR0CZKhiV1NVHQJlk5Czs3UdAz9bBwd7MR0AH0O/7N89HQJxu2SH+zUdAQiJt40/GR0DWUdUEUctHQBsOSwM/2kdAKETAIVTNR0C214LeG81HQKdfIt46y0dAXJTZIJPCR0AwpMNDGMVHQM6I0t7gx0dA8PlhhPDUR0B2N091yNVHQGEyVTAqxUdANSkF3V7IR0C4BOCfUsVHQJqV7UPewkdA/aIE/YXOR0DWjuIcddxHQIZa07zjykdANzgR/drYR0Bp+1dWmsBHQO0NvjCZxkdAI7pnXaPDR0CbcRqiCs1HQMpskElGykdArP4Iw4DLR0B9BtSbUc1HQCo4vCAizUdAKh2s/3PUR0AUYFj+fMVHQMRb598uyUdAfJkoQurOR0CM9nghHc5HQPyohv2ewkdA3uukvizPR0B/UYL+QtlHQDYdAdwszkdAT3Yzox/TR0DKNJpcjMlHQFD8GHPXwkdAjNXm/1XLR0CD+StkrsJHQGpSCrq9xEdANh0B3CzOR0AbutkfKM1HQFimXyLexkdAOUVHcvnHR0DW/WMhOshHQC6QoPgxwkdASxx5ILLMR0BRoE/kSc5HQJwaaD7nzkdAzcr2IW/FR0CLic3HtcVHQFwf1hu1zEdAVKnZA63OR0BLzok9tMlHQNGRXP5D1EdA5NnlWx/IR0ABFY4glcJHQLGnHf6azkdAXJTZIJPCR0DCUfLqHMNHQFHdXPxt10dAKGIRww7NR0CI83AC09tHQKitEcE4wkdAfR6jPPPYR0AqxvmbUMhHQHR7SWO0wEdAsfuO4bHPR0DNkgA1tcxHQKporP2dxUdAz9bBwd7MR0Af+YOB585HQMZtNIC32EdAIqgavRrIR0C+9WG9UctHQFovhnKizUdAmG4Sg8DUR0A/bypSYchHQIjYYOEkzUdAutVz0vvCR0Bf0hito8JHQCBB8WPM20dAGt6swfvCR0Bh+l5DcNhHQCEgX0IFzUdAXJTZIJPCR0AhCJChY8NHQLdhFASPxUdAKETAIVTNR0BmiGNd3NhHQDUpBd1eyEdAc2N6whLFR0CthsQ9ltBHQFCIgEOoyEdAzqrP1VbIR0AX8Z2Y9dZHQA/xyIUuykdAarfzg47GR0CWtOIbCttHQN798V612kdAPZAGAYPOR0Aiqz/o991HQDumAK4qz0dAw2Fp4EfFR0AySdngjMFHQDhIecfYwkdAlZdxXbXMR0Ae3+1g1c9HQO0I+wT9zUdAenTwOgXNR0AJVWr2QM9HQDmf6w8VykdAv81SGkDaR0DgL/5nIc5HQDh6FjMrz0dATPS/fRnPR0Bo2QcXOshHQBo6WvuZzkdAMiqSdxrKR0BuJfcYRd1HQNbfEoB/xkdA6hyWFenDR0C4I5wWvNRHQN0J1VH+yEdAUUZXR+DGR0B6IiqCb9ZHQBuyVvTU1EdAkr40OFbCR0Bg2WquUc1HQEwf75KOx0dAvFxzMGPXR0A7MPX9GM9HQG2TmfGHx0dAv4UXcpzJR0AHVwE9m85HQNCzA/VAz0dAeujCFf7UR0A2xIA+tMdHQL/s/K1tzUdA8q+6Fc/CR0AyFH8tktxHQPzUS2ifwEdA3a93iS7YR0BHyHDXM8lHQKjOVJzr3UdAtOkI4GbRR0Btk5nxh8dHQGW3NFZZykdAoPzdO2rWR0Ct+WimOMJHQCpTzEHQy0dApvt9IjbKR0C6XVjMwsZHQOqTTrf7wkdABbD5n9nIR0BWU3ghtMFHQNWmyxHb1EdARImWPJ7KR0DLNpuHRtBHQPARMSWS3EdA3swTyJ/aR0Dqk063+8JHQBcnaNqYzkdAjTXBDwXNR0AJ2vEajMZHQBTlRE4uz0dA5f7e/sDOR0Dqk063+8JHQMbAnbga3UdAQj+nrmnOR0ADK4cW2c5HQCanKvij1kdAFydo2pjOR0AXJ2jamM5HQDr8TPWYyEdAkfbwecbHR0CFyOIx1c9HQPsFu2HbwkdAHwH6gvjOR0Doaiv2l81HQKYM1fpGw0dATWxpLmrNR0CxbVFmg8RHQMCdjVp2zkdAz+IOmYfGR0B8ddQfAc5HQMP3m9xx0kdAzHwHP3HER0Dqk063+8JHQLkdLvqJxUdA6pNOt/vCR0ASRPdb5MVHQMKsq10uzkdAtd1LtIDGR0AVcjNJXc5HQN9u4Spjw0dAyZompirDR0CS/W37UMtHQJL9bftQy0dA6OK7CYjOR0BYFFj7mc5HQDHMPMuJz0dA+XeAnjvMR0DCC9TCIs5HQNKT1Degw0dAA+s4fqjUR0A+GjX8us5HQKOtSiL7xEdAI5E8K/fOR0AM6Vj0usRHQPCV2x7GyUdAj6omiLrDR0A3XufK085HQAlszsEzw0dAMqf+U0fYR0Brw1n4l81HQMfIeOUR3EdADxeQKHraR0C+/QX3zdxHQJdzKa4qw0dAavRWnOvdR0AVO0UHF8VHQCG4S5TdzUdAn4Ue4HLHR0CgT+RJ0s1HQN0DFO3hykdAEjYq2pbVR0D5gZwRVM1HQMgp/S6zzEdAX9omy7/OR0BL0c92usNHQEVNawgLw0dAr5/xiaTMR0AKE0azMspHQCYVedHYx0dA6Vs6dCfNR0CmzkgpzcxHQBEDcd9pzkdAtMnc2tTNR0CnDvzs48VHQMFE2stYyUdAa3o3s2nbR0CqsiJ8hdZHQAJas8jIw0dAo7IuXMDQR0DCUnGkss9HQHiDCjwnwkdAUUDdt8/JR0DES9BccNVHQA5ig1/M20dAnhaTaTrJR0D5gZwRVM1HQOp7iYjNzEdADY0ngjjBR0CXytsRTs9HQKOtSiL7xEdAa5p3nKLRR0BJGcy6GsNHQFF07aOEy0dA5bdxVgfKR0CJtI0/UctHQOwpG9Fb00dAMSBGy+vdR0COzg0ONcVHQBPjN7AV3EdAcQM+P4zOR0CGSlkPatxHQPV/DvPl2UdAlC9oIQHFR0DTuXzN7c1HQDY8vVKW1UdAcyqi8YfHR0CsKhq8RuJHQIav1TwMzkdA2ZR/u1nNR0DNQG9ub9lHQLzoK0gz2kdAdrROtQbGR0DqLkTfgcpHQBMEcRkVzkdABRVVv9LNR0AOSaKhA81HQJgOPSyLzkdAMUMEmAnER0AV9el7BM1HQEXXhR+cxUdAsi7lsePNR0BUKmdDjM5HQPa3cXxOwUdArvtX7nbJR0A7GyIJY85HQDSd7lMNzkdA5GboOrXMR0AtigCivthHQGZtAvWuz0dApCWt/T/NR0ALvyJfTM5HQFCIgEOoyEdAUdobfGHMR0A6nTssms1HQFad1QJ7zEdAf6SIDKvUR0Dc3JiesNxHQMAwf9bTwUdAg5vqm8TMR0BLaFP0TtlHQHykURlw10dAUU96OvLBR0B3tOEYmNRHQAR4QBa4xUdAAfHHqAPBR0DRyr3ArM5HQM6honDRxEdAig1fJInOR0CBgCQIscJHQF3cQUp+2UdAdv2C3bDXR0A5hgpSjNRHQDnxPXKXy0dASGIFnH7DR0AarLScttFHQCMp3+90zkdA3QMU7eHKR0ATKji8IMpHQMf7sF+pzUdAjo3W187aR0Csqpffac5HQNB/3yTlxUdAL64w/q/PR0ABMDZezs1HQDUOg2bIxUdAK0x3iNPNR0A7NgLxus5HQMUBkdHDxkdAVn+EYcDOR0Cx2ISGDsNHQCZWRiOfz0dASXB+Hv7NR0AuLuES+NtHQNYVt/q/zkdAVAiVzDLRR0BLaFP0TtlHQDO2pUhdxUdApCtD4j/NR0AD4+38c8RHQKzfvqF/zkdAxF3/pl7OR0DXQEHJZ8dHQBVQBhnRyEdAKXrgY7DGR0DI+KTRLM5HQKBhvZMHy0dAQrPr3orCR0DH+7Bfqc1HQBfn7sGLxEdAjDFfRyTNR0BrPQmNHM5HQKfZsGSW1UdAfms+5jfNR0CtUaymrc5HQMUpXlhDwEdAxhGHRpnQR0DO9Ni3z8lHQF5Ih4fwyEdAfJiS7F7IR0BFUlm0g9hHQA5ig1/M20dAXt1vvBTER0BWRAFmdM5HQFEnYSUtxEdARKcXF2/NR0BjzqVLDstHQEgWMIFbw0dAipya2PfcR0B1k9bnw8lHQHAq3VN1zkdAyLmWjo7CR0DdHTBHA81HQDmDXDURxEdAIugr8rLMR0CS4/MvLs5HQPWsoV0Q20dA9Qz97dTPR0CFBQQu4NRHQC5nEpyKxkdA5bdxVgfKR0BhKGyu9sNHQKjPoxwryUdAIPZbnrvDR0BVtsai1MJHQK2/vRyKwkdAuA9fdxHcR0BxOV6B6NNHQPHcZBzv0EdAPWaTCDzOR0B12CYQVNJHQE48gV/M20dAEQH+XofGR0D1LeUPFcpHQNnJ98RuxUdAmCPnoU/ER0DEpg8JkcNHQKTpjvMu1EdAnNRJFi3ER0CMxb2ZW81HQPMqqv+l1EdAb+SljtrMR0A5g1w1EcRHQIiiLrzMzEdAznlWaqfPR0CFLg5So9VHQK2pt/zDyEdAeaJWXtPHR0CbWtydesZHQA83Qmcb1UdAvv0F983cR0CXM3Ex2t1HQM7KoiLhzEdAx9PyA1fNR0CFLEqKgdFHQIxQ1uksz0dA9NTeOM3MR0Dk3CbcK89HQDVgxea5w0dAbsOfFoDPR0AOYoNfzNtHQJHPK556xkdAEwGnp+rTR0BJwTdzps5HQP/OXszCxkdABd6Hi3XdR0ASFlxGhs1HQHzlsc6HzkdAlqssxebNR0D/HL4DPtNHQKeqy4eyzEdAd8GMm63aR0BVmzy79dVHQPAq6hpNykdAE5ljwCzPR0BIPh4WRMxHQMj4pNEszkdAasHhvvvCR0CQHDLjAs1HQJ0pkLMSxUdAJN43R6jUR0AvxY8Q6cxHQNUD5iFTyEdAI/IoWE3LR0DAnY1ads5HQDEAaw1Zz0dAXB/WG7XMR0B7ouvCD9pHQBWrBmFuz0dAyZompirDR0DF12wfUc9HQPhZEafmxUdAoypIYc67R0DDGBKpCd1HQGF8azylxkdAN17nytPOR0CXHO5YacJHQN0Z/rd4x0dAAfPzU5rFR0BXlImQt8tHQEZaKm9H2EdAfabOC4bOR0DmriXkg9hHQP0eq0oR3EdAVPCIyDjCR0BzZL/QnsJHQHEDPj+MzkdA5GboOrXMR0DelmXbK9RHQMlA2AjIxUdAYqBrX0DVR0DjHPE7OMlHQA91SP9Fz0dA4hLTx3TCR0Cqj+Mu0spHQPrJiHPjxUdAzqGicNHER0Cq8j0jEchHQFiX2Tux2kdAY8H1D3/KR0AGre0RHdhHQAu/Il9MzkdA3+YvIgHFR0AlNc5V3MVHQObc4QeLxEdApN3jqgTOR0Bh4DAGk8JHQOrksQvrwEdAhq/VPAzOR0DQ1sHBnsNHQMr8TW+ZzkdA3+YvIgHFR0BrPQmNHM5HQCZ1jYwR3UdATqh1Vb/BR0CJOtGAisJHQI4rCsjSzUdAkJCa2RvNR0A7PSlyzMxHQO71wFeMxkdA3QMU7eHKR0B2HpHGE81HQCz88F770kdAF+fuwYvER0DofylrKsxHQGa5QfSxw0dA5SfVPh3VR0C2fs9PfspHQP0eq0oR3EdA2CVP/hPZR0DVhPmawdRHQM1J//3v1EdATcem2R/VR0BzKqLxh8dHQJJXrW0GxUdATyrdB2fQR0BJcH4e/s1HQBDKoH+n3UdAigQM+KDFR0AKE0azMspHQDoGZK93z0dAUiL5skPGR0CJtqq/Os5HQDde58rTzkdAqDrkZrjBR0BzxXvEHtVHQJH28HnGx0dAvOgrSDPaR0BUBDi9i9dHQKCOxwxUzkdAp+Zyg6HSR0CPaQB+LMpHQINZyRAFzUdA6XPelOzDR0Dd71AU6MdHQE1hjOWpxUdAeEQiwKvYR0BzKqLxh8dHQCcvqQ8hx0dAL0Rj+hnGR0CRmQtcHs9HQOqTTrf7wkdA74v1VGHIR0CR9vB5xsdHQIb8xuaJxEdAGAUSKxvVR0AVUAYZ0chHQJ9BQ/8EzUdA2Fz7I0jbR0CQkJrZG81HQNTxJiyix0dAzyvRawnER0BoQGkap8ZHQMj4pNEszkdAFtPGvWvOR0Ca+KpimM5HQENSnohkykdAyO24XT/KR0ABxeEvms5HQLHFbp9VwEdA1gpZMarER0DqLrF78M1HQAjs1NZ0zkdAVfgzvFnPR0AI7NTWdM5HQLqSgkZnykdA8CrqGk3KR0CAOdZstcxHQNpPemqr2UdAvTRFgNPNR0D+211OZsBHQG3KFd7l1kdABLcWrzfWR0AEbW0/a9tHQOz/FHUDx0dATRE09PzUR0C+KCjigMJHQLr3H4KyzEdAwEyuPuvYR0BL0c92usNHQGqme53Uy0dA6iEa3UHGR0BHI6QQdshHQD4aNfy6zkdAv+fgyYnDR0A3O0VTpdRHQGa5QfSxw0dArO5oTmTNR0BL0c92usNHQCn/DtCzzEdAuQGfH0bMR0CoQYL2a89HQMrliHoW0UdAWrLPCFvHR0AoRMAhVM1HQMuyQdURxkdABWnGounMR0DtCYQwxsRHQDde58rTzkdA11T6Ly7OR0DbNAzYO9BHQNkIxOv6zUdAEyo4vCDKR0COKwrI0s1HQNSGRFOWzEdAGyWETlXCR0B97Yz7Ps9HQPj4PRfxykdAlXBg8+PNR0DMfAc/ccRHQIuJzce1xUdA9jgdEgjPR0C/e3p+rs9HQGHtKs/81EdAqRUO02rRR0DEaqC3ANZHQFn2zq8Ax0dAWuckA9zMR0Bl5kttvsRHQEvRz3a6w0dAckpcofHdR0D61RwgGMVHQKZBx8rMzEdAVo9Xx4HLR0DVpgAEK8hHQIUO9C9Nx0dAi4nNx7XNR0CAhECy6cxHQBWpk+ALyUdA9Eb3vVfDR0A0gLdAgtZHQLfykv/J10dAk7bNYTLNR0AgCDXocMlHQA91SP9Fz0dAVSnT7uvdR0ATKji8IMZHQHkAi/z6x0dAtkqwOJzJR0ASbFz/rs1HQOyfpwGDzkdAvTRFgNPLR0BbJVgczsxHQLfu5qkOyUdAZ7tCHyzPR0Cb/1cdOdhHQCfChqdX2kdAqMXgYdrNR0ALtaZ5x9VHQEs8oGzK0UdAKETAIVTNR0DikuNO6cxHQGL03EJXwkdA2jwOg/nFR0BXeQJhp8hHQExSmWIOzkdA9MDHYMXNR0AKTn0gecdHQKGkwAKYwkdAGvonuFjVR0BmguFcw9RHQHAJwD+l1EdAqHFvfsPYR0DL2Tujrc5HQBsOSwM/2kdAAg8MIHzYR0CPqiaIutNHQJd0lIPZwkdAgzRj0XTCR0DV7IFWYMhHQKOtSiL7xEdAEyo4vCDGR0BXQKGePtpHQChEwCFUzUdAbw9CQL7ER0D9ogT9hc5HQM5qgT0mykdAzmqBPSbKR0CNCwdCssxHQBR4J58e0UdAUg37PbHCR0Akz/V9OMRHQLjsEP+w3UdAw0ZZv5nOR0B9XBsqxslHQBo09E9wxUdAfuNrzyzJR0CHwJFAg8VHQPNZngd3z0dA+MCO/wLNR0CCVmDI6sJHQMri/iPTzUdARbx1/u3IR0CkGvZ7YsNHQA==","dtype":"float64","shape":[2915]},"lon":{"__ndarray__":"ARU92dWUXsDI2fWEJZVewAxJxme7k17A75HzHBaTXsAPEMzR45VewC76vkNHkV7ADJThZjuUXsCMmdrYwJhewNAhrYfIlF7AoOlSR/qSXsA+rZ2GupZewIilI66Tk17APeN+ZHOQXsCxQEftdpZewL6gDvbJll7Alwq/DtuTXsDNyPqvLpZewL5BpHSDll7A5oEtTrOUXsDovwxoN5FewEcpBwTRlF7AJx7lmmGQXsBN12dcZZVewE3XZ1xllV7Av0MKy4OTXsAyFt7JzZRewCZuhxlpkF7ADdVxVYmRXsDmgS1Os5RewOPzQdFnkl7AlKrg/FWTXsAo+kEypJVewDvQh4pYlV7AEfT5I8qVXsD+h3/OYJFewH2cC1HVkl7AizETud6VXsDmgS1Os5RewDzj5EZdkV7ANpcv8DuTXsD3FSLi8ZRewN09J1rlkF7AEfT5I8qVXsBzNn1zqJFewERXKQqCl17APdz3cPWUXsBp82pGp5hewGfsFkTOkl7A0ol5YMSRXsB5d5mehpVewOBFFmsjlF7AIrX96S6RXsBREGr2aJNewOoC9IHYlF7Ar+E43CaYXsAttAFFPZpewCK1/ekukV7AhzPlYYaQXsDYFDLRzJJewA9/yZ2kkV7AR2E1m+mVXsAXcalmkJVewAi1pzALl17AdtVugcWQXsD3H2nVhpZewFxdz4kdlV7AVfFdgkeRXsDyeqJ+xpRewFmcsEtUlV7AuCGETwyWXsCqoYmHgpFewCmZ0cwpll7AYL2H1L+TXsAJ8Rs7dZdewGZPMtTplV7AoeeBVXaWXsBBDULt9ZJewDmhm/MPlF7AYguxYkeRXsAyGFu8g5VewNgUMtHMkl7AcNue8BeVXsBu2dooFpJewMcXBo8jll7AU1IJSg+VXsCkVAnpxZZewBJ7SskQlF7AfLrl4+2VXsDMpJKp/pJewH86z+yblV7AvDYCjpCTXsBrEvbM1pdewPWq7MAbll7ARvin7OWRXsAr/RJe85RewL2Z2ElLk17Afz4vtDGVXsB355oTJZZewNgUMtHMkl7AAnFZsK2UXsAjzP6KhpBewNz8RSQYll7AbNZ0mMqSXsCxOOXPzJRewHHD9xdkkl7AiWQesu6UXsBhDnvUMZZewM0Lo2VslF7AsUBH7XaWXsC+4nGd+5VewFeEw1SYlF7AhHn/h2qRXsBDZ7OZTJBewNgUMtHMkl7AMy68ldyUXsC1gVWkq5ZewJZjQmRCll7AhJAXxXeUXsAo+kEypJVewMgsTdrslF7AXcREcZGUXsAyGFu8g5VewJlTkg31kl7A5oEtTrOUXsDwBW0/p5RewPytTuJ0mF7Am4Zf7GiTXsDu+LVJU5RewIpgBcBEkV7A3PxFJBiWXsAu16AEnZFewIGny41Ck17AUe3tRX2UXsCZWykd75BewBn6/De8lV7AXNHt8luVXsCwCBKcOZlewGky8Jfnj17AbmXnP1SaXsANUspNb5VewKJu8whmmV7A8MPw+tSVXsD4Q+AGBJdewBX3SBgAlF7AAzNl+36UXsAmzYm3OpZewAtHgyDvmV7AmVspHe+QXsDCKZxy/5BewAJcIZAxkV7AC14VJA2WXsDq8dZUUZRewM0re2twkl7AQykxOiaWXsCYL1DOp5ZewEtrzB5akl7A5bpjkF+RXsBA8gGTMZdewF+/qQ1Dl17AHgm3WVWRXsDanXG+kZRewB4Jt1lVkV7A+WQHjYeYXsC6p30Da5lewMtExcMRll7A4L30DeSQXsBtEAbOdJFewESYLgZHkl7AdbTS7eqQXsAwPkYlB5NewHIJ0Wv9kF7ANwYCPKCVXsCXHpTK8JVewFV8szXRkl7AwllyXiGSXsAX52iInJZewDtWLvZMkl7AVSOvXxSVXsCJBRKiCZRewGcFrysAlF7AD9EbAKeWXsByK92NYJBewK6x/cR+ll7AB38pfU2UXsDyeqJ+xpRewFkgmKgAlF7AoATGkmOVXsCdrUIeb5RewHz+Tm8zkV7AZVm741CUXsBA8gGTMZdewPrrATIVk17AT7662eiUXsDYFDLRzJJewGc1q95kkl7ANz6smnSRXsCt3OUEaJRewEbjiGnqlF7A3tE+11CRXsDxy6oZI5VewBO7eVTjkl7A8nqifsaUXsDYFDLRzJJewNgUMtHMkl7AdC6uuU+RXsCom2iwuZVewG1+5wq7ll7AKAW/CPiYXsAXKQbbV5NewHR7FHEEmF7An+9JVWqUXsDPbmc+K5RewN8+TVuTkl7AvbmhJEKSXsDtGhOz9ZRewAC9Q2Y7ll7A8cuqGSOVXsB3+ZRro5dewJcjbpLCk17A7+B7DU6VXsCzxFYSkZRewPJ6on7GlF7A9hFBmiaUXsALfxEqtJRewDIYW7yDlV7AskY9RKOTXsCtSYyltZRewDIYW7yDlV7Atfvo42CVXsA+RLzYaJVewL/xxJJjlV7AO1Yu9kySXsBEpJcy35VewDa5rWcnkV7Aqk52T5iPXsAwStBfCJFewMzPxnctl17ASedAMqSVXsDcKVCdZJVewI8VLyiplV7AoQfjTDiTXsC2UzsP45VewCZLTYWPkl7AiBABzoWPXsA6rW4EyJFewGDu0geEkl7AVR27CTOSXsAuVeCZLZJewEqk3JljlV7AgA24Sa2VXsDPG5FpuZJewJESS2Lall7AemMBRkmVXsDXFq3CV5NewCL1VfQSl17A5xgU9oKWXsDeTYpraZJewBtRKKsMll7Awg+U/KSaXsCfhQz9NpJewOaBLU6zlF7ABnZsbMWUXsDB4CMt2JRewBuRjd/SkV7AgA24Sa2VXsBtSF/lCZRewDX27XCwl17ANfbtcLCXXsAEQpfiHZFewAQwXiYckl7AWu4+WiuXXsB1ExxhSJFewKdbpsH1l17AAxavaAmUXsDs96MsTJFewN92ASyblV7A7VMUA5KRXsDLRcttWpZewHYDyHpRlV7AjXq4fw2TXsDQIa2HyJRewLCEDup9mF7AFva0w1+XXsBztzztiJRewNNIS+XtlF7AssPmg6iRXsDZ690f75BewKgEt/pZl17AOq3oyviUXsAkLZW3I5RewNTBoYd/k17AAEnHi7uRXsBO0ZFc/pdewOrxBo7HkF7AwfvseLqTXsDRJPh5SJNewMykkqn+kl7AMMA+OnWXXsDYFDLRzJJewC/lhiMrk17A1srQ7S+WXsAJyqemaJFewLN1h0wtll7Ab+uK83mUXsByg644zZFewAPcMxgRlV7AyJQPQdWUXsDw7Qo7VJVewPDYu37Cml7A8mN4Xv2SXsC8sfF3R5FewD19je/ukl7Af2bqV3WaXsBhoeNeMZNewBJB9T+7kl7AQXgS4yWZXsDfyDzyB5VewJsBxuRBll7A7mmEB3iUXsCp27OQO5NewL359HWslV7AKQOQpTKVXsCS40kwR5RewOSijzbElF7AkuNJMEeUXsBsRnNVOpdewCQtmnD9j17A0vcnrOWQXsA6sC4En5BewNgUMtHMkl7AHNFPznaVXsCS40kwR5RewA28/zSall7ANtQgszCWXsC/8cSSY5VewCEpkWAkkl7ACIK7RBmSXsDCk96D7JJewNwSaJkNlV7AHiNIwQ2WXsCqv3f+gZRewPFo44i1ll7ABhPVFI6SXsDg+dOzkZRewNajnnX1kl7AaMD92b+WXsDYFDLRzJJewNTBoYd/k17A7zq4x9SRXsAmrLgxsJNewBCqB95mlF7ApfH3yr2TXsB5WaZuTZRewNgUMtHMkl7AF703rEeRXsBBjKDJz5FewOfhe7S1kF7AvLHxd0eRXsCbAcbkQZZewJ/bP6ckll7ARp3zMq6WXsCkPB7zFJNewC/u48HGkl7APPsRWUCTXsDX4dGOR5FewBd6j/Ypll7AsDpjeeaYXsA6Yo2wkZRewEIPeArAl17AZYd3BxiYXsBlh3cHGJhewCpzn446mV7AnLro5wqTXsDBg0iBY5VewGnjeYqLk17AGkpsxV6RXsBuDONp95VewOJh89RXk17AZTbIJCOVXsDBg0iBY5VewJthCNillV7A/6uqcbiUXsAauLXlWZJewLK5ap4jlF7APkS82GiVXsCljwX0vpFewMNyOn+JlF7AAYMWpXOSXsDQIa2HyJRewA+lP/nwk17AkyZurWCTXsC4bPNNGpFewJk2SRdulV7AWIerHF2VXsByX4pPmpRewH0/nUEPlV7Av8t8byKVXsDBZFzRQ5JewJHZosqFk17AIWBwd52UXsBeupDhTZVewHOU8y2ilF7AL1MwtpKTXsDYFDLRzJJewDIYW7yDlV7AW2pSRMWRXsB/643RD5FewLNBd2BYkl7AKVbiQUCUXsBLZWZzMJVewD5VjXfKkl7A1gOV2pOVXsBMCJryKJZewNJiw69ll17AkX8k9IyWXsA6sC4En5BewFd8aaiWlV7AuztMqj+WXsCmMxlWfZdewLyuX7Abll7AexVlq1WVXsDiRWb7fpRewG8xeeIdkl7AyXa+nxqQXsDhFIOrD5ZewH26fwGklV7AF703rEeRXsDJRKolRpRewAZ2bGzFlF7AgLxcZkaTXsCVIvKQG5RewN6p8tAmlF7AVZ9Q9IWVXsBKPQaJv5VewJM1PiEIlF7AEkH1P7uSXsCHOnTGDJZewIANuEmtlV7A9eYr2fWSXsATbJtjMpNewPXL6MYilV7AcQs9MpuTXsBLLSmxKpNewHgdwA7bk17AWWxCQ4eUXsBLZWZzMJVewO+UV6z2k17A4fXEMzuXXsC1AKdWY5VewBpNYbcllV7AniQt+oKUXsCeJC36gpRewOlyC9wIk17A93r3x3uRXsBezgcsApNewCPJQUOekl7AYCxL9ZaVXsCh6Bxkm5NewFV8szXRkl7A3IvudBWWXsAyvvDJEZdewIlZL4Zykl7AD0RdPm6VXsDyeqJ+xpRewFV8szXRkl7Av/HEkmOVXsCX/5B++5VewOxAoKpXk17Ax2eyf56YXsATZtr+lZZewL/xxJJjlV7AhuW91GmUXsC/8cSSY5VewDM4f1Btkl7AVDpY/+eVXsDzyrOaR5FewOsOpoSHlF7AUnUJMx+WXsBcUD2kyJNewG6TySqekl7AwgHw+YiSXsA79x4uOZZewLUEqaw3kl7Aipi011KaXsCnCLdPY5VewIcTbc5OkV7AUR523BmXXsBQqhoQA5ZewAMWr2gJlF7AiVkvhnKSXsDXO43I+JRewOFjulQIk17A1rCQzRaRXsBnfC8jNJVewEGVw7zBll7AuQGfH0aUXsDYFDLRzJJewDURoCC9ll7AxwGJYHuTXsAFB3zKppZewHicoiO5ll7Aw3jn//6QXsBCD3gKwJdewHBYEIb+mV7A/PWbbRSWXsCEGVpqS5NewH7sJt8Jj17AegToC0KTXsC3RSL/j5RewJhHXNIBkl7A2BQy0cySXsAFbpuxQZhewGfP+4UylV7A2BQy0cySXsA9zrPgRZZewMlshtfSlV7Ab0Ag17OWXsCS40kwR5RewFBBUP6GmV7ANU6of6eVXsC1o+y4l5JewBbS5Nl6k17Add0h5g6UXsAyGFu8g5VewLOX3/xVk17AARU92dWUXsC3RSL/j5RewH7sJt8Jj17A+rpGqrOYXsAXKQbbV5NewADTqfgNkV7APg8HbNuUXsBDixbnYpNewCYQ4SXZmV7A1qOedfWSXsB+anOevJhewHDZpzfRlV7AMYFbd/OUXsDedqG5TpFewICVktFAmF7AWHF1w0CYXsB+Vbz+dZVewC7yx8Fgk17AcTdT5BqSXsD2OB0SSJFewEFzCOI9k17A+HGA1duVXsDYFDLRzJJewBPnaT/All7AszanQXqVXsD2i9LYMJZewAqsn9vkk17AVaErWN2WXsBm//+pP5hewOGhL4qMmF7AW2pSRMWRXsCLbktR35VewJCcOPjDmF7Av/HEkmOVXsAl250OVJZewOZpfAMMlF7AVOFY4gSTXsCM/O33c5JewM9Hw3Cokl7A2UsYogqUXsDRm6PxOJJewKONI9bik17AjK/5lUeYXsD/Xh7zwJhewH7sJt8Jj17AqyQpHlSXXsAyvvDJEZdewLp6lJgnl17AgAUSD8aTXsCOA46IspFewPn3GRcOkl7A2UsYogqUXsDSx3xAoJNewBG29kPOmF7Ab0Ag17OWXsDGBXfSqJNewBcpBttXk17AKrA6UfaTXsCuTPilfpRewOz3oyxMkV7Ak41vPsGWXsDsPDsqyJJewJUfKB+xlF7AKPygzn+UXsC9h8/Gv5ZewNcfOJl+ll7AF7zoK0iRXsAa4wzDHJZewBxfe2ZJll7AowbTMHyUXsDBHD1+b5dewDqvsUtUlV7AswdagSGTXsCRgxJm2pRewGCOHr+3kl7A5uFiF5WUXsBGtvP91JVewOM2GsBblV7A4fDvJOOUXsBYIeUn1ZZewCGTjJyFk17AzHUaaamSXsCYNEbrqJJewLv00dejk17AMuJ0JXGXXsAq9OqxR5FewE3XZ1xllV7AweJw5leTXsAIt0UxSpVewKYxLA8Kll7AIbK1r92TXsCHMMA2CZRewLqScGOLlF7As5ff/FWTXsAH3j3+OpJewLLROT/FkV7AuCizQSaRXsAuHAjJAphewMrbEU4LlF7ATyhEwCGSXsAWb2Qe+ZFewOy7IvjfkF7ARg2mYfiSXsARTgte9JBewOJw+DoPlV7AyuFjFc6YXsDVa78k8ZVewC0QFKrBll7AdOSS9JqVXsCfs/hZFJFewLPviuB/mF7ACeHRxhGXXsAmzLT9K5VewBn/PuPClV7AbJVgcTiVXsBw7YZl+pVewD5VjXfKkl7AFUB9QIqUXsD9gHwTh5NewKT0ZoP1kl7AuzOocGOVXsAUT5aK6JNewFfPSe8blV7AEGpH8O2TXsD9bexlfZVewDXnDtJblV7AIOfzDWmTXsDYFDLRzJJewEW9reLXll7AdOSS9JqVXsC5Uo1mnpVewFd8aaiWlV7AhojvUleRXsA+VY13ypJewPTM6bfRlV7ANJu971yTXsCd/IU6JphewJ38hTommF7ASXFWkFuTXsDsQuPxw5ZewOLlyE6olF7AQZXDvMGWXsDECCPu+JVewAwS+TP+lV7A/Zj/JeOUXsBlsiLk6JFewP+GzSNGlF7AikI4V46SXsCbYQjYpZVewM8eP4YUk17AkRJLYtqWXsDbVlCkXZZewEqk3JljlV7AJqy4MbCTXsDyeqJ+xpRewO4LdjBzj17AYJYia2CQXsB6gpyuqZNewOysNC5+mV7AP9CxUzGXXsDhmh+lEJJewF3+Q/rtk17AJPlR2smRXsDphNX6kJFewOoeLVzjlF7AmPty05eRXsBdVBkzupFewAUO+UsRk17A3N/CgkeRXsBcJBjHW5VewBxDQox+lF7AI96nmyWVXsCcphErCpZewJDhdDxtlV7AfH3dhGOVXsAePlMpApVewIpwr6Y0ml7A5qyyY0GWXsCp0SqB9JBewLAMtoDMlF7AjLrC+sCYXsCKcK+mNJpewOAO4VNxlF7AyCxN2uyUXsAQMiHKPZJewIsm00WjlV7AwYNIgWOVXsD+h9qHE5hewHDpK1e+ll7AK4wtBDmUXsABaXFZNJRewP5dI3IPlV7AWemVghOWXsBme9vpepZewNqdcb6RlF7AOrAuBJ+QXsC/fR04Z5ZewMZOqEJklF7Ad9RMgu2QXsBWn6ut2JVewC6+GgCnll7Aq7SV/MeYXsCSiS6EqZNewGufjscMll7AZx0ozEiXXsDqPxV+A5lewNgUMtHMkl7A9LMAicCWXsDvOrjH1JFewAyU4WY7lF7A+pW/XDqXXsBmVOEb/5VewKk7fL0ukl7As3WHTC2WXsCHE23OTpFewIRFrX9jlV7AupOK8ZqTXsBOQC+2spRewMH77Hi6k17A18l+tUGUXsDfdgEsm5VewCaMZmUbll7A0r1WW5SSXsA+VY13ypJewOAGLu8nkl7AqC7jHbWUXsCng/LHX5dewGHQhh9DkV7A+yFIOzSVXsCwctrmVZVewE9yMU1LlV7A5oEtTrOUXsCC1OF5TZVewOo/FX4DmV7Aqg65GW6UXsDnpS1xbpVewE0C4Edxkl7ALOxph7+WXsAovz22ApZewBa0hA1TlF7A2p1xvpGUXsA7smFpupZewEDSWcYjk17A55sC0wiRXsCJBRKiCZRewJyqtQ/dk17A9r3hmQuRXsDgDzDU0JFewL1rM8L5kl7A5qq28WCTXsC873PXDZJewJthCNillV7AKvTqsUeRXsA5g1w1cZNewNgUMtHMkl7AXUOKsAqTXsB3LE5m8JNewIPe6FG7k17AsbdGZPWWXsD4BIF8RpFewAmFCDiEkF7ANoIBQvOUXsD50PTI1ZVewNgUMtHMkl7AkIevkGiTXsBi2Q4+m5dewDJY6LgXmF7AegToC0KTXsCS40kwR5RewCVqKgqCl17AYiBJ9S+TXsCHokCfyJNewM8PI4RHkV7AgosVNZiYXsDOmoVhU5RewPvW0MtdlF7A0CGth8iUXsCgnuNIjJVewD5VjXfKkl7AxkpBwSmTXsAT9XUlkZVewDcNwdn8kl7AyWbcDgyVXsCvlGWIY5VewNq+cHxHkV7A942vPbOUXsBB41yfJpNewOmOk/wnlF7AKVbiQUCUXsByX4pPmpRewEOzz4lbl17AvPqPhLGRXsAqsDpR9pNewHhMkwiDkl7A5UGbmOWWXsCuCka4+JRewMqak0JZlF7A6mylMD+WXsDgBi7vJ5JewLs7TKo/ll7ASdhPsLOVXsDYFDLRzJJewPPKs5pHkV7AveypZWOVXsCVnWxtO5RewMo2ls4MlF7AFzetleKTXsA1EaAgvZZewDJY6LgXmF7A+MGj1HiYXsD4rahRgJRewA28/zSall7A/9n0P7eSXsDeE53FiJJewL0NdjL0jV7A5x1WoWmTXsAPsl+JnZJewJ7qi+KHk17A95ZyvtiPXsCEGVpqS5NewA28/zSall7AiK+Lr5GVXsBwo6VL75JewEMGC4oTlF7AHAjJAiaUXsB0Hu02apVewDhCNCq4k17Akw3WxW6SXsBgcTjzK5VewAmk9OfDk17AMCTMWSSUXsAWtG1xXZVewKdcTvr8lV7A+NozSwKSXsA+3/jVmpJewOUS6aymmF7A28IZGjSUXsC5Uo1mnpVewIANuEmtlV7APxuqQx2UXsCashrlVZVewCos0nN0ll7A88qzmkeRXsD0zOm30ZVewOg+v0M/lV7Ad9RMgu2QXsAQzNHj95RewHVB08s1lV7AVc+ipyOTXsCDgj7Q65RewNGQJBp6lV7AtZ+FNx2YXsC1n4U3HZhewMtwJQNslV7AKfTRFCeVXsD15ivZ9ZJewNgUMtHMkl7ATMSLIBaWXsAqi7MDPZVewM2EfUDCkl7AOen8YraVXsCdaFch5ZlewBuNqd+4l17A3m6sOPOSXsAUHfzWZJNewKVXDwdlll7Ap3Tj7/SSXsCFhbv8DJJewEi2E1UamF7AlelvwCmRXsCuC8NwY5VewKGIkZrAmV7ALpHY3HuUXsA+CSqyT5RewAe+UxUblV7A2UsYogqUXsApMk+7U5VewBj/4ylwlF7AiuQ9ZFCUXsD6lb9cOpdewP/w14pUmF7ACn7w4V+VXsD186YiFZZewJ/bP6ckll7ARTJRdYmWXsDzkZmt6pRewOg+v0M/lV7A2BQy0cySXsB31EyC7ZBewAbN0kFDlV7A16x8lOaTXsAXKQbbV5NewJ9UcIJzlV7AQg94CsCXXsCxS1RvDZZewNZ3iMMVk17AEHEGjgqTXsD5iJgSSZJewLdXZS3lmV7AgQw22MiWXsAyUrq3DJZewHVYkE8Qk17AswGZHOWSXsAHvlMVG5VewM8kK2vtlV7A1AyIlI+VXsC4I/fPTpNewG9bEqLHlF7ATh0HBTWTXsA4QjQquJNewCnEK2LbkV7AxHkmnk2TXsCAMHFd0ZVewCMuqozZl17AFPUS+5WZXsDQEbcSM5NewIXvzdQDlV7AJoxmZRuWXsAp9NEUJ5VewF1V9l0RlV7ATMSLIBaWXsAd8cSpn5hewI47T4N8mV7A9HxoRxOXXsA5cEsH0pNewPqvwhk7lF7AdUHTyzWVXsAx/363FJVewD8ZJeCekV7AEy1d552QXsAMEvkz/pVewNgUMtHMkl7AeRSi1MKVXsBxGw3gLZNewEi2E1UamF7AvLHxd0eRXsAmjGZlG5ZewI8SsUSEkF7A/Zj/JeOUXsBdQ4qwCpNewD5EvNholV7A+bHDRBWaXsBdQ4qwCpNewD5EvNholV7AANE2eAuTXsDmiNgHiZRewPhxgNXblV7A2p1xvpGUXsBrgezekpRewO8FJGmwk17AvLHxd0eRXsAa708okpRewOebAtMIkV7A6x69B8aTXsCon06xXpJewP0bHjxfkl7AB0n/yL2YXsCbM7lQDZZewF/CVyo+kl7Ar7LmYtSWXsCgTkSCs5lewL6b4+a4ll7ASQR4RQ+VXsDjgXqT3JFewMi5GscSll7A3WyuxQeSXsDR4pTS9pJewMsaE2cnl17AFhT3OQ2SXsB2YiAZ/JVewO2BVmDIkF7A55sC0wiRXsDfdgEsm5VewO/k02PblF7AznADPj+VXsDLrc/w9JFewMKg1ZTnlV7A/BN4ARiWXsApoVT4nJlewIzBtooNll7Arvu6GHKSXsAb70L+T5dewAEVPdnVlF7AMhhbvIOVXsAWMpkiB5VewPTkiB99k17AdjGYgp+XXsCuMkYwvZhewNgUMtHMkl7AZnCUvDqVXsBHUBhuIplewAp0aopHkV7Awimccv+QXsBsBi8vfZBewDba16UZkV7ANU6of6eVXsBTuH73V5RewFO4fvdXlF7ARa0NbnuTXsA/fb8pcJJewB/5g4HnkV7AhDpe4bqXXsCkXpT515dewA1Z3eo5l17A2r5wfEeRXsBV8V2CR5FewHav4YnjkF7A80fU6A6UXsDqBJc7MZJewKQ8HvMUk17Ay2VNc2WWXsCzAZkc5ZJewHmSZaJXk17ACuHvHAySXsAyGFu8g5VewDIYW7yDlV7AZx0ozEiXXsByBKGjcpVewN5zw2M9k17A6bzfyxGTXsCduWZ2ppBewGYgilqelV7A+HGA1duVXsDjpe/DTpJewPYnf2TLkV7AwcWKGkyRXsDc3JiesJVewLyx8XdHkV7A/KTap+OVXsBDLnAtnpVewJ5flKC/lF7AvO1Cc52SXsBvCFVq9pBewCmzQSYZlV7AI/PIHwyWXsDTxhFr8ZdewG3i5H6HlF7AdXYyOEqWXsBfDOVEu5JewJW8OseAmF7ASbpm8s2SXsD/mqxRD5VewEHZlCu8kV7AbJBJRs6YXsAkERrBxpNewLXApwQnl17AmPViKCeQXsCEEmba/pFewLgehetRll7ATvIjfsWQXsD5LM+Du5FewKVJKej2kl7AgA24Sa2VXsDvycNCrZVewKAy/n3GlF7AHJQw0/aRXsDM0eP3NpFewHQuxVVllV7ASqm7Gg+VXsAgEKvpwZFewEqk3JljlV7AOrAuBJ+QXsCjAbwFEpJewNgUMtHMkl7A7C+7Jw+VXsCCX0Gf6pRewCbMtP0rlV7A4/7AqCaUXsDZSxiiCpRewBHCo40jlF7AO8eA7PWSXsDRyK1qRZRewPhxgNXblV7ADbz/NJqWXsAyX16AfZRewFJ1CTMfll7AkfbPa/2QXsDPdCPq7ZRewPm9TX/2lF7AOBCSBUySXsBslWBxOJVewLEo0wWIlF7Auk4jLZWVXsAPK2qdiZRewGCWImtgkF7Azw8jhEeRXsDTwfo/h5RewLyx8XdHkV7AjzLYkPyUXsBtfucKu5ZewJsBxuRBll7A7KNTVz6VXsAc0U/OdpVewA1slWBxkV7AjnVxGw2WXsCS40kwR5RewK+YEd4emF7AIXt731GWXsCmg/V/DpZewJ736NWsj17A9eKMrdyUXsCuxxIQUpRewLrD6c46l17AzI/CbDeSXsCUs0rFM5pewIKufQG9lF7A7zq4x9SRXsBXfGmolpVewJUfKB+xlF7A14uhnGiTXsA2ww34/JZewLu3VyMxlV7A5QrvchGVXsDhJw6g35VewJs+O+C6ll7Am4hqiZaSXsDwbfqzH5dewDjzqzlAlF7Aku18PzWWXsBw2ac30ZVewKMYFl+xk17AShdRyS+UXsC8yGcmNpZewMa2R5r4lF7ASgwCK4eUXsA+cV5uwJhewJtattYXl17Arl+wG7aXXsBjgW3MBJJewLlSjWaelV7AUI2XbhKRXsCPFS8oqZVewLztQnOdkl7ADqZh+IiUXsCBlUOLbJdewPuzHykimV7ASS7/If2RXsByLVqAtpNewIVf6udNlV7AysNCrWmUXsDzGrtE9ZJewHZsBOJ1lF7A14uhnGiTXsDKPPIHA5VewFu77UJzlV7ASbpm8s2SXsBJERlW8ZJewAFqatlakV7A6PF7m/6SXsDQSe8bX5VewHub/uxHkl7ABirj32eSXsBvIz3DFpVewCtvRzgtll7ApUkp6PaSXsDdDDfg85RewLdif9k9k17AukkMAiuRXsByFYvfFJZewD+uDRXjlF7A98ySADWTXsAawFsgQZdewOIA+n3/kF7AnLryWZ6VXsDAQ1GgT5VewHjuPVxymF7AeJeL+E6YXsBomxvTE5hewGdEaW/wk17Aq7NaYI+PXsAKYwtBDpZewC1DHOvilF7AdC7FVWWVXsBDrWnecZRewG3i5H6HlF7AYHZPHhaXXsDsh9hg4ZRewF8R/G8lk17AXqPlQA+VXsA8ZqAy/pVewL1SliGOkl7ACCC1iZORXsDBNAwfEZZewNAQBWi4lF7AmI78a0CTXsDyeqJ+xpRewL4ncX4Mll7AT4DnMgOWXsA1Tqh/p5VewCKKmeIpll7AOq+xS1SVXsDUejEn95FewKFxyqQyk17AkBGS/TqXXsDSiNuZcJVewLCEDup9mF7A7Ohujf6VXsBofj95+5dewDJY6LgXmF7AZlThG/+VXsCCFLGS05JewKOhFOcHll7AoYbKGvCRXsDanXG+kZRewNDW8frUlV7A0p3UVYmUXsBLZWZzMJVewGEzWCJklV7AfhKGnmCTXsAFz4fed5JewCg0z2XYlF7ASssg9RmXXsCIEkFdY5VewElxVpBbk17AUZME1KCUXsBMxIsgFpZewPUICsMtlF7APkS82GiVXsBiGXZzrJRewP/JPS8ll17AhEJBfxqVXsDqvMN2YpZewOq8w3Zill7AJll1wK+RXsDeekDlB5dewBI41QQYlV7A/SWsBMCVXsAyGFu8g5VewNesfJTmk17ASedAMqSVXsDHGTI6OplewDa5rWcnkV7AMhhbvIOVXsAyWOi4F5hewIr3LYRGl17AdSRV456RXsAKXm7clJRewO4wzUR2mF7A+q+Kb1yUXsALsN6UUZNewMTut01jmF7A0CGth8iUXsBtELDN+5VewPAek9FQkl7AA4zqUdGYXsBx6zb0K5NewOyez48Fkl7Ac68fpP+XXsAo3ho7dZdewLZTOw/jlV7Am2EI2KWVXsCsx+pHJJZewNjRVCmflV7ATYgPpUOUXsDRm6PxOJJewApkqQfCkF7ACmSpB8KQXsCkO7MdRpFewAiCu0QZkl7Av/HEkmOVXsDzyrOaR5FewFaCxeHMkl7AMuvFUE6UXsD/Ej9mKpNewDldFhOblV7AtdrDXiiUXsDMBplk5JJewIY97fDXll7AxmgdVU2UXsCBCdy6m5FewFfsL7snl17A6PF7m/6SXsAfbRyxFpFewF3Ed2LWkV7AAHmvWpmWXsB224XmOpFewFCIgEOolF7AnBvTE5aWXsBt3c1THZZewAU5KGGmll7AIQiQoWOVXsDT2cngKJNewDxO0ZFclF7AN6EQAYeSXsA17zhFR5RewFkSoKaWlV7AYhVvZB6VXsDIgOz17pNewCcUIuAQmF7Ac1DCTNuTXsCMvoI0Y5VewL6kMVpHkV7ARPXWwFaSXsBj83FtqJpewFFTy9b6lF7ANs07TtGVXsBxp3Sw/pVewItx/iYUll7AWRKgppaVXsCoHf6arJdewGBZaVIKll7AyAc9m1WTXsBfEfxvJZNewPeNrz2zlF7AwbLSpBSYXsCFX+rnTZVewGfQ0D/Bk17AaVch5SeRXsB/Tdaoh5RewFIrTN9rkl7ANJ2dDI6SXsCha19AL5hewAMhWcAEmF7A/BTHgVeTXsAOpmH4iJRewBgmUwWjlF7At11ortOSXsCqDrkZbpRewDankgGgkl7A7J+nAYOSXsArjC0EOZRewKuzWmCPj17AMzhKXp2UXsCJzce1oZJewCUGgZVDlV7AE+0qpPyQXsB4P26/fJRewFt2iH/YlF7AP8vz4O6UXsDPDyOER5FewOzFUE60l17Azw8jhEeRXsA3oRABh5RewBKlvcEXlF7A8rBQa5qVXsA5XRYTm5VewOc1donqk17Aj+TyH9KUXsBSRIZVvJFewB+duvJZlF7A4L4OnDOWXsBZEqCmlpVewHe5iO/ElF7AXYqryr6RXsCyogbTMJZewPeNrz2zlF7A6Ugu/yGVXsAYJlMFo5RewC9NEeD0kl7A7IfYYOGUXsCJXkax3JZewBy3mJ8blF7AoDL+fcaUXsBLPKBsypVewIZQpWYPll7AKjqSy3+UXsBy/bs+c5JewO84RUdyk17AiqvKviuSXsC6vaQxWpVewAKaCBuell7Ag7uzdtuTXsAHX5hMFZpewFUwKqkTll7AjL6CNGOVXsCMMhtkkplewIVf6udNlV7AcbGiBtOQXsBCW86luJRewD1+b9OfkV7A942vPbOUXsAlBoGVQ5VewHaJ6q2Bl17AVisTfqmTXsB0QX3LnJRewFAZ/z7jlF7AOpLLf0iTXsDB4nDmV5NewIEhq1s9l17A+KqVCb+WXsAuBDkoYZRewGIQWDm0lF7ASREZVvGSXsAqNXugFZJewM/fhEIElF7A5wXYR6eUXsD3ja89s5RewFaCxeHMkl7Af4eiQJ+RXsA2WaMeopRewFaCxeHMkl7AEAaeew+ZXsCsvyUA/5ZewCwsuB/wkl7AnLryWZ6VXsB0nUZaKpNewN/DJcedlF7A2jhiLT6XXsCJWS+GcphewD2Dhv4JlV7Awv9WsmOVXsCWtyOcFphewKjLYmLzk17AAOgwX16WXsBy/bs+c5JewD7t8NdkkV7Ai6VIvhKWXsAmzLT9K5VewB1ClZo9lF7Af2WlSSmUXsDTwfo/h5RewL+CNGPRkF7AzHUaaamUXsBt4uR+h5RewEhL5e0Ik17Aad1p31qSXsBjfy8+cpNewLPviuB/kl7AZpi8/AySXsDibJhz+ZFewAPI7AZzkV7AQIf58gKUXsAvasK5sJNewP4Vksmykl7AMuvFUE6UXsCP9j/AWpNewFFPH4E/ll7ABP9byY6XXsDJ6lbPSZFewPX+wM6tl17AMSBxS2iTXsDVWwNbJZZewMj0vtCHlF7AyAc9m1WVXsDRr86th5RewFCIgEOolF7AnLryWZ6VXsDP91PjpZVewCo1e6AVlV7A7EfZDqWVXsDPDyOER5FewO84RUdyk17AN7qo6HiTXsDPvvIgPZNewK2V6rHWk17AHg6ovXyUXsBkrSUNo5RewD8Wentykl7Ai063aNiVXsA7euKKIpVewOIA+n3/kF7AMzhKXp2UXsAWc/nXvpVewGUxsfm4mF7A3i1PO+qWXsC+K4L/rZRewAVR9wFIl17A9dbAVgmUXsCej29F25RewFhZ6j/8lF7Aq8oPc4GXXsDFpz17R5FewBwDste7lV7At11ortOSXsDgpMQJR5hewEMc6+I2lF7ADHva4a+WXsAmOzYC8ZZewIoeKFLikl7AoDL+fcaUXsAEPj+MEJZewOkmYUHCmF7AHVA25QqRXsDV8ZiBypJewFH2cKs7lF7AIjGzYkeRXsD8ODf5T5RewBPVWwNbk17Ar+yCwTWVXsCjejhvRpFewK39OsMWlV7AzEHsJlqWXsA5PvopRZNewPZVONBjlV7AWYKMgAqVXsDs96MsTJFewIBeN/MrlV7AdnEbDeCVXsBrDhDM0ZVewB3ppKinkl7Ah2WR+GWTXsCIujBOs5RewKJdhZSfkl7AzGd5HtyWXsAdUf8rm5VewBgJbTmXlF7AXW3F/rKUXsCKH2PuWpRewLBamfBLk17A1Lt4P26VXsAFi8OZX5NewH41Bwjmkl7A2SH+YUuTXsCOdXEbDZZewO/Jw0KtlV7AFaQZi6aTXsDU00fgD5NewPvG155ZlF7A1BOWeECVXsBVSPlJtZNewDXSUnk7lF7AN6EQAYeSXsBFTIkkepVewIVkARO4k17AqmqCqPuWXsAZijve5JlewI51cRsNll7ATyMtlbeVXsCqSIWxhZJewDJaR1UTlF7Anzws1JqSXsBYPsvz4JRewDxO0ZFclF7ANBZNZyeRXsCvDRXj/JNewApjC0EOll7AJe6x9KGXXsALRbqfU5RewIF4Xb9gk17Aa7sJvmmUXsDoacAg6ZVewEasxacAlF7Ahy6ob5mTXsDqlbIMcZJewKrx0k1ill7A4WJFDaaTXsBlqmBUUpVewAmi7gOQlF7AA0S0YkeRXsAnqrcGtpBewL6kMVpHkV7A/5qsUQ+VXsAhN8MN+JBewP0ORYE+lF7AatRDNLqPXsBAn8iTpJFewMQlx53Sk17AzvxqDhCUXsCEmbZ/ZZdewKWg20sakV7AhlClZg+WXsCZo8fvbZJewBIsDmd+k17AOE91yM2UXsA8NgLxupRewA9/Tdaol17Aqbwd4bSWXsC+E7NeDJZewAtFup9TlF7A5X6HokCXXsBGDaZh+JJewLPviuB/ll7AweJw5leTXsAxDcNHxJRewO/ErBdDkV7AvCL430qRXsBgArfu5pVewApjC0EOlF7AVmXfFcGVXsBcd/NUh5RewBn/PuPClV7AJV0z+WaZXsBv8IXJVJFewIAr2bERll7AOS140VeSXsB4Bg39E5hewIiFWtO8lV7Azw8jhEeRXsBeo+VAD5VewFCIgEOolF7AV3OAYI6TXsBk0XR2MpZewIulSL4SmF7Arkz4pX6UXsC43VzguJVewEOtad5xlF7ABd1e0hiVXsAUs14M5ZJewBKDwMqhlV7ABvpEniSWXsDsOel945BewKWl8naEk17A+KqVCb+SXsAfbRyxFpVewLhAguLHmF7AtRX7y+6TXsA17zhFR5RewB4Wak3zkF7ADeVEuwqTXsDNQGX8+5ZewAN9Ik+SmF7A0ocuqG+VXsA7dHrejZVewG3i5H6HlF7AxJlfzQGUXsBUbw1slZRewFH2cKs7lF7AcpBPSQ+VXsAAjGfQ0JNewPXijK3clF7ApgpGJXWUXsC6w+nOOpdewI/MI38wlV7AJCNnYU+TXsDX3NH/cpFewEw3iUFgkF7ASGZEVauUXsBqx7m/DZVewLLbrmpFlF7AEIPf15+RXsDP2FCXsJFewDSmIyq7kl7AfAj+Rb2WXsB6GCWrzJVewFY4Xo6ykV7AuyC4UA2WXsDxkp9X05ZewBCPTb3xlV7AmldwndGTXsASJ+3JoJVewMgMVMa/k17ASCbLPF6RXsAIMc/+y5JewMOv+FD5kV7Arf06wxaVXsC8k166epFewBBglhi5ll7AFEuAUG2SXsAhYHB3nZRewEk4EyQNll7ApKjir9GVXsC8E4Eky5JewBL3B7MRl17AtPpDY6iWXsB5WaZuTZRewIJnvFlVkV7ArwTEt9+UXsCJWS+GcpJewOhmf6DclF7AyNSXhM+XXsDzcLZEhJBewNyibpUXk17AFD/VB6OUXsCIujBOs5RewPFrtLREkl7AKRsvDb6QXsC7ylkmA5VewAXC16Iol17A83C2RISQXsCyC7DWQ5ZewIEoavmZlF7ArwcK8SWUXsDT4l4pQ5VewFsKJ+22mF7AD5OthIeUXsBlxsln05RewIJ58Fydkl7APxZ6e3KSXsBRbsRbU5RewHq6jeJJk17AFD/VB6OUXsCeX5Sgv5RewNq7gEO6mF7AF5WVpSSSXsAycohLPZJewIBeN/MrlV7A9Dw+ddqZXsC1tSC8H5FewBuKVHvFkl7AP+LqD3OTXsA9YKcj45FewMvydRmekl7Ai75uUNySXsCLsWVcZZVewJ6Jg2AClF7AeugWFQyWXsB7/N6mP5NewGqrhZ78kF7APDT+DVKSXsDYEa0zg5FewIEmwoanlV7AvLHxd0eRXsBgWWlSCpRewHJlRvu8lV7AIWBwd52UXsAUG7mPOJVewJf5KtNxlF7AxWrsRcaTXsCU6R55ypJewGDNAYI5l17AHVNCc+eRXsCXxLw70JZewAsfw8MRll7AgF438yuVXsA5RUdy+ZFewHmql20Ull7AZeDCsiCTXsCIujBOs5RewNhnjN4iml7AdbBZiRSWXsB0ORT0zZJewIiE7/0Nkl7A1sVtNICTXsBvDWyVYJVewIPF4cyvll7AxoHbA+KRXsCt/TrDFpVewJwui4nNlV7ArnGbSIeUXsB87ZklAZhewACnidQalF7Azw8jhEeRXsDeq1Ym/JRewHkB9tGpkV7AozKsf2OVXsDhehSuR5VewNcmPgxHlF7AMMA+OnWXXsBQqhoQA5ZewEJJiL/0kl7A7J+nAYOSXsBgzQGCOZJewHWwWYkUll7AcQM+P4yVXsCljwX0vpFewLztQnOdlF7AIdacNfiRXsDRyK1qJZNewGJy7J5xlF7A5ejqwRaSXsBZ6ZWCE5ZewOslr5YHmF7Ar60jN7iSXsAv02YESpVewCntDb4wlF7AIMVFXUeRXsBEZIb9hpJewL5D57uvll7A0a/OrYeUXsDOrN8rvpJewBn/PuPClV7ANgaiyROUXsAZ/z7jwpVewAjbzkWjlV7AYSC5Sa2VXsALsI9OXZFewG/yKzs8lV7AcY+lD12UXsBKY7SOqpRewEpjtI6qlF7AIWBwd52UXsDw4VDHXJRewFi3AIgJl17Ah7083I+UXsDRr86th5RewPjDz38Pll7AlSHL2KmRXsCvlGWIY5VewOu2IGhgk17AVk4nSwCTXsBH/mDguZZewKazk8FRl17A0SNV+hqUXsAZc6QhrZRewNzfwoJHkV7AV89J7xuVXsBQXQOfIpZewEirhVIOll7AFaQZi6aTXsAMEnBCAJZewGRFDaZhkF7A155ZEqCUXsB8fhghPJJewOwvuycPlV7AA08QK3KUXsCcMjffiJBewHP0+L1NlV7Arwj+t5KTXsCt/TrDFpVewH1gx3+BlF7A2yXNxjqWXsCzNMzd4pRewG5MT1jikV7AeJeL+E6YXsDSjEXT2ZNewIQlHlA2lV7ANAxhLeWZXsB9Oh4zUJVewOJw5ldzkl7ARdBwgaaTXsDwE5DBzZRewIBIv30dmF7AsRfpycWUXsC0oKR+xpRewFg/T2bwk17AKcQrYtuRXsBN845TdJBewN/eaNkQlV7AQIwQHm2XXsB2S3LArpJewMrbEU4LlF7ASeE9sTWTXsAD+F3HbpNewG0nHAqXlF7AhjBgxByUXsCaIOo+AJdewPBjG6T/l17Ar60jN7iSXsCqN69Z6pRewMj0vtCHlF7AvJwF5lCXXsCkNU1y/JBewDgDA9illV7AEmMs4tqUXsA7WP/nMJNewMWnPXtHkV7A/wkuVtSWXsC+MQQAx5JewDeJQWDlkF7AcQM+P4yVXsD3ja89s5RewIleRrHcll7AH20csRaVXsDicOZXc5RewETiHksfkl7AqD/7kSKWXsBCW86luJRewFFJ0HGrk17AdlQ1QdSWXsACnx9GCJdewHQ8ZqAylV7A+SzPg7uRXsCaIOo+AJNewGPzcW2oll7AbT6uDRWTXsAfbRyxFpVewHhjQWFQll7AopxoVyGRXsD10akrn5FewJ87wf7rlF7AnzvB/uuUXsDoZn+g3JRewKN6a2CrmF7A0ugOYmeSXsCcilQYW5ZewGrZWl8klF7AnG7ZIf6TXsANiXssfZJewOC+DpwzmF7AnNzvUBSWXsA6kst/SJhewKpqgqj7kl7AABjPoKGUXsDBstKkFJZewGkYPiKmlF7AlltaDYmVXsB2+qSHH5BewKzGvNVNk17ASOUw3PyRXsCK7bZXG5RewNqCvw5llF7A/3VDWjCWXsCLQ6+fu5VewOlXLqyflV7Anvfo1ayPXsA+RLzYaJVewEN9GSz/kV7AL+9TUC+WXsB0ORT0zZJewMlEqiVGlF7Alt/6lOmTXsBPT1rjTJRewJsgyTD3kl7AeVmmbk2UXsAQcQaOCpNewH/rjdEPkV7A0CGth8iUXsAyFt7JzZRewHRLGr8KlV7A/e6ul+ySXsBvIz3DFpVewOAGLu8nkl7AjxKxRISQXsBZbEJDh5RewBXemZTYlV7AcIzA/4aUXsAFDgh3/pdewCRDBbzpkl7AXs4HLAKTXsAbIAj4ZJdewARg3hHFkF7AvBUGiAmXXsA/hAIAMZZewBuoUR2SkF7A/pgJmPaUXsA+7fDXZJVewLa/uPYTmF7ADbz/NJqWXsDYFDLRzJJewG+NRyqlll7Aa38yiUSWXsAmrLgxsJNewJCHr5Bok17AajdnNT6SXsDU682qmpNewNTrzaqak17APObtHIuTXsDadLBwZZVewNVrvyTxlV7ARrVY72+TXsB8BkmpCJRewMi5GscSll7APkS82GiVXsA3X9uRQJdewF4DeXtykl7At1JWc2OVXsCLdtjuZZdewFcRNojrkl7AgDBxXdGVXsAv35eGo5RewEfJOR7El17ARBfUt8yXXsC1KYmyGJJewLj8j2UElV7AwYNIgWOVXsDyyS8oOJNewK4KRrj4lF7AXUOKsAqTXsDrDqaEh5RewG3i5H6HlF7A3wZcJ/OSXsAMVmwxl5BewN6p8tAmlF7AGri15VmSXsBuTepm55JewOaBLU6zlF7A+8u513ORXsCCUYu5spRewGPQs6Dqkl7Ay3afklyUXsBD4oYuVJVewOqIS6c4ll7A9c2Jf3CWXsBDKTE6JpZewMi5GscSll7ACn7w4V+VXsCKlcSehZNewEMesmJHkV7AdyxOZvCTXsCDmozwt5JewKbVYH/RlF7AuqQZdAqVXsB7FWWrVZVewFxob28FlV7Alx6UyvCVXsB0JJf/kJRewEQvj3RHkV7AVc+ipyOTXsDZsOjOOpdewDc7axrol17A5Pc2/dmVXsC3vL5LU5RewDoLHWmAlF7AeDrCL7aXXsAb44iKWJVewO2RHJxnll7ABN1r/FqTXsD5wbxxOZZewNtWUKRdll7AkTiEWo6TXsAZHQeTH5NewHlZpm5NlF7AKouzAz2VXsD71tDLXZRewMCl/qItlV7AQZWx2YWTXsDv7QWCWpFewLg2VIzzk17A7PejLEyRXsAWiBDqMZNewPaYbjC5kF7AOhslwZGUXsCe71Z/DJZewJAxdy0hk17A1MGhh3+TXsDmgS1Os5RewGu+hOlfkF7AmuUG0WeSXsBOjnKYnpJewNh88jZKkV7A7MhjlhWXXsB19WWU55VewJthCNillV7ASPDxz02VXsBL0n5pRpFewAWmrfMKlF7ANtQgszCWXsAc/EGA85RewCaMZmUbll7AtT2ii+uTXsDlGKCfb5VewNwpUJ1klV7AwTQMHxGWXsC87UJznZRewGc1acISmF7A4zsx68WWXsAd4bTgRZVewBe86CtIkV7AEd+JWS+WXsAeiklSTpRewKMjufyHlF7AB2Svd3+UXsDanXG+kZRewIVkARO4k17A2czxb++SXsDGVWXfFZVewDVbzcgNlV7AdVfoFimTXsCodysqZpZewCxNSkG3kl7AzSEb27qWXsDYFDLRzJJewNgUMtHMkl7Avpvj5riWXsCcwZhaupJewNzz7T72kl7AV3xpqJaVXsDanXG+kZRewHDZpzfRlV7ACzQc8jaOXsBs1VCYB5FewN0UeO90mF7AkIevkGiTXsBLZWZzMJVewDM4f1Btkl7AP3ylm2CTXsAfO8YaEJRewL7p2jr/lV7A1hn7bCaUXsCF783UA5VewJyKJN/El17AhrDd5/+WXsC4I/fPTpNewGuIaWA9lF7AuVKNZp6VXsD4AcntN5ZewNh88jZKkV7AeKFgljuZXsCAXBpzQpBewOlyC9wIk17Aw5jJd5aUXsAE3/+KhpBewHwI/kW9ll7Ag4I+0OuUXsAuVeCZLZJewDUFb54Dl17AITNhRfeTXsC4I/fPTpNewOC5e6lNkF7A25RqIA+VXsBgaRuqQpRewKFinL8Jll7ARg2mYfiWXsBTrvAuF5VewB/0bFZ9lF7AQ61p3nGUXsBzY3rCEpdewJ0pdF5jlV7AF6WEYFWTXsDnjCjtDZJewNCvrZ/+lV7A942vPbOUXsDNO07RkZRewG8NbJVgk17AyjzyBwOVXsA0uoPYmZRewOMZNPRPkl7APbMkQE2SXsCS5/o+HJRewDDYDdsWlV7AiVkvhnKSXsDlCu9yEZdewNeeWRKglF7ANXo1QGmUXsALndfYJZRewBWpMLYQlF7AyQImcOuSXsDsaYe/JpFewAmFCDiEkl7AEHAIVWqSXsCjAbwFEpJewO/Jw0KtlV7AMlab/1eTXsDysbtASZVewBUdyeU/kl7Aad/cXz2UXsDFpwAYz5RewPSEJR5Qkl7ALhfxnZiUXsA+kSdJ15RewHgGDf0TmF7AAwmKH2OTXsDKbJBJRpRewOJ1/YLdlF7AvqQxWkeRXsDyPLg7a5VewMSxLm6jl17AwmosYW2SXsCQuMfSh5RewI/MI38wlV7A4ZLjTumSXsBXW7G/7JRewM/3U+OllV7AXtcv2A2VXsBPqn06HpNewGlXIeUnlV7AOdGuQsqVXsCwj05d+ZJewPW9huC4ll7AueS4UzqWXsCWW1oNiZVewHL9uz5zkF7AxY8xdy2XXsCP9j/AWpNewNQTlnhAlV7Au5unOuSWXsD5vU1/9pRewMnlP6Tfkl7Azw8jhEeRXsBVpMLYQpRewA97oYDtkF7AzqYjgJuTXsATeZJ0zZhewCuC/61kkV7A0ETY8PSSXsCh8xq7RJFewDehEAGHkl7ABaOSOgGVXsASoKaWrZdewJC4x9KHlF7AcRsN4C2SXsAPe6GA7ZBewGibG9MTmF7A0NVW7C+RXsCLpUi+EpZewJm7lpAPll7A942vPbOUXsDD3Vm77ZRewH51VaAWlV7Aelc9YB6YXsASiNf1C5RewD/L8+DumV7AKePfZ1yUXsAtrYbEPZJewAjE6/oFk17AVoLF4cySXsDZPXlYqJNewLLROT/FkV7A7C+7Jw+VXsDGaB1VTZRewJ5flKC/ll7AIGPuWkKUXsCBeF2/YJNewIzzN6EQk17AAOgwX16WXsCDF30FaZZewISezarPj17Azw8jhEeRXsALsI9OXZFewEYE4+DSlV7ASNxj6UOZXsCKtI0/UZFewLWhYpy/kV7Az2vsEtWTXsBskElGzphewPC/lezYkl7AesISDyiVXsBx5eyd0ZRewDnRrkLKlV7AR/5g4LmQXsCvCP63kpNewPjDz38Pll7A942vPbOUXsCPzCN/MJVewA5FgT6Rk17Av4I0Y9GQXsBoy7kUV5FewN7lIr4TmF7A+8xZn3KWXsCiXYWUn5hewIvJG2DmlV7AoswGmWSSXsAWE5uPa5FewA97oYDtkF7A9FSH3AyVXsBn0NA/wZZewF6j5UAPlV7AsUtUbw2WXsCVZYhjXZBewIeiQJ/IkV7AiSmRRC+RXsAQQGoTJ5VewHIVi98Uml7ANddppKWSXsAfbRyxFpVewP8mFCLgkl7Asi5uowGUXsDzAuyjU5NewADoMF9eml7AQla3ek6WXsBbzqW4qpRewKr26XjMlF7Azo5U3/mVXsA8odefxJFewO/Jw0KtlV7AXI/C9SiYXsAxQQ3fwppewCcs8YCyl17ADche7/6UXsC6SQwCK5FewHEbDeAtkl7A78nDQq2VXsDjNhrAW5VewG+Z02Uxk17Ahj3t8NeSXsCJWS+GcpJewBe86CtIkV7AxmgdVU2UXsAcA7LXu5VewFjFG5lHlF7AiqvKviuSXsBxGw3gLZJewF5/Ep87k17AkLjH0oeUXsACmggbnpJewJ1oVyHlmV7A8rp+wW6SXsBt3c1THZhewBIZVvFGlF7AZmt9kdCWXsADeAskKJRewBgJbTmXkl7AJQaBlUOVXsCRgxJm2pJewDw2AvG6ll7A0a5Cyk+WXsDK4Ch5dZJewApQU8vWkF7Ag584gH6VXsDB4nDmV5NewJY+dEF9k17AesISDyiVXsBRZoNMMpRewAtFup9TlF7A9wFIbeKSXsB2cRsN4JNewG8NbJVgk17AP96rViaWXsC+E7NeDJNewPWhC+pblF7A3NyYnrCRXsDLuRRXlZFewIulSL4Sll7AmiUBamqRXsBrn47HDJZewJLjTulglV7Av4I0Y9GQXsAFo5I6AZVewMe/z7hwmF7A942vPbOUXsAX1LfM6ZZewKLMBplkkl7Aol2FlJ+UXsACnx9GCJdewKTfvg6ckV7A5wDBHD2SXsBhvrwA+5BewEBqodFulF7AHJ/aKlKSXsCBft+/eZdewDnMlxdglV7A02KGTC2WXsBMxIsgFpZewKobDpwqlV7APKWD9X+SXsCeihm27ZhewEqarEJklF7AO2/7z06TXsD2qdfrJZVewHVgIqawlV7AE8Pl42CVXsDWbrvQXJNewMa4c0UPlV7AUJHvxL+WXsBqCMktRpRewE0ml5Q1lV7AmX6JeGuWXsA/Fnp7cpJewNGvzq2HlF7ARSeu11KaXsBs3SQLepVewBKlvcEXlV7Aaics7KeRXsAxKT4+IZVewFZMaDwYmV7A2bDozjqXXsCq7jYU45hewGUlq/dblV7AiMRoFjuSXsDM6jnDFpVewGqRfShik17AuPIiq8yVXsB3lCwiqJVewL9VbAZ3k17At0MUqtOTXsBZypyoMZRewBWuvu9ck17A+uI0PxyUXsAq2u9lT5dewHvFG+VVlV7Ak29lchKXXsDqT24dFJZewHnVPZELkV7AJMEwbVOUXsDqYBY9xJJewN/s9T+3kl7Ai6VIvhKYXsC/VWwGd5NewH6KuEAPlV7AseHplbKUXsCxQdiJqJZewDV2ieqtk17AP9DhjCeaXsCv/pD9OpdewLyx8XdHkV7ANiYQ6zeXXsCxa0uCr5BewFWOcCqXl17AzAuwj06TXsDrrbHmKJZewItx/iYUll7ADkqnlGiWXsC8sfF3R5FewHJiCDMfll7AqGTBQz+VXsBXf98ac5FewL2Hz8a/ll7A4Wjgqt+VXsC8sfF3R5FewDErauk3lV7Am/pXjmSVXsDM8+DurJNewI0NrbM5ll7AcmIIMx+WXsByYggzH5ZewFkpByr4kV7ASA7gRk2SXsAhI9D7Z5RewDPEsS5ulV7AU0ewObOUXsC5AZ8fRpRewL+lpqFplF7A7Widam2VXsAuc7osJpRewLLv/DWolF7A4Fd/YDuXXsCucZtIh5RewDw0qA0Zl17AlltaDYmRXsC8sfF3R5FewE1wjJKnl17AvLHxd0eRXsBWE7F5lpFewATBZxQgk17AJaez6cGRXsC7ILhQDZZewPa8NKiqlF7AIjGzYkeRXsAvUzC2kpNewC9TMLaSk17AykyFUp2UXsDRr86th5RewHMGYLI6lV7ATrJHOz2TXsBmS50axJJewHRJAPdvll7ArRIsDmeWXsA6WEEEA5VewFaCxeHMkl7AohKfh4+WXsDs96MsTJFewD8sv//7kl7Azw8jhEeRXsCpaeLgXJRewN6OcFrwkF7A0ovVRPGXXsCQ3+VmO5RewPvalb4Zk17AS3FLZ4SVXsB5qpdtFJZewL6kMVpHkV7A3+z1P7eSXsDwHpPRUJJewJVyO1e7lV7A3f6U3uKRXsAe/pqsUZVewPPltJBok17AHkDLYv6XXsCIujBOs5RewPWQnXX1kl7AO5DZf7uUXsDc38KCR5FewDUhQ00ol17AJEKLu82UXsDRyK1qJZNewDDu8uzzkl7AlC7SyzWVXsBZVZxbQpRewN0meQEYll7ABtSMJkaUXsAyihiIu5FewNpot5jqkl7AmQQP1taWXsDwYxuk/5dewA3ndR+7kV7AZh34ktKWXsAF5DQMq5NewASSGFP8kF7A/svCkmOVXsBzW67ACJRewEVuFscSll7AundvbQqXXsCIujBOs5RewEq6oJ2XlF7A1LK1vkiRXsCq2QOtwJRewFaCxeHMkl7Ahj3t8NeWXsBPdQrqopFewN5YvbSCkl7Awykd8xSTXsD37o/3qpNewNTtCIGemF7ANkSWfsKSXsCgS7dzoZFewM5+APkClF7ArkfhehSWXsDn1rUHy5JewFlqvd9olV7AhJm2f2WSXsBaJ6PUwpVewMEcPX5vl17AoGhtBneTXsChOrtUI5ZewNg/jGaelV7AABpZvfmUXsB0O3pKDpZewIZQpWYPll7AaIsLCrqSXsB+P9fsOJNewNX4kcrwlV7A3FAxzt+SXsBVIHhRm5NewKeciq+RlV7AGks/fuKRXsB0yWZ+fZRewDblCu9ykV7Af7/aSUuTXsB1sFmJFJZewNh/37dIkV7AN3kJz92SXsBw2ac30ZVewIbZ5Qq4lV7AFykG21eTXsBEfbu6vZZewAAQ0K0SlF7AJF4B+VCUXsApQOSSopVewKTfvg6ckV7AxTh/EwqTXsBlxsln05RewJ93Y0FhlF7AIOo+AKmXXsBn0NA/wZZewGhG5mGGkF7AqacQQfWSXsCbYNpl75RewIzOZMVRlF7AJlnTMbGQXsBMIsN2zJhewDJY6LgXmF7A5WkX2GWQXsDNWDSdnZRewKcAbM5OkV7AXqcX0FmVXsCEMScKgpdewEirhVIOll7AGlHaG3yVXsBdlxyiCpRewFjUjZutk17At8ORzRaRXsAcHv9bopRewGzsf3FKk17A8+W0kGiTXsCOBvAWSJpewDlDwg7bk17ABBGGWkOTXsCsxacAGJZewKJG7tdHkl7AxBUL1OaUXsDYZSiJzZVewMhgXcYhlV7ANLr1LaKUXsDKPPIHA5VewH/bpoenl17An3djQWGWXsAcpy0d75BewEwfuqC+lV7AnkYnOcqVXsCVnRZtApRewJI71AWIlF7A/YVgTeyUXsCbYNpl75RewG59FFJXk17AcXInJ0aUXsDZaZw0CpJewN3hn+cJll7AwXN9jEqTXsBq2rYJZpJewOcl1hSOkl7Ahy6ob5mTXsBhILlJrZVewLfdqG4elV7A8P54r1qRXsA5Q8IO25NewGhxwXctl17AIFrLZ3CTXsA4AwPYpZVewJC2pZkkmV7ABAafn2+VXsBOwqOSXJRewExOLyklmF7AtT2ii+uTXsC/8cSSY5VewH7xKyeYkV7AlUzcl2SSXsAAtySQHZhewEVuFscSll7ANZ2x8HSXXsDQHPmGeZNewAMPnMuekV7AVc/GbRuUXsDp2w2YQ5RewOIA+n3/kF7A0vNncmOVXsA+VY13ypJewExVd7iflV7A9ovcSuSQXsBXyJTDMpNewMaCIBLOkl7A+Uk5iOuSXsBdQ4qwCpNewPSzAInAll7AAWlxWTSUXsBtSF/lCZRewP2AfBOHk17ApDwe8xSTXsBV8V2CR5FewPNH1OgOlF7AR1AYbiKZXsAKdGqKR5FewOebAtMIkV7A0eKU0vaSXsCpE9BE2JRewHZiIBn8lV7A33YBLJuVXsDv5NNj25RewMi5GscSll7AyxoTZyeXXsBJBHhFD5VewN1srsUHkl7Avpvj5riWXsDjgXqT3JFewCmhVPicmV7APOPkRl2RXsAkGJdCcZRewEaka/t+lF7ApfS0EsaTXsDGgiASzpJewBZ+6gSmk17An4YrRICTXsBjfy8+cpNewJH6s2u3kl7AMv4QKteYXsDzcLZEhJBewAMWr2gJlF7AeaqXbRSWXsAAojVG2JVewGBWGacQk17AdAzIXu+SXsBFHz2P25RewO3iiWIKll7AfbJTjU2UXsA2H9eGipVewOazqatckV7AFJS0eFeUXsBFbhbHEpZewAmFCDiEkF7As2hYkVOVXsAvoU3RG5VewA3Gjf06l17A5u6/CvqSXsBvD2gHYZNewA+TrYSHlF7A8Ev4A7CTXsCW2IeFcphewKqKklgelV7AVkv9ZkmTXsCmpRDN/pVewLdBHfEMml7APMZw0PmVXsDmB7OrfpRewGEguUmtlV7A3zVxPY2RXsAFyPsx4JJewL/OoZqflF7Aa/jHj9mVXsDfXCnv1pJewEPFOH8TmF7AZJxww/CSXsCy7/w1qJRewL954TaJlF7AXqJ6a2CTXsDD8BExJZZewAw2dR4Vl17AIjGzYkeRXsDlwH2tA5RewKyFt9nolF7A7AkVkwyWXsCEWADKFJZewOH1xDM7l17AqWni4FyUXsD4JzXX0JZewBuLC985l17A4jtzBxiYXsAKzjxgTpRewMBbIEHxl17Aajg87wyVXsAyPWGJB5hewLMBmRzlkl7ATpHoCruWXsA8jAwcl5VewK5H4XoUll7AFykG21eTXsA/Q+7YHpRewLNW3bjflF7ALgQ5KGGUXsAg1ND8jZJewKau2geJlF7A/5fnmJ6WXsBieBXnYpNewLzvc9cNkl7ApwBszk6RXsCPWItPAZpewAyaEiAVlF7A5AXRjUKTXsAGQ1BHvZZewClA5JKilV7AfEX5emWSXsDSpMudpJFewOUvNKS4ll7A0u+if6eVXsD/gJexEpdewJh6e6+4kF7A2D+MZp6VXsBRq+/JEZdewBdkDQ+olF7AfEX5emWSXsA4AwPYpZVewCxaUzUulV7AeWnw4nCSXsB7KrRnJ5FewPXmK9n1kl7AyBliczCVXsA6+pdYJJVewPljIPB8kl7A8+W0kGiTXsCy9G4aRZNewGjNgJRHlV7AaHHBdy2XXsD4Rrmj+5NewE6AcCQhkV7A8fRKWYaUXsCIND5UeZNewLMBmRzlkl7A2ZZuAxiVXsD7eRYu0pNewPG2aIdzlF7Al6IdtluVXsCgaG0Gd5NewGW8lFf6kl7AkxOScXGSXsCeRic5ypVewG6sraAVll7AlSAFSsiYXsDRyK1qJZNewCuC/61klV7A4+IxzuKRXsAncHZhh5RewKlp4uBclF7AvctFfCeQXsCDjMyYDJZewEgO4EZNkl7AhlClZg+WXsCe0sH6P5NewC5zuiwmll7ANwLxun6TXsAyLpbOOZRewJnAT0o4lV7AtBrJICKZXsBrEyf3O5JewGEcYfOfkV7AvLabBiOWXsCgaG0Gd5NewEocfNggkl7ABb22BauQXsBTHXIz3JRewLyx8XdHkV7Asu+AbgyTXsBIDuBGTZJewCDFRV1HkV7AEs7ZyPaTXsDnJdYUjpJewGU2yCQjlV7AEGYxtrKUXsDIGWJzMJVewCYW7hh7k17A51NxKgySXsDesJjRYpJewGEguUmtlV7AN98R4JeVXsDZj6qsQZZewK4yRjC9mF7Aq1Bg3hyaXsAeDqi9fJRewLdFmQ0ykV7AebX1NkqRXsByMA1WC5ZewA/zqKJfk17A2xFOC16UXsAP86iiX5NewALLSdzumV7At0Ed8QyaXsD3mczbRZNewKRV2el6ll7ANlmjHqKUXsDYIJv9xJBewO2BVmDIkF7AGfcwxWaVXsCAtf06FpNewD94V7eGk17AAQQgrM6TXsBgXVx90ZBewKqUDj4jlV7AHesuxV+YXsDc38KCR5FewDw2AvG6lF7AHquUnumTXsChvXGHSpNewDpYQQQDlV7AV8LiieOQXsAM4qiBS5RewE6AcCQhkV7Ar+EzI+2UXsDc38KCR5FewO6ElCjGk17AHaz/c5iTXsBx8G4tn5RewD0L+6MTmF7AMoq6FjqXXsD3ja89s5RewKdnpwr5kV7A78SsF0OVXsD2vxL+W5JewKlp4uBclF7AobSQsAqTXsCDpWSAfpRewKipZWt9lV7AjgbwFkiaXsD15ivZ9ZJewOK2BIBNlF7AKAIbXjCWXsBI5afqfpVewBm2CLotk17AMj3qeoWTXsCWW1oNiZFewHEbDeAtkl7AjNS9RnmVXsBNERPm85JewND5R+Sdk17A078VaryRXsAIbiilNZRewI6FRIEOkl7AgF438yuVXsDfXhY2qpFewNzfwoJHkV7As6JK8O2TXsDqT+rkL5FewM6tNh3Gk17ARrM7b0aSXsALt/jrQJdewCegAL9Dkl7AZ0Rpb/CTXsAusB1FY5VewKkvN1eOkl7AKcQrYtuRXsBtxf6ye5RewDQRNjy9ll7AjraZJkaUXsAj8QRYapJewKau2geJlF7AyfMlw82SXsDLFd7lIpJewI/f2/RnkV7A95LGaB2TXsBDNLqD2JVewCtvRzgtll7A7C+7Jw+VXsBslWBxOJVewMczaOifkl7Ae4hGdxCVXsAZ4lgXt5lewJm7lpAPll7AVpqUgm6VXsA5ud+hKJdewHQMyF7vlF7A942vPbOUXsDXNO84RZNewGUe+YOBl17AXW3F/rKRXsD/HVGhupdewGsOEMzRlV7ArIvbaACVXsAFwHgGDZdewGpSCrq9kF7ARs7CnnaYXsCBeF2/YJRewFWkwthClF7AfXiWICOWXsA8TtGRXJRewNrO91PjlV7A3BK54AyWXsDuCKcFL5ZewKr26XjMlF7Ax0/j3vyWXsCIS447pZdewFaCxeHMkl7AyxXe5SKSXsDQSe8bX5VewPeNrz2zlF7AXcR3YtaRXsD0VIfcDJVewP3epj/7k17A/d6mP/uTXsA4T3XIzZRewIzbaABvmV7ArfpcbcWWXsBL0jWTb5ZewMwGmWTkkl7AseHplbKUXsDNQGX8+5JewNAsCVBTkV7ARUdy+Q+VXsC3uTE9YZVewG987ZkllV7AxRuZR/6SXsC+h0uOO5VewG8NbJVgk17AtHHEWnySXsBp39xfPZRewA==","dtype":"float64","shape":[2915]},"size":{"__ndarray__":"AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAfJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACAn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAHyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAICfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAICfQAAAAAAAcJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAgJ9AAAAAAAB8n0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAAPh/AAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABsn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAICfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAAAA+H8AAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAgJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAISfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAACEn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAAPh/AAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAhJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAcJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAbJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAGyfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAGyfQAAAAAAAAPh/AAAAAABsn0AAAAAAAICfQAAAAAAAbJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAhJ9AAAAAAABwn0AAAAAAAHCfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAdJ9AAAAAAABwn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAHSfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAICfQAAAAAAAgJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAAD4fwAAAAAAgJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAICfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAICfQAAAAAAAgJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACAn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAgJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAhJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAACEn0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAISfQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAhJ9AAAAAAACEn0AAAAAAAHifQAAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAeJ9AAAAAAAAA+H8AAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAeJ9AAAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAHifQAAAAAAAAPh/AAAAAAB4n0AAAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAbJ9AAAAAAABsn0AAAAAAAGyfQAAAAAAAaJ9AAAAAAABon0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAISfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAhJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAAPh/AAAAAAB8n0AAAAAAAISfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAACEn0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAAA+H8AAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAAPh/AAAAAAAA+H8AAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAAB8n0AAAAAAAHyfQAAAAAAAfJ9AAAAAAACEn0AAAAAAAHyfQAAAAAAAAPh/AAAAAAB8n0AAAAAAAISfQAAAAAAAhJ9AAAAAAAB8n0AAAAAAAAD4fwAAAAAAfJ9AAAAAAAB8n0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAAPh/AAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAAAA+H8AAAAAAAD4fwAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQAAAAAAAhJ9AAAAAAACEn0AAAAAAAISfQA==","dtype":"float64","shape":[2915]}}},"id":"588f4be0-df1a-49a7-b365-dbbd443bf641","type":"ColumnDataSource"},{"attributes":{"plot":null,"text":"Gun related crimes on Different location"},"id":"20360560-6745-4346-a1ff-01172e85e862","type":"Title"},{"attributes":{"plot":{"id":"3c47ed94-c527-4ee4-962c-3b8edca17ee5","type":"GMapPlot"}},"id":"da8d4ee7-6d61-4aef-83a5-813feed9fd46","type":"PanTool"},{"attributes":{"bottom_units":"screen","fill_alpha":{"value":0.5},"fill_color":{"value":"lightgrey"},"left_units":"screen","level":"overlay","line_alpha":{"value":1.0},"line_color":{"value":"black"},"line_dash":[4,4],"line_width":{"value":2},"plot":null,"render_mode":"css","right_units":"screen","top_units":"screen"},"id":"a4373d93-833b-473f-a967-0f64bc7d8995","type":"BoxAnnotation"},{"attributes":{"fill_alpha":{"value":0.7},"line_color":{"value":"red"},"x":{"field":"lon"},"y":{"field":"lat"}},"id":"76e214c8-3af2-4860-a56f-f2a428228d01","type":"Circle"},{"attributes":{},"id":"8e357aa5-e5c6-49b9-99a5-cb79c69dca5d","type":"BasicTickFormatter"},{"attributes":{},"id":"d65be3e0-5aeb-49df-9a73-2a0f927fe184","type":"ToolEvents"}],"root_ids":["3c47ed94-c527-4ee4-962c-3b8edca17ee5"]},"title":"Bokeh Application","version":"0.12.4"}};
            var render_items = [{"docid":"8fa69125-de0a-43bc-8cf4-cc82c74ec469","elementid":"44a7e710-166f-4242-9a17-ac86c3d4a119","modelid":"3c47ed94-c527-4ee4-962c-3b8edca17ee5"}];
            
            Bokeh.embed.embed_items(docs_json, render_items);
          };
          if (document.readyState != "loading") fn();
          else document.addEventListener("DOMContentLoaded", fn);
        })();
      },
      function(Bokeh) {
      }
    ];
  
    function run_inline_js() {
      
      if ((window.Bokeh !== undefined) || (force === true)) {
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i](window.Bokeh);
        }if (force === true) {
          display_loaded();
        }} else if (Date.now() < window._bokeh_timeout) {
        setTimeout(run_inline_js, 100);
      } else if (!window._bokeh_failed_load) {
        console.log("Bokeh: BokehJS failed to load within specified timeout.");
        window._bokeh_failed_load = true;
      } else if (force !== true) {
        var cell = $(document.getElementById("44a7e710-166f-4242-9a17-ac86c3d4a119")).parents('.cell').data().cell;
        cell.output_area.append_execute_result(NB_LOAD_WARNING)
      }
  
    }
  
    if (window._bokeh_is_loading === 0) {
      console.log("Bokeh: BokehJS loaded, going straight to plotting");
      run_inline_js();
    } else {
      load_libs(js_urls, function() {
        console.log("Bokeh: BokehJS plotting callback run at", now());
        run_inline_js();
      });
    }
  }(this));
</script>


    WARNING:/anaconda/lib/python3.6/site-packages/bokeh/core/validation/check.py:W-1005 (SNAPPED_TOOLBAR_ANNOTATIONS): Snapped toolbars and annotations on the same side MAY overlap visually: GMapPlot(id='2e944da3-5ae5-423c-ab87-627c7f1c9912', ...)
    WARNING:/anaconda/lib/python3.6/site-packages/bokeh/core/validation/check.py:W-1005 (SNAPPED_TOOLBAR_ANNOTATIONS): Snapped toolbars and annotations on the same side MAY overlap visually: GMapPlot(id='d9dd0aa7-0cdb-440b-a95b-ffe4c560ba87', ...)
    WARNING:/anaconda/lib/python3.6/site-packages/bokeh/core/validation/check.py:W-1005 (SNAPPED_TOOLBAR_ANNOTATIONS): Snapped toolbars and annotations on the same side MAY overlap visually: GMapPlot(id='3c47ed94-c527-4ee4-962c-3b8edca17ee5', ...)


References:

![image.png](attachment:image.png)

